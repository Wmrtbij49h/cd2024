﻿# NX 1872
# Journal created by Admin on Fri May 24 13:54:16 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: Tools->Movie->Record...
    # ----------------------------------------------
    theUI = NXOpen.UI.GetUI()
    
    theUI.MovieManager.Start("F:\\嚴家明\Sieme\\Siemens\\nx影片\bas\\base.avi", False)
    
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "Z:\\base.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    # User Function call - UF_PART_ask_part_name
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch Dialog")
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(True)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    scaleAboutPoint1 = NXOpen.Point3d(0.884963306818632, -8.2596575303072157, 0.0)
    viewCenter1 = NXOpen.Point3d(-0.884963306818632, 8.2596575303072157, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId7)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    scaleAboutPoint2 = NXOpen.Point3d(10.383569466671922, 2.5958923666680005, 0.0)
    viewCenter2 = NXOpen.Point3d(-10.383569466671922, -2.5958923666679805, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(12.684474064400375, 3.244865458335001, 0.0)
    viewCenter3 = NXOpen.Point3d(-12.684474064400375, -3.2448654583349756, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(15.855592580500469, 4.7935512452676319, 0.0)
    viewCenter4 = NXOpen.Point3d(-15.855592580500469, -4.7935512452675688, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(11.799510757581769, -1.4749388446976865, 0.0)
    viewCenter5 = NXOpen.Point3d(-11.799510757581745, 1.4749388446977119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(14.749388446977241, -2.949877689395398, 0.0)
    viewCenter6 = NXOpen.Point3d(-14.749388446977115, 2.949877689395461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint6, viewCenter6)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId9, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(165.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(165.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(165.0, 0.0, 20.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(165.0, 0.0, 20.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 20.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 20.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(82.5, 0.0, -15.678483782219857)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression5 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(180.67848378221987, 0.0, 10.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression6 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    scaleAboutPoint7 = NXOpen.Point3d(98.175616850192029, 45.170002118867721, 0.0)
    viewCenter7 = NXOpen.Point3d(-98.175616850191943, -45.170002118867643, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(134.24248078694097, 50.124874800274085, 0.0)
    viewCenter8 = NXOpen.Point3d(-134.24248078694092, -50.124874800274085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(107.39398462955266, 39.178063062283194, 0.0)
    viewCenter9 = NXOpen.Point3d(-107.39398462955266, -39.178063062283194, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.98189570051620489
    rotMatrix1.Xy = -0.18942232052562716
    rotMatrix1.Xz = -0.00013339594418135882
    rotMatrix1.Yx = -0.0020566559870716468
    rotMatrix1.Yy = -0.011365126938675469
    rotMatrix1.Yz = 0.99993329980345125
    rotMatrix1.Zx = -0.18941120208145609
    rotMatrix1.Zy = -0.9818299335304228
    rotMatrix1.Zz = -0.011548945826500378
    translation1 = NXOpen.Point3d(-12.818111131876677, -6.9762027700355578, 18.089754543894529)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.71754387453957968)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    parallelDimension1 = dimension2
    point3 = NXOpen.Point3d(182.77750407575584, 0.0, 10.302577157451644)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(parallelDimension1, workPart.ModelingViews.WorkView, point3)
    
    point1_1 = NXOpen.Point3d(165.0, 0.0, 20.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    sketchRapidDimensionBuilder1.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder1 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList1 = convertToFromReferenceBuilder1.InputObjects
    
    added1 = selectNXObjectList1.Add(parallelDimension1)
    
    convertToFromReferenceBuilder1.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject3 = convertToFromReferenceBuilder1.Commit()
    
    convertToFromReferenceBuilder1.Destroy()
    
    expression7 = workPart.Expressions.FindObject("p0")
    expression7.SetFormula("5")
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.25)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId11, None)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId10, "Edit Driving Value")
    
    scaleAboutPoint10 = NXOpen.Point3d(22.1240826704658, -6.6372248011397392, 0.0)
    viewCenter10 = NXOpen.Point3d(-22.1240826704658, 6.6372248011397392, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(17.699266136372643, -7.3746942234885839, 0.0)
    viewCenter11 = NXOpen.Point3d(-17.699266136372643, 7.3746942234885839, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(13.923422693946453, -6.1357455939425094, 0.0)
    viewCenter12 = NXOpen.Point3d(-13.923422693946453, 6.1357455939425094, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(9.062024261822792, -3.5870512703048445, 0.0)
    viewCenter13 = NXOpen.Point3d(-9.062024261822792, 3.5870512703048445, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(6.9475519340641059, -2.7186072785468505, 0.0)
    viewCenter14 = NXOpen.Point3d(-6.9475519340641316, 2.7186072785468247, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(5.4372145570936548, -2.1748858228374801, 0.0)
    viewCenter15 = NXOpen.Point3d(-5.4372145570936956, 2.1748858228374597, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-3.9631252771705232, -1.2566006976394299, 0.0)
    viewCenter16 = NXOpen.Point3d(3.9631252771704903, 1.2566006976394135, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-4.562427148352401, -1.3919269266159946, 0.0)
    viewCenter17 = NXOpen.Point3d(4.5624271483523682, 1.3919269266159748, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-4.2685759082890193, -1.2991317981749264, 0.0)
    viewCenter18 = NXOpen.Point3d(4.268575908288998, 1.2991317981749051, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(4.3056939596654189, -4.800601311351123, 0.0)
    viewCenter19 = NXOpen.Point3d(-4.3056939596654527, 4.8006013113511026, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(5.4439808685424902, -6.3719321529531703, 0.0)
    viewCenter20 = NXOpen.Point3d(-5.4439808685425115, 6.3719321529531392, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(11.831378876235828, -16.857781666793571, 0.0)
    viewCenter21 = NXOpen.Point3d(-11.831378876235862, 16.857781666793535, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(9.4651031009886619, -13.486225333434849, 0.0)
    viewCenter22 = NXOpen.Point3d(-9.4651031009886832, 13.486225333434822, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(7.5720824807909208, -10.788980266747885, 0.0)
    viewCenter23 = NXOpen.Point3d(-7.5720824807909546, 10.788980266747854, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    point4 = NXOpen.Point3d(24.243262783158357, 1.7763568394002505e-15, 2.5673907444456745e-16)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(line1, workPart.ModelingViews.WorkView, point4)
    
    point1_3 = NXOpen.Point3d(41.25, 0.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, workPart.ModelingViews.WorkView, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionlinearunits21 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point5 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point5
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point6 = NXOpen.Point3d(24.242873719853989, 0.0, -0.17147660978300339)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point6)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = True
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject4 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId13, None)
    
    theSession.SetUndoMarkName(markId12, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId12, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId14, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits27 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    expression8 = workPart.Expressions.FindObject("p1")
    expression8.SetFormula("120")
    
    theSession.SetUndoMarkVisibility(markId14, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId15, None)
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId14, "Edit Driving Value")
    
    scaleAboutPoint24 = NXOpen.Point3d(10.333665503197032, 4.6323328117779692, 0.0)
    viewCenter24 = NXOpen.Point3d(-10.33366550319707, -4.6323328117780029, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(24.943330524958355, 5.0480549871939413, 0.0)
    viewCenter25 = NXOpen.Point3d(-24.943330524958405, -5.0480549871939751, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(31.550343669962214, 6.1863418960710126, 0.0)
    viewCenter26 = NXOpen.Point3d(-31.550343669962256, -6.1863418960710437, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(39.515258861153669, 7.732927370088766, 0.0)
    viewCenter27 = NXOpen.Point3d(-39.515258861153718, -7.7329273700887988, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(49.394073576442054, 9.6661592126109639, 0.0)
    viewCenter28 = NXOpen.Point3d(-49.394073576442118, -9.6661592126109959, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(61.863418960710213, 11.961872025606073, 0.0)
    viewCenter29 = NXOpen.Point3d(-61.863418960710256, -11.961872025606093, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(79.594779766343464, 11.931665278066665, 0.0)
    viewCenter30 = NXOpen.Point3d(-79.594779766343493, -11.93166527806669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(99.49347470792938, 14.914581597583334, 0.0)
    viewCenter31 = NXOpen.Point3d(-99.49347470792938, -14.914581597583366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(127.67070639703465, 16.519315060614453, 0.0)
    viewCenter32 = NXOpen.Point3d(-127.67070639703465, -16.519315060614474, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(160.47334630311195, 20.35415605682854, 0.0)
    viewCenter33 = NXOpen.Point3d(-160.47334630311195, -20.354156056828565, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(203.9102952794598, 24.705225648686792, 0.0)
    viewCenter34 = NXOpen.Point3d(-203.9102952794598, -24.705225648686856, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(254.88786909932475, 30.88153206085849, 0.0)
    viewCenter35 = NXOpen.Point3d(-254.88786909932475, -30.881532060858568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(318.60983637415592, 38.601915076073162, 0.0)
    viewCenter36 = NXOpen.Point3d(-318.60983637415592, -38.601915076073212, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(254.88786909932475, 30.88153206085849, 0.0)
    viewCenter37 = NXOpen.Point3d(-254.88786909932475, -30.881532060858568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(203.9102952794598, 24.705225648686792, 0.0)
    viewCenter38 = NXOpen.Point3d(-203.9102952794598, -24.705225648686856, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(164.30818729932599, 20.059168287888948, 0.0)
    viewCenter39 = NXOpen.Point3d(-164.30818729932599, -20.059168287889047, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(131.91853026976412, 16.991295490917704, 0.0)
    viewCenter40 = NXOpen.Point3d(-131.91853026976418, -16.991295490917782, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(106.10120073217522, 15.292165941825935, 0.0)
    viewCenter41 = NXOpen.Point3d(-106.10120073217522, -15.292165941826015, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.944428312888276
    rotMatrix2.Xy = -0.32871325724618061
    rotMatrix2.Xz = -0.0016602185436884924
    rotMatrix2.Yx = -0.0059787497168950505
    rotMatrix2.Yy = -0.022226907666973224
    rotMatrix2.Yz = 0.99973507447092536
    rotMatrix2.Zx = -0.32866307423686847
    rotMatrix2.Zy = -0.94416818368666244
    rotMatrix2.Zz = -0.022957015202343244
    translation2 = NXOpen.Point3d(24.60828643804679, 17.127851535810017, 27.98307409580999)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 1.7518160999501455)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.944428312888276
    rotMatrix3.Xy = -0.32871325724618061
    rotMatrix3.Xz = -0.0016602185436884924
    rotMatrix3.Yx = -0.0059787497168950505
    rotMatrix3.Yy = -0.022226907666973224
    rotMatrix3.Yz = 0.99973507447092536
    rotMatrix3.Zx = -0.32866307423686847
    rotMatrix3.Zy = -0.94416818368666244
    rotMatrix3.Zz = -0.022957015202343244
    translation3 = NXOpen.Point3d(26.97098541318574, 19.178985810930641, 27.98307409580999)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 1.4948425209005307)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.944428312888276
    rotMatrix4.Xy = -0.32871325724618061
    rotMatrix4.Xz = -0.0016602185436884924
    rotMatrix4.Yx = -0.0059787497168950505
    rotMatrix4.Yy = -0.022226907666973224
    rotMatrix4.Yz = 0.99973507447092536
    rotMatrix4.Zx = -0.32866307423686847
    rotMatrix4.Zy = -0.94416818368666244
    rotMatrix4.Zz = -0.022957015202343244
    translation4 = NXOpen.Point3d(26.766898706385454, 19.250918010868659, 27.98307409580999)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 1.4808467136632886)
    
    scaleAboutPoint42 = NXOpen.Point3d(32.875336038597489, 11.434899491686021, 0.0)
    viewCenter42 = NXOpen.Point3d(-32.875336038597432, -11.434899491686142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(50.697698918217583, 14.293624364607547, 0.0)
    viewCenter43 = NXOpen.Point3d(-50.697698918217512, -14.293624364607661, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(68.676398314325581, 17.867030455759455, 0.0)
    viewCenter44 = NXOpen.Point3d(-68.676398314325553, -17.867030455759576, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(90.731014033153613, 21.286891753932153, 0.0)
    viewCenter45 = NXOpen.Point3d(-90.731014033153556, -21.286891753932274, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(121.70169670793209, 26.17240789417886, 0.0)
    viewCenter46 = NXOpen.Point3d(-121.70169670793202, -26.172407894178971, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(191.38573272618345, 29.989217378746662, 0.0)
    viewCenter47 = NXOpen.Point3d(-191.38573272618333, -29.989217378746755, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(154.41720657565571, 23.991373902997296, 0.0)
    viewCenter48 = NXOpen.Point3d(-154.41720657565571, -23.991373902997406, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(124.58066157629173, 19.193099122397864, 0.0)
    viewCenter49 = NXOpen.Point3d(-124.58066157629173, -19.193099122397925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(103.85211452410199, 16.191996350531991, 0.0)
    viewCenter50 = NXOpen.Point3d(-103.85211452410199, -16.191996350532087, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(94.69526141552528, 16.527003171577469, 0.0)
    viewCenter51 = NXOpen.Point3d(-94.69526141552528, -16.527003171577565, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(83.260361923839199, 17.688360151201849, 0.0)
    viewCenter52 = NXOpen.Point3d(-83.260361923839199, -17.688360151201937, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(66.751225782717427, 14.150688120961464, 0.0)
    viewCenter53 = NXOpen.Point3d(-66.751225782717412, -14.150688120961561, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(53.744027610924583, 11.43489949168603, 0.0)
    viewCenter54 = NXOpen.Point3d(-53.74402761092454, -11.434899491686128, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    theSession.UndoToMark(markId16, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId18, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(43.475391919384599, 0.0, 5.0)
    section1.AddToSection(rules1, line3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId20, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId19, None)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("120")
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId21, None)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId22, None)
    
    theSession.SetUndoMarkName(markId18, "Extrude")
    
    expression11 = extrudeBuilder1.Limits.StartExtend.Value
    expression12 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    workPart.Expressions.Delete(expression10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId23, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 130 * 140 {(0,-120,5)(60,-120,5)(120,-120,5) EXTRUDE(2)}")
    point7 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 140 * 170 {(0,-120,5)(0,-60,5)(0,0,5) EXTRUDE(2)}")
    direction3 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 140 {(60,-60,5) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point7, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point8 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId24, None)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject5 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject5
    feature3 = sketch3.Feature
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId26)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId25, None)
    
    theSession.SetUndoMarkName(markId23, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point8)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    scaleAboutPoint55 = NXOpen.Point3d(31.150708400015848, 16.755305275766101, 0.0)
    viewCenter55 = NXOpen.Point3d(-31.150708400015848, -16.755305275766084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(39.233373268959333, 20.944131594707628, 0.0)
    viewCenter56 = NXOpen.Point3d(-39.233373268959333, -20.944131594707603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(50.516655430896925, 26.180164493384535, 0.0)
    viewCenter57 = NXOpen.Point3d(-50.516655430896805, -26.180164493384535, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(64.06765606655722, 32.264287227762637, 0.0)
    viewCenter58 = NXOpen.Point3d(-64.067656066557149, -32.264287227762637, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(88.726789876347226, 46.09183889680375, 0.0)
    viewCenter59 = NXOpen.Point3d(-88.726789876347169, -46.09183889680375, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(71.442350290045823, 38.25622628434715, 0.0)
    viewCenter60 = NXOpen.Point3d(-71.442350290045596, -38.256226284347115, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId28, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(61.0, -43.0, 5.0)
    endPoint5 = NXOpen.Point3d(61.0, -28.0, 5.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(61.0, -28.0, 5.0)
    endPoint6 = NXOpen.Point3d(89.0, -28.0, 5.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(89.0, -28.0, 5.0)
    endPoint7 = NXOpen.Point3d(89.0, -43.0, 5.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(89.0, -43.0, 5.0)
    endPoint8 = NXOpen.Point3d(61.0, -43.0, 5.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line5
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line6
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line6
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line7
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line7
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line8
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line8
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line5
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom6.Geometry = line5
    geom6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom6)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = line5
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line5
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(73.54278702577588, -35.5, 5.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_3, dimObject2_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint3
    dimension3 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression17 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line6
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line6
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(75.0, -40.542787025775887, 5.0)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression18 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    scaleAboutPoint61 = NXOpen.Point3d(113.93902575289903, 47.935512452675908, 0.0)
    viewCenter61 = NXOpen.Point3d(-113.9390257528987, -47.935512452675908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(140.11919024628352, 59.919390565844928, 0.0)
    viewCenter62 = NXOpen.Point3d(-140.11919024628321, -59.919390565844886, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(173.42054384922429, 74.899238207306112, 0.0)
    viewCenter63 = NXOpen.Point3d(-173.420543849224, -74.899238207306112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(138.73643507937942, 59.919390565844928, 0.0)
    viewCenter64 = NXOpen.Point3d(-138.73643507937911, -59.91939056584485, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(110.98914806350356, 47.935512452675937, 0.0)
    viewCenter65 = NXOpen.Point3d(-110.98914806350325, -47.935512452675908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(85.841440761407469, 40.708312113657101, 0.0)
    viewCenter66 = NXOpen.Point3d(-85.841440761407171, -40.70831211365708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(68.437162393974333, 32.566649690925665, 0.0)
    viewCenter67 = NXOpen.Point3d(-68.437162393974077, -32.566649690925644, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(54.749729915179472, 26.242111924861842, 0.0)
    viewCenter68 = NXOpen.Point3d(-54.749729915179188, -26.242111924861842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(43.79978393214364, 21.144723277586532, 0.0)
    viewCenter69 = NXOpen.Point3d(-43.799783932143356, -21.144723277586518, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines13 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines16)
    
    theSession.SetUndoMarkName(markId29, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    point1_5 = NXOpen.Point3d(75.0, -28.0, 5.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line6, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(89.0, -28.0, 5.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    point1_7 = NXOpen.Point3d(75.0, -28.0, 5.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line6, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(89.0, -28.0, 5.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Destroy()
    
    theSession.UndoToMark(markId29, None)
    
    theSession.DeleteUndoMark(markId29, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines21 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines24)
    
    theSession.SetUndoMarkName(markId30, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point1_9 = NXOpen.Point3d(61.0, -28.0, 5.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(89.0, -28.0, 5.0)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    point1_11 = NXOpen.Point3d(61.0, -28.0, 5.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(89.0, -28.0, 5.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point9 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point9
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point10 = NXOpen.Point3d(77.256080538610206, -21.567625795723195, 5.0)
    sketchRapidDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point10)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.TextCentered = True
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject6 = sketchRapidDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId31, None)
    
    theSession.SetUndoMarkName(markId30, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId30, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines25 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines28)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId32, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    expression19 = workPart.Expressions.FindObject("p4")
    expression19.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId32, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.21428571428571427)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId33, None)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId32, "Edit Driving Value")
    
    scaleAboutPoint70 = NXOpen.Point3d(-39.027117820916672, -17.51991357285738, 0.0)
    viewCenter70 = NXOpen.Point3d(39.027117820916985, 17.519913572857391, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-31.221694256733311, -14.015930858285914, 0.0)
    viewCenter71 = NXOpen.Point3d(31.221694256733617, 14.015930858285914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-24.977355405386621, -11.212744686628733, 0.0)
    viewCenter72 = NXOpen.Point3d(24.977355405386938, 11.212744686628733, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-19.981884324309277, -8.9701957493029987, 0.0)
    viewCenter73 = NXOpen.Point3d(19.981884324309572, 8.9701957493029827, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-15.985507459447389, -7.225647334610958, 0.0)
    viewCenter74 = NXOpen.Point3d(15.985507459447684, 7.225647334610958, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    point1_13 = NXOpen.Point3d(113.35714285714286, -100.28571428571429, 5.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(113.35714285714286, -103.5, 5.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(113.35714285714286, -100.28571428571429, 5.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(113.35714285714286, -103.5, 5.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point11 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point11
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point12 = NXOpen.Point3d(115.21311587005415, -102.34694504277616, 5.0)
    sketchRapidDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point12)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId35, None)
    
    theSession.SetUndoMarkName(markId34, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId34, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId36, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    expression20 = workPart.Expressions.FindObject("p5")
    expression20.SetFormula("5.9")
    
    theSession.SetUndoMarkVisibility(markId36, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId37, None)
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId36, "Edit Driving Value")
    
    scaleAboutPoint75 = NXOpen.Point3d(-10.887961737084861, -1.7816664660684414, 0.0)
    viewCenter75 = NXOpen.Point3d(10.887961737085146, 1.7816664660684682, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-13.609952171356102, -2.5240274935969658, 0.0)
    viewCenter76 = NXOpen.Point3d(13.609952171356412, 2.5240274935969955, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-17.012440214195163, -3.5262148807604734, 0.0)
    viewCenter77 = NXOpen.Point3d(17.01244021419549, 3.5262148807605, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder6.Destroy()
    
    theSession.UndoToMark(markId38, None)
    
    theSession.DeleteUndoMark(markId38, None)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines33 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines36)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines37 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines40)
    
    theSession.SetUndoMarkName(markId39, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    point1_17 = NXOpen.Point3d(113.35714285714286, -100.55, 5.0)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line7, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    edge3 = extrude1.FindObject("EDGE * 140 * 150 {(120,-120,5)(120,-60,5)(120,0,5) EXTRUDE(2)}")
    point13 = NXOpen.Point3d(120.0, -100.11862469181139, 5.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(edge3, workPart.ModelingViews.WorkView, point13)
    
    point1_18 = NXOpen.Point3d(120.0, -100.11862469181139, 5.0)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    point1_19 = NXOpen.Point3d(113.35714285714286, -100.55, 5.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line7, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point14 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point14
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder7.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point15 = NXOpen.Point3d(119.13030755864634, -91.612404584713715, 5.0)
    sketchRapidDimensionBuilder7.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point15)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.TextCentered = False
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject8 = sketchRapidDimensionBuilder7.Commit()
    
    theSession.DeleteUndoMark(markId40, None)
    
    theSession.SetUndoMarkName(markId39, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId39, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId41, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits195 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    expression21 = workPart.Expressions.FindObject("p6")
    expression21.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId41, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId42, None)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId41, "Edit Driving Value")
    
    scaleAboutPoint78 = NXOpen.Point3d(-6.3410004434726357, 11.831378876235862, 0.0)
    viewCenter78 = NXOpen.Point3d(6.3410004434729714, -11.831378876235849, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-4.7634832599745316, 9.6506933578708303, 0.0)
    viewCenter79 = NXOpen.Point3d(4.7634832599748691, -9.6506933578707983, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-3.8107866079795913, 7.7205546862966683, 0.0)
    viewCenter80 = NXOpen.Point3d(3.8107866079799289, -7.720554686296639, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(-3.1278144626533479, 6.1764437490373361, 0.0)
    viewCenter81 = NXOpen.Point3d(3.1278144626536859, -6.1764437490373085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-4.0582402838224327, 7.6710639511281036, 0.0)
    viewCenter82 = NXOpen.Point3d(4.0582402838227623, -7.6710639511280743, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-5.0728003547780833, 9.5269665199494149, 0.0)
    viewCenter83 = NXOpen.Point3d(5.0728003547784315, -9.5269665199493829, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(-6.3410004434726241, 11.908708149936762, 0.0)
    viewCenter84 = NXOpen.Point3d(6.3410004434729998, -11.908708149936741, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-7.9262505543408279, 14.88588518742095, 0.0)
    viewCenter85 = NXOpen.Point3d(7.9262505543411992, -14.885885187420916, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(-9.907813192926108, 18.607356484276178, 0.0)
    viewCenter86 = NXOpen.Point3d(9.9078131929264579, -18.607356484276156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-12.384766491157682, 24.014364293830432, 0.0)
    viewCenter87 = NXOpen.Point3d(12.384766491158043, -24.014364293830432, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-15.480958113947104, 30.206747539409353, 0.0)
    viewCenter88 = NXOpen.Point3d(15.480958113947489, -30.206747539409339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-20.059168287888827, 44.366160448507486, 0.0)
    viewCenter89 = NXOpen.Point3d(20.059168287889189, -44.366160448507486, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-16.04733463031106, 36.248097047291218, 0.0)
    viewCenter90 = NXOpen.Point3d(16.047334630311383, -36.248097047291218, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-13.290968917339935, 29.753646326318204, 0.0)
    viewCenter91 = NXOpen.Point3d(13.290968917340322, -29.753646326318218, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint91, viewCenter91)
    
    perpendicularDimension1 = nXObject8
    perpendicularDimension1.LeaderOrientation = NXOpen.Annotations.LeaderOrientation.FromLeft
    
    perpendicularDimension1.IsOriginCentered = False
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId41)
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    origin8 = NXOpen.Point3d(80.256108376472909, -89.192667095266444, 5.0)
    perpendicularDimension1.AnnotationOrigin = origin8
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId44)
    
    theSession.DeleteUndoMark(markId44, None)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId43, "Edit Object Origin")
    
    scaleAboutPoint92 = NXOpen.Point3d(-17.036605612226662, 29.602612588621152, 0.0)
    viewCenter92 = NXOpen.Point3d(17.036605612227074, -29.602612588621142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(-21.295757015283382, 37.003265735776445, 0.0)
    viewCenter93 = NXOpen.Point3d(21.295757015283794, -37.003265735776445, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(-26.997280613346884, 46.631666513963175, 0.0)
    viewCenter94 = NXOpen.Point3d(26.997280613347336, -46.631666513963161, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(-33.982590981835244, 58.525573357605616, 0.0)
    viewCenter95 = NXOpen.Point3d(33.982590981835706, -58.525573357605602, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(-42.478238727294155, 73.746942234886077, 0.0)
    viewCenter96 = NXOpen.Point3d(42.478238727294602, -73.746942234886077, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-54.941471964989923, 96.608494327700768, 0.0)
    viewCenter97 = NXOpen.Point3d(54.941471964990363, -96.608494327700768, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-44.248165340931394, 77.876771000039696, 0.0)
    viewCenter98 = NXOpen.Point3d(44.248165340931898, -77.876771000039668, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-36.342493133351603, 64.189338521244864, 0.0)
    viewCenter99 = NXOpen.Point3d(36.342493133352107, -64.189338521244835, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-30.961916227894324, 52.861808193966375, 0.0)
    viewCenter100 = NXOpen.Point3d(30.961916227894839, -52.861808193966311, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-38.938385500019585, 66.313250457609598, 0.0)
    viewCenter101 = NXOpen.Point3d(38.93838550002009, -66.313250457609541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-31.905877088500858, 53.428184710330299, 0.0)
    viewCenter102 = NXOpen.Point3d(31.905877088501374, -53.428184710330235, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-25.67573540849768, 43.044615243658356, 0.0)
    viewCenter103 = NXOpen.Point3d(25.675735408498209, -43.044615243658264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-21.386377257901554, 34.798173165399611, 0.0)
    viewCenter104 = NXOpen.Point3d(21.386377257902069, -34.798173165399518, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-19.1389952409695, 28.708492861454676, 0.0)
    viewCenter105 = NXOpen.Point3d(19.138995240970011, -28.708492861454594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint105, viewCenter105)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder8.Destroy()
    
    theSession.UndoToMark(markId45, None)
    
    theSession.DeleteUndoMark(markId45, None)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines49 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines52)
    
    theSession.SetUndoMarkName(markId46, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits197 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits203 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits207 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits213 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    point1_20 = NXOpen.Point3d(63.0, -97.600000000000009, 5.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line6, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    scaleAboutPoint106 = NXOpen.Point3d(18.404367140811587, 21.884184457351335, 0.0)
    viewCenter106 = NXOpen.Point3d(-18.404367140811072, -21.88418445735125, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(29.868431966968231, 25.711983505545291, 0.0)
    viewCenter107 = NXOpen.Point3d(-29.868431966967719, -25.711983505545216, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(43.256062476434472, 31.052536470512869, 0.0)
    viewCenter108 = NXOpen.Point3d(-43.256062476433939, -31.052536470512788, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(54.52317930863417, 38.815670588141074, 0.0)
    viewCenter109 = NXOpen.Point3d(-54.523179308633637, -38.815670588140989, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(70.60827237336963, 47.386835202448495, 0.0)
    viewCenter110 = NXOpen.Point3d(-70.608272373369118, -47.386835202448395, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint110, viewCenter110)
    
    point16 = NXOpen.Point3d(63.792090543072646, 0.0, 5.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(line3, workPart.ModelingViews.WorkView, point16)
    
    point1_21 = NXOpen.Point3d(63.792090543072646, 0.0, 5.0)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line3, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(63.0, -97.600000000000009, 5.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line6, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    dimensionlinearunits217 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point17 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point17
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point18 = NXOpen.Point3d(52.228570000642492, -28.573865249070167, 5.0)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point18)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject9 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId47, None)
    
    theSession.SetUndoMarkName(markId46, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId46, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId48, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits223 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits225 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits229 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits233 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression22 = workPart.Expressions.FindObject("p7")
    expression22.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId48, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId49, None)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId48, "Edit Driving Value")
    
    scaleAboutPoint111 = NXOpen.Point3d(114.69124456369519, 59.233544003060615, 0.0)
    viewCenter111 = NXOpen.Point3d(-114.69124456369467, -59.233544003060508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(140.41417801522346, 73.451954465946642, 0.0)
    viewCenter112 = NXOpen.Point3d(-140.41417801522289, -73.451954465946514, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(175.14898780785475, 91.814943082433288, 0.0)
    viewCenter113 = NXOpen.Point3d(-175.14898780785433, -91.814943082433174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(218.01439798188224, 113.84684207510554, 0.0)
    viewCenter114 = NXOpen.Point3d(-218.01439798188184, -113.84684207510539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(271.9418494911427, 142.30855259388187, 0.0)
    viewCenter115 = NXOpen.Point3d(-271.94184949114236, -142.30855259388173, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(217.55347959291421, 113.84684207510554, 0.0)
    viewCenter116 = NXOpen.Point3d(-217.55347959291382, -113.84684207510539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(171.09290598493595, 91.077473660084479, 0.0)
    viewCenter117 = NXOpen.Point3d(-171.09290598493558, -91.07747366008428, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(135.9893614811302, 72.8619789280676, 0.0)
    viewCenter118 = NXOpen.Point3d(-135.98936148112978, -72.861978928067401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(107.84752832429764, 58.76156357275736, 0.0)
    viewCenter119 = NXOpen.Point3d(-107.84752832429724, -58.761563572757161, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(85.711646143074262, 47.19804303032722, 0.0)
    viewCenter120 = NXOpen.Point3d(-85.711646143073807, -47.198043030327021, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(93.924105630351136, 65.841270027306422, 0.0)
    viewCenter121 = NXOpen.Point3d(-93.924105630350738, -65.841270027306223, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(117.11014426899933, 82.006599765193457, 0.0)
    viewCenter122 = NXOpen.Point3d(-117.11014426899892, -82.006599765193258, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(146.38768033624916, 101.03331086179413, 0.0)
    viewCenter123 = NXOpen.Point3d(-146.38768033624874, -101.03331086179391, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(182.06276364237524, 123.98704663240237, 0.0)
    viewCenter124 = NXOpen.Point3d(-182.06276364237485, -123.98704663240221, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(227.00230656675896, 154.40766030429288, 0.0)
    viewCenter125 = NXOpen.Point3d(-227.00230656675865, -154.40766030429273, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(181.60184525340725, 123.5261282434343, 0.0)
    viewCenter126 = NXOpen.Point3d(-181.60184525340685, -123.52612824343419, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(145.28147620272577, 98.820902594747466, 0.0)
    viewCenter127 = NXOpen.Point3d(-145.28147620272546, -98.820902594747338, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(116.22518096218067, 79.05672207579795, 0.0)
    viewCenter128 = NXOpen.Point3d(-116.22518096218032, -79.056722075797893, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(92.98014476974457, 63.245377660638354, 0.0)
    viewCenter129 = NXOpen.Point3d(-92.980144769744214, -63.245377660638312, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(74.384115815795695, 50.596302128510693, 0.0)
    viewCenter130 = NXOpen.Point3d(-74.384115815795312, -50.596302128510651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(59.5072926526366, 40.477041702808556, 0.0)
    viewCenter131 = NXOpen.Point3d(-59.50729265263621, -40.477041702808513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(41.564484614227432, 37.577193939025257, 0.0)
    viewCenter132 = NXOpen.Point3d(-41.564484614227077, -37.577193939025236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(51.955605767784213, 46.971492423781548, 0.0)
    viewCenter133 = NXOpen.Point3d(-51.955605767783879, -46.971492423781527, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(64.944507209730233, 58.714365529726926, 0.0)
    viewCenter134 = NXOpen.Point3d(-64.94450720972992, -58.714365529726905, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(83.776526378830766, 75.752859063675018, 0.0)
    viewCenter135 = NXOpen.Point3d(-83.776526378830425, -75.752859063674975, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(105.015645742478, 94.396086060654213, 0.0)
    viewCenter136 = NXOpen.Point3d(-105.01564574247763, -94.396086060654213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(131.26955717809739, 117.99510757581774, 0.0)
    viewCenter137 = NXOpen.Point3d(-131.26955717809699, -117.99510757581774, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(164.08694647262166, 147.49388446977215, 0.0)
    viewCenter138 = NXOpen.Point3d(-164.08694647262129, -147.49388446977215, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(205.10868309077694, 184.36735558721517, 0.0)
    viewCenter139 = NXOpen.Point3d(-205.10868309077665, -184.36735558721517, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(256.38585386347114, 230.45919448401895, 0.0)
    viewCenter140 = NXOpen.Point3d(-256.38585386347086, -230.45919448401895, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(323.18301101469854, 296.17607416110252, 0.0)
    viewCenter141 = NXOpen.Point3d(-323.1830110146982, -296.17607416110252, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(257.82622382899626, 239.10141427716965, 0.0)
    viewCenter142 = NXOpen.Point3d(-257.82622382899604, -239.10141427716965, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(205.684831076987, 191.28113142173572, 0.0)
    viewCenter143 = NXOpen.Point3d(-205.68483107698682, -191.28113142173572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(163.62602808365352, 153.02490513738857, 0.0)
    viewCenter144 = NXOpen.Point3d(-163.62602808365332, -153.02490513738857, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(127.95094477752745, 121.31371997638756, 0.0)
    viewCenter145 = NXOpen.Point3d(-127.95094477752707, -121.31371997638756, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(102.36075582202199, 97.050975981110028, 0.0)
    viewCenter146 = NXOpen.Point3d(-102.36075582202166, -97.050975981110057, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(81.888604657617634, 77.404790569736392, 0.0)
    viewCenter147 = NXOpen.Point3d(-81.888604657617293, -77.404790569736434, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(65.510883726094136, 61.923832455789132, 0.0)
    viewCenter148 = NXOpen.Point3d(-65.510883726093809, -61.923832455789146, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(52.257673243178324, 49.08596475154016, 0.0)
    viewCenter149 = NXOpen.Point3d(-52.257673243177962, -49.085964751540203, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(41.322830633912169, 36.973058988237007, 0.0)
    viewCenter150 = NXOpen.Point3d(-41.322830633911806, -36.973058988237042, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(33.058264507129742, 29.385124006337389, 0.0)
    viewCenter151 = NXOpen.Point3d(-33.058264507129415, -29.385124006337431, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(26.44661160570384, 23.430769931369021, 0.0)
    viewCenter152 = NXOpen.Point3d(-26.446611605703485, -23.430769931369046, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(21.157289284563099, 18.6827525261345, 0.0)
    viewCenter153 = NXOpen.Point3d(-21.157289284562751, -18.682752526134525, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(16.925831427650511, 14.946202020907593, 0.0)
    viewCenter154 = NXOpen.Point3d(-16.925831427650166, -14.946202020907622, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(13.976183611603838, 10.096109974387907, 0.0)
    viewCenter155 = NXOpen.Point3d(-13.976183611603497, -10.096109974387938, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(17.569210984841888, 12.323193056973471, 0.0)
    viewCenter156 = NXOpen.Point3d(-17.569210984841572, -12.323193056973514, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(21.96151373105231, 15.156537645374007, 0.0)
    viewCenter157 = NXOpen.Point3d(-21.961513731051991, -15.156537645374039, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(27.451892163815344, 18.636354961913955, 0.0)
    viewCenter158 = NXOpen.Point3d(-27.451892163815028, -18.636354961913991, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(34.314865204769141, 23.295443702392447, 0.0)
    viewCenter159 = NXOpen.Point3d(-34.314865204768836, -23.295443702392486, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder10.Destroy()
    
    theSession.UndoToMark(markId50, None)
    
    theSession.DeleteUndoMark(markId50, None)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    sketch4 = theSession.ActiveSketch
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("120")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId52, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule2
    helpPoint2 = NXOpen.Point3d(65.748723535279424, -59.899999999999999, 5.0)
    section2.AddToSection(rules2, line8, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId54, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction4
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies4[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId53, None)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkName(markId52, "Extrude")
    
    expression25 = extrudeBuilder2.Limits.StartExtend.Value
    expression26 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression23)
    
    workPart.Expressions.Delete(expression24)
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin9, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId57, "Create Sketch Dialog")
    
    scalar3 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature4
    edge4 = extrude2.FindObject("EDGE * 130 * 140 {(66,-59.9,65)(63,-59.9,65)(59.9999999999999,-59.9,65) EXTRUDE(2)}")
    point19 = workPart.Points.CreatePoint(edge4, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge5 = extrude1.FindObject("EDGE * 140 EXTRUDE(4) 140 {(66,-59.9,5)(63,-59.9,5)(59.9999999999999,-59.9,5) EXTRUDE(2)}")
    direction5 = workPart.Directions.CreateDirection(edge5, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude2.FindObject("FACE 140 {(63,-59.9,35) EXTRUDE(2)}")
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction5, point19, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem3
    
    origin10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin10, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face2
    plane8.SetGeometry(geom7)
    
    plane8.SetFlip(False)
    
    plane8.SetExpression(None)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin11, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane9.SynchronizeToPlane(plane8)
    
    scalar4 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point20 = workPart.Points.CreatePoint(edge4, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom8 = [NXOpen.NXObject.Null] * 1 
    geom8[0] = face2
    plane9.SetGeometry(geom8)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId58, None)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject10 = sketchInPlaceBuilder3.Commit()
    
    sketch5 = nXObject10
    feature5 = sketch5.Feature
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId60)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId59, None)
    
    theSession.SetUndoMarkName(markId57, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression28)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point20)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression27)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression30)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression29)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    scaleAboutPoint160 = NXOpen.Point3d(4.955794518184339, -17.227285706069356, 0.0)
    viewCenter160 = NXOpen.Point3d(-4.955794518184339, 17.227285706069377, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(4.3422199587900661, -13.404244220612842, 0.0)
    viewCenter161 = NXOpen.Point3d(-4.3422199587900661, 13.40424422061289, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(3.4737759670320663, -10.572361638793224, 0.0)
    viewCenter162 = NXOpen.Point3d(-3.4737759670320534, 10.572361638793263, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(2.7790207736256427, -7.7329273700887562, 0.0)
    viewCenter163 = NXOpen.Point3d(-2.7790207736256223, 7.732927370088797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(1.9332318425222106, -4.9297411984315858, 0.0)
    viewCenter164 = NXOpen.Point3d(-1.9332318425221695, 4.9297411984316266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint164, viewCenter164)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId62, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(62.499999999999943, -59.900000000000006, 56.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 1.9662356255647571, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = arc1
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(62.499999999999943, -59.900000000000006, 56.876804363222668)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension5 = sketchDimensionalConstraint5.AssociatedDimension
    
    expression31 = sketchDimensionalConstraint5.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines57 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines60)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines61 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines64)
    
    theSession.SetUndoMarkName(markId63, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits251 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits253 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits257 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits261 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    point1_23 = NXOpen.Point3d(62.499999999999943, -59.900000000000006, 56.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    point1_24 = NXOpen.Point3d(62.499999999999943, -59.900000000000006, 56.0)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    dimensionlinearunits263 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point21 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point21
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder11.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point22 = NXOpen.Point3d(69.683150508101832, -59.900000000000006, 57.319858921236396)
    sketchRapidDimensionBuilder11.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point22)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.TextCentered = False
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject11 = sketchRapidDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId64, None)
    
    theSession.SetUndoMarkName(markId63, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId63, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId65, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    expression32 = workPart.Expressions.FindObject("p10")
    expression32.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId65, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.76287906723741383)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId66, None)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId65, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder12.Destroy()
    
    theSession.UndoToMark(markId67, None)
    
    theSession.DeleteUndoMark(markId67, None)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines69 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines72)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines73 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines76)
    
    theSession.SetUndoMarkName(markId68, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    point1_26 = NXOpen.Point3d(61.907197668093481, -59.900000000000006, 58.134088394863277)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(61.907197668093481, -59.900000000000006, 58.134088394863277)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    edge6 = extrude2.FindObject("EDGE * 140 * 170 {(66,-59.9,65)(66,-59.9,35)(66,-59.9,5) EXTRUDE(2)}")
    point23 = NXOpen.Point3d(65.999999999999986, -59.900000000000006, 56.159919815723079)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(edge6, workPart.ModelingViews.WorkView, point23)
    
    point1_29 = NXOpen.Point3d(65.999999999999986, -59.900000000000006, 56.159919815723079)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge6, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(61.907197668093481, -59.900000000000006, 58.134088394863277)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    point1_31 = NXOpen.Point3d(65.999999999999986, -59.900000000000006, 56.159919815723079)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge6, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(61.907197668093481, -59.900000000000006, 58.134088394863277)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point24 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point24
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder13.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point25 = NXOpen.Point3d(68.600540676289398, -59.900000000000006, 53.917370878397335)
    sketchRapidDimensionBuilder13.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point25)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.TextCentered = False
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject12 = sketchRapidDimensionBuilder13.Commit()
    
    theSession.DeleteUndoMark(markId69, None)
    
    theSession.SetUndoMarkName(markId68, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId68, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines77 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines80)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId70, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    expression33 = workPart.Expressions.FindObject("p11")
    expression33.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId71, None)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId70, "Edit Driving Value")
    
    point1_33 = NXOpen.Point3d(62.999999999999986, -59.900000000000006, 58.134088394863277)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(62.999999999999986, -59.900000000000006, 58.134088394863277)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    point1_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    point1_36 = NXOpen.Point3d(62.999999999999972, -59.900000000000006, 65.0)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point1_37 = NXOpen.Point3d(62.999999999999986, -59.900000000000006, 58.134088394863277)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(62.999999999999972, -59.900000000000006, 65.0)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    point1_39 = NXOpen.Point3d(62.999999999999986, -59.900000000000006, 58.134088394863277)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(62.999999999999972, -59.900000000000006, 65.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point26 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point26
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder14.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point27 = NXOpen.Point3d(54.526612862727809, -59.900000000000006, 63.119554448802987)
    sketchRapidDimensionBuilder14.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point27)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.TextCentered = False
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject13 = sketchRapidDimensionBuilder14.Commit()
    
    theSession.DeleteUndoMark(markId73, None)
    
    theSession.SetUndoMarkName(markId72, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId72, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines81 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines84)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId74, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    expression34 = workPart.Expressions.FindObject("p12")
    expression34.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId75, None)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId74, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder15.Destroy()
    
    theSession.UndoToMark(markId76, None)
    
    theSession.DeleteUndoMark(markId76, None)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    sketch6 = theSession.ActiveSketch
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    scaleAboutPoint165 = NXOpen.Point3d(-8.4956477454588679, 30.442737754560941, 0.0)
    viewCenter165 = NXOpen.Point3d(8.4956477454588679, -30.442737754560923, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(-6.796518196367094, 24.542982375770098, 0.0)
    viewCenter166 = NXOpen.Point3d(6.796518196367094, -24.542982375770034, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(-5.4372145570936761, 19.634385900616081, 0.0)
    viewCenter167 = NXOpen.Point3d(5.4372145570936503, -19.634385900616032, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(-4.3497716456749611, 15.707508720492875, 0.0)
    viewCenter168 = NXOpen.Point3d(4.3497716456749203, -15.707508720492815, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(-3.4798173165399695, 12.566006976394295, 0.0)
    viewCenter169 = NXOpen.Point3d(3.4798173165399366, -12.566006976394245, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint169, viewCenter169)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId78, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature5
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section3.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule3
    helpPoint3 = NXOpen.Point3d(62.24506235820472, -59.900000000000006, 62.290931169230575)
    section3.AddToSection(rules3, arc1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId80, None)
    
    direction6 = workPart.Directions.CreateDirection(sketch6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction6
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId79, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies19)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies23)
    
    direction7 = extrudeBuilder3.Direction
    
    success1 = direction7.ReverseDirection()
    
    extrudeBuilder3.Direction = direction7
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies26)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies32)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("27")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies33)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId81, None)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature6 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId82, None)
    
    theSession.SetUndoMarkName(markId78, "Extrude")
    
    expression37 = extrudeBuilder3.Limits.StartExtend.Value
    expression38 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression35)
    
    workPart.Expressions.Delete(expression36)
    
    scaleAboutPoint170 = NXOpen.Point3d(-2.7838538532319759, -13.996598539860678, 0.0)
    viewCenter170 = NXOpen.Point3d(2.783853853231943, 13.996598539860729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(-3.5764789086660822, -17.785732951204174, 0.0)
    viewCenter171 = NXOpen.Point3d(3.5764789086660493, 17.785732951204231, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(-5.3163875669360658, -23.198782110266318, 0.0)
    viewCenter172 = NXOpen.Point3d(5.316387566936025, 23.198782110266382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(-7.2496194094582345, -29.602612588621088, 0.0)
    viewCenter173 = NXOpen.Point3d(7.2496194094582087, 29.602612588621152, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(-9.4396086060654198, -37.380850080018966, 0.0)
    viewCenter174 = NXOpen.Point3d(9.4396086060654198, 37.380850080019052, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(-24.54298237577008, -56.401661421240775, 0.0)
    viewCenter175 = NXOpen.Point3d(24.54298237577008, 56.40166142124086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint175, viewCenter175)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin12, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane10
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId83, "Create Sketch Dialog")
    
    scalar5 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point28 = workPart.Points.CreatePoint(edge5, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction8 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction8, point28, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem4
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin13, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = face1
    plane11.SetGeometry(geom9)
    
    plane11.SetFlip(False)
    
    plane11.SetExpression(None)
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin14, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane12.SynchronizeToPlane(plane11)
    
    scalar6 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point29 = workPart.Points.CreatePoint(edge5, scalar6, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = face1
    plane12.SetGeometry(geom10)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId84, None)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject14 = sketchInPlaceBuilder4.Commit()
    
    sketch7 = nXObject14
    feature7 = sketch7.Feature
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId86)
    
    sketch7.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId85, None)
    
    theSession.SetUndoMarkName(markId83, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression40)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point29)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression39)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression42)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression41)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane12.DestroyPlane()
    
    scaleAboutPoint176 = NXOpen.Point3d(4.129828765153583, 54.572737253815674, 0.0)
    viewCenter176 = NXOpen.Point3d(-4.129828765153583, -54.572737253815603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(3.3038630121228656, 43.658189803052551, 0.0)
    viewCenter177 = NXOpen.Point3d(-3.3038630121228656, -43.658189803052473, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(2.6430904096982926, 34.926551842442038, 0.0)
    viewCenter178 = NXOpen.Point3d(-2.6430904096982926, -34.92655184244196, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(1.812404852364558, 27.941241473953657, 0.0)
    viewCenter179 = NXOpen.Point3d(-1.812404852364558, -27.941241473953539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint179, viewCenter179)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId88, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(9.9999999999999432, -62.900000000000013, 5.0)
    endPoint9 = NXOpen.Point3d(9.9999999999999432, -55.900000000000013, 5.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(9.9999999999999432, -55.900000000000013, 5.0)
    endPoint10 = NXOpen.Point3d(15.999999999999943, -55.900000000000013, 5.0)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(15.999999999999943, -55.900000000000013, 5.0)
    endPoint11 = NXOpen.Point3d(15.999999999999943, -62.900000000000013, 5.0)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(15.999999999999943, -62.900000000000013, 5.0)
    endPoint12 = NXOpen.Point3d(9.9999999999999432, -62.900000000000013, 5.0)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line9
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line10
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line10
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line11
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line11
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line12
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line12
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line9
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom11.Geometry = line9
    geom11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateHorizontalConstraint(geom11)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line9
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line10
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line11
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line12
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line12
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line9
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line9
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line9
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(14.110020452606186, -59.400000000000013, 5.0)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_5, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression43 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line10
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line10
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(12.999999999999943, -60.010020452606256, 5.0)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_6, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression44 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines89 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines92)
    
    theSession.SetUndoMarkName(markId89, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    point1_41 = NXOpen.Point3d(15.999999999999943, -59.400000000000013, 5.0)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line11, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    scaleAboutPoint180 = NXOpen.Point3d(0.60413495078817225, 10.632775133872128, 0.0)
    viewCenter180 = NXOpen.Point3d(-0.60413495078817225, -10.632775133872025, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(0.38664636850443357, 8.4095585149716001, 0.0)
    viewCenter181 = NXOpen.Point3d(-0.38664636850443357, -8.4095585149715006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(0.07732927370089003, 6.7276468119772872, 0.0)
    viewCenter182 = NXOpen.Point3d(-0.077329273700896622, -6.7276468119771886, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(-0.18559025688213082, 5.3821174495818465, 0.0)
    viewCenter183 = NXOpen.Point3d(0.18559025688212555, -5.3821174495817461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint183, viewCenter183)
    
    point1_42 = NXOpen.Point3d(15.999999999999943, -62.900000000000013, 5.0)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, workPart.ModelingViews.WorkView, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(15.999999999999943, -59.400000000000013, 5.0)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line11, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(15.999999999999943, -62.900000000000013, 5.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Destroy()
    
    theSession.UndoToMark(markId89, None)
    
    theSession.DeleteUndoMark(markId89, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines93 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines96)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines97 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines97)
    
    lines98 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines98)
    
    lines99 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines99)
    
    lines100 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines100)
    
    theSession.SetUndoMarkName(markId90, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    point1_45 = NXOpen.Point3d(15.999999999999943, -62.900000000000013, 5.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    point1_46 = NXOpen.Point3d(15.999999999999943, -55.900000000000013, 5.0)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(15.999999999999943, -62.900000000000013, 5.0)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    point1_48 = NXOpen.Point3d(15.999999999999943, -55.900000000000013, 5.0)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits441 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point30 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point30
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder17.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point31 = NXOpen.Point3d(19.471225466186731, -58.978852785472661, 5.0)
    sketchRapidDimensionBuilder17.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point31)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.TextCentered = True
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject15 = sketchRapidDimensionBuilder17.Commit()
    
    theSession.DeleteUndoMark(markId91, None)
    
    theSession.SetUndoMarkName(markId90, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId90, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder17.Destroy()
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines101 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines101)
    
    lines102 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines102)
    
    lines103 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines103)
    
    lines104 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines104)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId92, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits443 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits447 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits451 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits453 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits459 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits461 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    expression45 = workPart.Expressions.FindObject("p15")
    expression45.SetFormula("5.9")
    
    theSession.SetUndoMarkVisibility(markId92, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.84285714285714286)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId93, None)
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId92, "Edit Driving Value")
    
    point1_49 = NXOpen.Point3d(17.857142857142797, -62.428571428571445, 5.0)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(22.914285714285654, -62.428571428571445, 5.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    point1_51 = NXOpen.Point3d(17.857142857142797, -62.428571428571445, 5.0)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(22.914285714285654, -62.428571428571445, 5.0)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    dimensionlinearunits463 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits467 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point32 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point32
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point33 = NXOpen.Point3d(21.797290019109436, -66.155009384915047, 5.0)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point33)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = False
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject16 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId95, None)
    
    theSession.SetUndoMarkName(markId94, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines105 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines105)
    
    lines106 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines106)
    
    lines107 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines107)
    
    lines108 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines108)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId96, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits469 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits471 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits473 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits477 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits479 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits481 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits485 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits487 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression46 = workPart.Expressions.FindObject("p16")
    expression46.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId97, None)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId96, "Edit Driving Value")
    
    scaleAboutPoint184 = NXOpen.Point3d(-1.5837035253941854, -6.1368511609024035, 0.0)
    viewCenter184 = NXOpen.Point3d(1.5837035253941854, 6.1368511609025056, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(-1.794039149860601, -7.7329273700887278, 0.0)
    viewCenter185 = NXOpen.Point3d(1.794039149860601, 7.7329273700888272, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint185, viewCenter185)
    
    scaleAboutPoint186 = NXOpen.Point3d(-2.1652196636248737, -9.6661592126109266, 0.0)
    viewCenter186 = NXOpen.Point3d(2.1652196636248604, 9.6661592126110243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(2.8998477637832925, -11.212744686628678, 0.0)
    viewCenter187 = NXOpen.Point3d(-2.8998477637832925, 11.212744686628778, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(2.4165398031527094, -15.949162700808047, 0.0)
    viewCenter188 = NXOpen.Point3d(-2.4165398031527507, 15.949162700808159, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(1.3593036392733926, -24.01436429383034, 0.0)
    viewCenter189 = NXOpen.Point3d(-1.3593036392734441, 24.014364293830429, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint189, viewCenter189)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder19.Destroy()
    
    theSession.UndoToMark(markId98, None)
    
    theSession.DeleteUndoMark(markId98, None)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines109 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines109)
    
    lines110 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines110)
    
    lines111 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines111)
    
    lines112 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines112)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines113 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines116)
    
    theSession.SetUndoMarkName(markId99, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    point1_53 = NXOpen.Point3d(16.914285714285654, -56.528571428571446, 5.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    point34 = NXOpen.Point3d(19.29670296160306, 0.0, 5.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(line3, workPart.ModelingViews.WorkView, point34)
    
    point1_54 = NXOpen.Point3d(19.29670296160306, 0.0, 5.0)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line3, workPart.ModelingViews.WorkView, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    point1_55 = NXOpen.Point3d(16.914285714285654, -56.528571428571446, 5.0)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point35 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point35
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder20.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point36 = NXOpen.Point3d(12.688976937357262, -22.891081071421773, 5.0)
    sketchRapidDimensionBuilder20.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point36)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.TextCentered = True
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject17 = sketchRapidDimensionBuilder20.Commit()
    
    theSession.DeleteUndoMark(markId100, None)
    
    theSession.SetUndoMarkName(markId99, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId99, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder21 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder21.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId101, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder21.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder21.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    expression47 = workPart.Expressions.FindObject("p17")
    expression47.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId101, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId101, "Edit Driving Value")
    
    point1_56 = NXOpen.Point3d(22.914285714285654, -59.899999999999999, 5.0)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(59.99999999999995, -59.900000000000013, 65.0)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    point1_58 = NXOpen.Point3d(22.914285714285654, -59.899999999999999, 5.0)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(59.99999999999995, -59.900000000000013, 65.0)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    point1_60 = NXOpen.Point3d(22.914285714285654, -59.899999999999999, 5.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    point1_61 = NXOpen.Point3d(59.99999999999995, -59.900000000000013, 65.0)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point37 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point37
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder21.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point38 = NXOpen.Point3d(48.370697468284497, -51.587491233860611, 5.0)
    sketchRapidDimensionBuilder21.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point38)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.TextCentered = False
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject18 = sketchRapidDimensionBuilder21.Commit()
    
    theSession.DeleteUndoMark(markId104, None)
    
    theSession.SetUndoMarkName(markId103, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId103, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder21.Destroy()
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder22 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines121 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines124)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder22.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId105, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder22.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder22.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    expression48 = workPart.Expressions.FindObject("p18")
    expression48.SetFormula("50")
    
    theSession.SetUndoMarkVisibility(markId105, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId106, None)
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId105, "Edit Driving Value")
    
    scaleAboutPoint190 = NXOpen.Point3d(9.4396086060653506, -23.032644998799533, 0.0)
    viewCenter190 = NXOpen.Point3d(-9.4396086060653825, 23.032644998799615, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(11.799510757581729, -29.498776893954339, 0.0)
    viewCenter191 = NXOpen.Point3d(-11.799510757581729, 29.498776893954421, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(15.04437621591674, -37.758434424261587, 0.0)
    viewCenter192 = NXOpen.Point3d(-15.044376215916765, 37.758434424261687, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(18.80547026989592, -47.935512452675795, 0.0)
    viewCenter193 = NXOpen.Point3d(-18.80547026989592, 47.935512452675923, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint193, viewCenter193)
    
    scaleAboutPoint194 = NXOpen.Point3d(24.428674615305923, -65.450411233461224, 0.0)
    viewCenter194 = NXOpen.Point3d(-24.428674615305923, 65.45041123346131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(18.805470269895917, -51.254124853245649, 0.0)
    viewCenter195 = NXOpen.Point3d(-18.805470269895917, 51.254124853245777, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint195, viewCenter195)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Profile...
    # ----------------------------------------------
    sketchRapidDimensionBuilder22.Destroy()
    
    theSession.UndoToMark(markId107, None)
    
    theSession.DeleteUndoMark(markId107, None)
    
    sketchRapidDimensionBuilder22.Destroy()
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId108, "Curve")
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId110, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(60.999999999999943, -108.90000000000001, 5.0)
    endPoint13 = NXOpen.Point3d(60.999999999999943, -99.900000000000006, 5.0)
    line13 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(60.999999999999943, -99.900000000000006, 5.0)
    endPoint14 = NXOpen.Point3d(70.999999999999943, -99.900000000000006, 5.0)
    line14 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(70.999999999999943, -99.900000000000006, 5.0)
    endPoint15 = NXOpen.Point3d(70.999999999999943, -108.90000000000001, 5.0)
    line15 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(70.999999999999943, -108.90000000000001, 5.0)
    endPoint16 = NXOpen.Point3d(60.999999999999943, -108.90000000000001, 5.0)
    line16 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line13
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line14
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line14
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line15
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line15
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line16
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line16
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line13
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom12.Geometry = line13
    geom12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateHorizontalConstraint(geom12)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line13
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line14
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line14
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line15
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line15
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line16
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line16
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line13
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line13
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line13
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(71.03422962062065, -104.40000000000001, 5.0)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_7, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    expression49 = sketchHelpedDimensionalConstraint7.AssociatedExpression
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = line14
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line14
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(65.999999999999943, -109.93422962062071, 5.0)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_9, dimObject2_8, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression50 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line13
    geoms7[1] = line14
    geoms7[2] = line15
    geoms7[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line13
    geoms8[1] = line14
    geoms8[2] = line15
    geoms8[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder23 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines125 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines128)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder23.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines129 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines129)
    
    lines130 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines130)
    
    lines131 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines131)
    
    lines132 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines132)
    
    theSession.SetUndoMarkName(markId111, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder23.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder23.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint196 = NXOpen.Point3d(-34.21858119698711, -72.861978928067245, 0.0)
    viewCenter196 = NXOpen.Point3d(34.21858119698711, 72.861978928067401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(-27.374864957589644, -58.289583142453793, 0.0)
    viewCenter197 = NXOpen.Point3d(27.374864957589686, 58.289583142453893, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(-21.899891966071735, -46.63166651396304, 0.0)
    viewCenter198 = NXOpen.Point3d(21.899891966071749, 46.631666513963154, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(-17.519913572857387, -37.305333211170407, 0.0)
    viewCenter199 = NXOpen.Point3d(17.519913572857401, 37.30533321117052, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(-14.015930858285918, -29.844266568936312, 0.0)
    viewCenter200 = NXOpen.Point3d(14.015930858285939, 29.844266568936426, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(-11.212744686628735, -23.875413255149041, 0.0)
    viewCenter201 = NXOpen.Point3d(11.212744686628735, 23.875413255149148, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint201, viewCenter201)
    
    point1_62 = NXOpen.Point3d(60.999999999999943, -99.900000000000006, 5.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line13, workPart.ModelingViews.WorkView, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    point1_63 = NXOpen.Point3d(70.999999999999943, -99.900000000000006, 5.0)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    point1_64 = NXOpen.Point3d(60.999999999999943, -99.900000000000006, 5.0)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line13, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    point1_65 = NXOpen.Point3d(70.999999999999943, -99.900000000000006, 5.0)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits585 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point39 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point39
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder23.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point40 = NXOpen.Point3d(68.307462351378661, -93.029041465308765, 5.0)
    sketchRapidDimensionBuilder23.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point40)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.TextCentered = False
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject19 = sketchRapidDimensionBuilder23.Commit()
    
    theSession.DeleteUndoMark(markId112, None)
    
    theSession.SetUndoMarkName(markId111, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId111, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder24 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines133 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines133)
    
    lines134 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines134)
    
    lines135 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines135)
    
    lines136 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines136)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder24.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId113, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder24.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits587 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits589 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits591 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits595 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder24.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits597 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits599 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits603 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    expression51 = workPart.Expressions.FindObject("p19")
    expression51.SetFormula("5.9")
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId113, "Edit Driving Value")
    
    point1_66 = NXOpen.Point3d(66.899999999999949, -99.900000000000006, 5.0)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    point1_67 = NXOpen.Point3d(66.899999999999949, -108.90000000000001, 5.0)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    point1_68 = NXOpen.Point3d(66.899999999999949, -99.900000000000006, 5.0)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    point1_69 = NXOpen.Point3d(66.899999999999949, -108.90000000000001, 5.0)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    dimensionlinearunits607 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits609 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point41 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point41
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder24.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point42 = NXOpen.Point3d(70.24069419390085, -104.39644469933927, 5.0)
    sketchRapidDimensionBuilder24.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point42)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.TextCentered = True
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject20 = sketchRapidDimensionBuilder24.Commit()
    
    theSession.DeleteUndoMark(markId116, None)
    
    theSession.SetUndoMarkName(markId115, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId115, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder24.Destroy()
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder25 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines137 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBefore(lines137)
    
    lines138 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAfter(lines138)
    
    lines139 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAbove(lines139)
    
    lines140 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBelow(lines140)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder25.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId117, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder25.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits613 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits615 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits617 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits619 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits621 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder25.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits623 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits625 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits627 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits629 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    expression52 = workPart.Expressions.FindObject("p20")
    expression52.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId117, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId118, None)
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId117, "Edit Driving Value")
    
    scaleAboutPoint202 = NXOpen.Point3d(-10.439451949619839, -19.254989151521006, 0.0)
    viewCenter202 = NXOpen.Point3d(10.439451949619864, 19.254989151521119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(-13.53262289765536, -24.358721215779596, 0.0)
    viewCenter203 = NXOpen.Point3d(13.532622897655376, 24.35872121577972, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(-17.278259592542092, -30.569228509882134, 0.0)
    viewCenter204 = NXOpen.Point3d(17.278259592542142, 30.569228509882258, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(-21.899891966071706, -38.81567058814089, 0.0)
    viewCenter205 = NXOpen.Point3d(21.899891966071742, 38.815670588140989, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(-27.186072785468326, -49.08596475154004, 0.0)
    viewCenter206 = NXOpen.Point3d(27.186072785468394, 49.085964751540153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(-16.283324845462779, -33.27462033638048, 0.0)
    viewCenter207 = NXOpen.Point3d(16.283324845462818, 33.2746203363806, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(-20.059168287888916, -43.068214265173303, 0.0)
    viewCenter208 = NXOpen.Point3d(20.05916828788904, 43.068214265173452, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(-24.705225648686735, -54.941471964989915, 0.0)
    viewCenter209 = NXOpen.Point3d(24.705225648686863, 54.941471964990079, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(-28.116021727050239, -79.738881291470335, 0.0)
    viewCenter210 = NXOpen.Point3d(28.116021727050317, 79.738881291470491, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(-38.601915076073119, -158.44069620776267, 0.0)
    viewCenter211 = NXOpen.Point3d(38.601915076073119, 158.44069620776281, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(-33.18612400569863, -130.90082246692242, 0.0)
    viewCenter212 = NXOpen.Point3d(33.186124005698716, 130.90082246692265, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(-27.286368626907755, -105.82686210706119, 0.0)
    viewCenter213 = NXOpen.Point3d(27.28636862690788, 105.82686210706143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(-22.124082670465729, -84.956477454588466, 0.0)
    viewCenter214 = NXOpen.Point3d(22.124082670465828, 84.956477454588708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(-17.935256351524224, -67.96518196367073, 0.0)
    viewCenter215 = NXOpen.Point3d(17.935256351524302, 67.965181963671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    scaleAboutPoint216 = NXOpen.Point3d(-30.961916227894488, -13.78182856485531, 0.0)
    viewCenter216 = NXOpen.Point3d(30.961916227894552, 13.781828564855649, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    scaleAboutPoint217 = NXOpen.Point3d(-24.467465506921471, -11.025462851884207, 0.0)
    viewCenter217 = NXOpen.Point3d(24.467465506921545, 11.025462851884543, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(-19.45314541537952, -8.8203702815073441, 0.0)
    viewCenter218 = NXOpen.Point3d(19.453145415379666, 8.8203702815076639, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint218, viewCenter218)
    
    point1_70 = NXOpen.Point3d(66.899999999999949, -105.90000000000001, 5.0)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    scaleAboutPoint219 = NXOpen.Point3d(-18.462364096086901, -7.6362657779625014, 0.0)
    viewCenter219 = NXOpen.Point3d(18.462364096087001, 7.636265777962806, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(-22.47382016932044, -11.841045035448273, 0.0)
    viewCenter220 = NXOpen.Point3d(22.473820169320586, 11.841045035448582, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(-24.920566720012577, -22.806094392253829, 0.0)
    viewCenter221 = NXOpen.Point3d(24.920566720012694, 22.806094392254138, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(-30.017955367287886, -31.905877088500858, 0.0)
    viewCenter222 = NXOpen.Point3d(30.017955367288014, 31.905877088501182, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint222, viewCenter222)
    
    point43 = NXOpen.Point3d(120.0, -102.31653372856513, 5.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(edge3, workPart.ModelingViews.WorkView, point43)
    
    point1_71 = NXOpen.Point3d(120.0, -102.31653372856513, 5.0)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(66.899999999999949, -105.90000000000001, 5.0)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    dimensionlinearunits633 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits635 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point44 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point44
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder25.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point45 = NXOpen.Point3d(110.35077170212398, -109.39624018311417, 5.0)
    sketchRapidDimensionBuilder25.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point45)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.TextCentered = False
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject21 = sketchRapidDimensionBuilder25.Commit()
    
    theSession.DeleteUndoMark(markId120, None)
    
    theSession.SetUndoMarkName(markId119, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId119, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder25.Destroy()
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder26 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines141 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines141)
    
    lines142 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines142)
    
    lines143 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines143)
    
    lines144 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines144)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder26.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId121, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder26.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits639 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits641 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits643 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits645 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits647 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder26.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits649 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits651 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits653 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits655 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits657 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    expression53 = workPart.Expressions.FindObject("p21")
    expression53.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId122, None)
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId121, "Edit Driving Value")
    
    scaleAboutPoint223 = NXOpen.Point3d(-24.542982375769974, -12.271491187884836, 0.0)
    viewCenter223 = NXOpen.Point3d(24.542982375770073, 12.271491187885157, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(-20.011970244858599, -10.005985122429147, 0.0)
    viewCenter224 = NXOpen.Point3d(20.011970244858695, 10.005985122429468, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(-16.009576195886869, -8.0047880979432922, 0.0)
    viewCenter225 = NXOpen.Point3d(16.009576195886947, 8.0047880979435888, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint225, viewCenter225)
    
    point1_73 = NXOpen.Point3d(66.0, -99.900000000000006, 5.0)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line14, workPart.ModelingViews.WorkView, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    point1_74 = NXOpen.Point3d(65.999999999999986, -59.900000000000006, 65.0)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    point1_75 = NXOpen.Point3d(66.0, -99.900000000000006, 5.0)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line14, workPart.ModelingViews.WorkView, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    point1_76 = NXOpen.Point3d(65.999999999999986, -59.900000000000006, 65.0)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    dimensionlinearunits659 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits661 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits663 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    point1_77 = NXOpen.Point3d(66.0, -99.900000000000006, 5.0)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line14, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    point1_78 = NXOpen.Point3d(65.999999999999986, -59.900000000000006, 65.0)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin16 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin16.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin16.View = NXOpen.View.Null
    assocOrigin16.ViewOfGeometry = workPart.ModelingViews.WorkView
    point46 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin16.PointOnGeometry = point46
    assocOrigin16.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.DimensionLine = 0
    assocOrigin16.AssociatedView = NXOpen.View.Null
    assocOrigin16.AssociatedPoint = NXOpen.Point.Null
    assocOrigin16.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.XOffsetFactor = 0.0
    assocOrigin16.YOffsetFactor = 0.0
    assocOrigin16.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder26.Origin.SetAssociativeOrigin(assocOrigin16)
    
    point47 = NXOpen.Point3d(68.318082501035974, -74.679247651726953, 5.0)
    sketchRapidDimensionBuilder26.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point47)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.TextCentered = False
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject22 = sketchRapidDimensionBuilder26.Commit()
    
    theSession.DeleteUndoMark(markId124, None)
    
    theSession.SetUndoMarkName(markId123, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId123, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder26.Destroy()
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder27 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines145 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBefore(lines145)
    
    lines146 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAfter(lines146)
    
    lines147 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAbove(lines147)
    
    lines148 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBelow(lines148)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder27.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId125, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder27.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits665 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits667 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits669 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits671 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits673 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder27.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits675 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits679 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits681 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits683 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    expression54 = workPart.Expressions.FindObject("p22")
    expression54.SetFormula("50")
    
    theSession.SetUndoMarkVisibility(markId125, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId126, None)
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId125, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder27.Destroy()
    
    theSession.UndoToMark(markId127, None)
    
    theSession.DeleteUndoMark(markId127, None)
    
    sketchRapidDimensionBuilder27.Destroy()
    
    sketch8 = theSession.ActiveSketch
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies34)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("27")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies35)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId129, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scalar7 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point48 = workPart.Points.CreatePoint(edge5, scalar7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction9 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction9, point48, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder1 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder1.Csys = cartesianCoordinateSystem5
    
    datumCsysBuilder1.DisplayScaleFactor = 1.25
    
    feature8 = datumCsysBuilder1.CommitFeature()
    
    datumCsysBuilder1.Destroy()
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    theSession.BeginTaskEnvironment()
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem5
    
    sketchInPlaceBuilder5.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject23 = sketchInPlaceBuilder5.Commit()
    
    sketchInPlaceBuilder5.Destroy()
    
    sketch9 = nXObject23
    sketch9.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.DeleteUndoMarksUpToMark(markId131, None, True)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_004")
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Dialog Begin Profile
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId133, "Curve")
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    theSession.DeleteUndoMark(markId132, None)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    theSession.Preferences.Sketch.SectionView = False
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.SketchOnly)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    theSession.UndoToMark(markId130, None)
    
    theSession.DeleteUndoMark(markId130, None)
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    datumCsys3 = feature8
    nErrs7 = theSession.UpdateManager.AddToDeleteList(datumCsys3)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    extrudeBuilder4.Destroy()
    
    section4.Destroy()
    
    workPart.Expressions.Delete(expression55)
    
    theSession.UndoToMark(markId129, None)
    
    theSession.DeleteUndoMark(markId129, None)
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies36 = [NXOpen.Body.Null] * 1 
    targetBodies36[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies36)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("27")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies37)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId135, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature7
    features4[0] = sketchFeature4
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section5.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule4
    helpPoint4 = NXOpen.Point3d(9.9999999999999432, -57.959014963491363, 5.0000000000000018)
    section5.AddToSection(rules4, line11, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId137, None)
    
    direction10 = workPart.Directions.CreateDirection(sketch8, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction10
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies38)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies39)
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId136, None)
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies40)
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId138, None)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature9 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId139, None)
    
    theSession.SetUndoMarkName(markId135, "Extrude")
    
    expression59 = extrudeBuilder5.Limits.StartExtend.Value
    expression60 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression56)
    
    workPart.Expressions.Delete(expression57)
    
    workPart.Expressions.Delete(expression58)
    
    scaleAboutPoint226 = NXOpen.Point3d(-48.672981875024767, -65.487284704578755, 0.0)
    viewCenter226 = NXOpen.Point3d(48.672981875024767, 65.487284704578826, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(-61.209962054955398, -81.859105880723448, 0.0)
    viewCenter227 = NXOpen.Point3d(61.209962054955398, 81.859105880723504, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint227, viewCenter227)
    
    scaleAboutPoint228 = NXOpen.Point3d(-49.262957412903845, -65.487284704578769, 0.0)
    viewCenter228 = NXOpen.Point3d(49.262957412903873, 65.487284704578798, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(-39.410365930323039, -52.389827763663021, 0.0)
    viewCenter229 = NXOpen.Point3d(39.410365930323138, 52.389827763663043, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(-31.528292744258426, -41.911862210930394, 0.0)
    viewCenter230 = NXOpen.Point3d(31.528292744258522, 41.91186221093043, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint230, viewCenter230)
    
    scaleAboutPoint231 = NXOpen.Point3d(-25.373667933103768, -33.52948976874432, 0.0)
    viewCenter231 = NXOpen.Point3d(25.373667933103867, 33.529489768744341, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint231, viewCenter231)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin15, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane13
    
    expression61 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression62 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId140, "Create Sketch Dialog")
    
    scalar8 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude3 = feature9
    edge7 = extrude3.FindObject("EDGE * 150 * 230 {(3.9999999999999,-59.9,25)(6.9999999999999,-59.9,25)(9.9999999999999,-59.9,25) EXTRUDE(2)}")
    point49 = workPart.Points.CreatePoint(edge7, scalar8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge8 = extrude3.FindObject("EDGE * 230 EXTRUDE(2) 140 {(3.9999999999999,-59.9,5)(6.9999999999999,-59.9,5)(9.9999999999999,-59.9,5) EXTRUDE(2)}")
    direction11 = workPart.Directions.CreateDirection(edge8, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude3.FindObject("FACE 230 {(6.9999999999999,-59.9,15) EXTRUDE(2)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction11, point49, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem6
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin16, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = face3
    plane14.SetGeometry(geom13)
    
    plane14.SetFlip(False)
    
    plane14.SetExpression(None)
    
    plane14.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane14.Evaluate()
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin17, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane15.SynchronizeToPlane(plane14)
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point50 = workPart.Points.CreatePoint(edge7, scalar9, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom14 = [NXOpen.NXObject.Null] * 1 
    geom14[0] = face3
    plane15.SetGeometry(geom14)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId141, None)
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject24 = sketchInPlaceBuilder6.Commit()
    
    sketch10 = nXObject24
    feature10 = sketch10.Feature
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId143)
    
    sketch10.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId142, None)
    
    theSession.SetUndoMarkName(markId140, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression62)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point50)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression61)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression64)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression63)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    scaleAboutPoint232 = NXOpen.Point3d(2.658193783468084, -7.1287924193005718, 0.0)
    viewCenter232 = NXOpen.Point3d(-2.6581937834679503, 7.1287924193006029, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(4.9841133440025995, -7.2496194094582211, 0.0)
    viewCenter233 = NXOpen.Point3d(-4.9841133440024716, 7.249619409458246, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint233, viewCenter233)
    
    scaleAboutPoint234 = NXOpen.Point3d(6.7965181963671748, -8.1180634012162241, 0.0)
    viewCenter234 = NXOpen.Point3d(-6.7965181963670132, 8.118063401216256, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(5.4372145570937791, -6.4944507209729805, 0.0)
    viewCenter235 = NXOpen.Point3d(-5.437214557093573, 6.4944507209730062, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint235, viewCenter235)
    
    scaleAboutPoint236 = NXOpen.Point3d(4.3497716456750437, -4.9539065964631028, 0.0)
    viewCenter236 = NXOpen.Point3d(-4.3497716456748377, 4.9539065964631339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint236, viewCenter236)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId145, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(6.4999999999999432, -59.899999999999999, 18.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.9380778288524121, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = arc2
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(6.4999999999999432, -59.899999999999999, 19.096005454028333)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_10, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension10 = sketchDimensionalConstraint10.AssociatedDimension
    
    expression65 = sketchDimensionalConstraint10.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder28 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines149 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines149)
    
    lines150 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines150)
    
    lines151 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines151)
    
    lines152 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines152)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder28.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines153 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines153)
    
    lines154 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines154)
    
    lines155 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines155)
    
    lines156 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines156)
    
    theSession.SetUndoMarkName(markId146, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder28.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits685 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits687 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits689 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits693 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits694 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder28.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits695 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits696 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits697 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits698 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits699 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits700 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits701 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits702 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits703 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits704 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    point1_79 = NXOpen.Point3d(6.4999999999999432, -59.899999999999999, 18.0)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    point1_80 = NXOpen.Point3d(6.4999999999999432, -59.899999999999999, 18.0)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    point1_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    dimensionlinearunits705 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits706 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits707 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits708 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits709 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits710 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin17 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin17.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin17.View = NXOpen.View.Null
    assocOrigin17.ViewOfGeometry = workPart.ModelingViews.WorkView
    point51 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin17.PointOnGeometry = point51
    assocOrigin17.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.DimensionLine = 0
    assocOrigin17.AssociatedView = NXOpen.View.Null
    assocOrigin17.AssociatedPoint = NXOpen.Point.Null
    assocOrigin17.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.XOffsetFactor = 0.0
    assocOrigin17.YOffsetFactor = 0.0
    assocOrigin17.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder28.Origin.SetAssociativeOrigin(assocOrigin17)
    
    point52 = NXOpen.Point3d(-3.1000960091381398, -59.899999999999999, 17.91500736463156)
    sketchRapidDimensionBuilder28.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point52)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.TextCentered = False
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject25 = sketchRapidDimensionBuilder28.Commit()
    
    theSession.DeleteUndoMark(markId147, None)
    
    theSession.SetUndoMarkName(markId146, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder28.Destroy()
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder29 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines157 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBefore(lines157)
    
    lines158 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAfter(lines158)
    
    lines159 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAbove(lines159)
    
    lines160 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBelow(lines160)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder29.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId148, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder29.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits711 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits712 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits713 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits714 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits715 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits716 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits717 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits718 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits719 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits720 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder29.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits721 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits722 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits723 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits724 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits725 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits726 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits727 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits728 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits729 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits730 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    expression66 = workPart.Expressions.FindObject("p25")
    expression66.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId148, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.77396272619766626)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId149, None)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId148, "Edit Driving Value")
    
    scaleAboutPoint237 = NXOpen.Point3d(3.6731405007922691, -5.0264027905576967, 0.0)
    viewCenter237 = NXOpen.Point3d(-3.6731405007920546, 5.0264027905577127, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint237, viewCenter237)
    
    scaleAboutPoint238 = NXOpen.Point3d(2.0878903899240906, -4.1757807798479307, 0.0)
    viewCenter238 = NXOpen.Point3d(-2.0878903899238663, 4.1757807798479503, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint238, viewCenter238)
    
    scaleAboutPoint239 = NXOpen.Point3d(1.237268379214304, -3.588078299721182, 0.0)
    viewCenter239 = NXOpen.Point3d(-1.2372683792140931, 3.5880782997212028, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint239, viewCenter239)
    
    scaleAboutPoint240 = NXOpen.Point3d(0.69287029236005926, -2.9694441101140892, 0.0)
    viewCenter240 = NXOpen.Point3d(-0.69287029235984821, 2.9694441101140976, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint240, viewCenter240)
    
    point1_82 = NXOpen.Point3d(5.9349068154941085, -59.899999999999999, 19.582260916616335)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    point1_83 = NXOpen.Point3d(5.9349068154941085, -59.899999999999999, 19.582260916616335)
    point2_83 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_83, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_83)
    
    point1_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_84, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_84)
    
    dimensionlinearunits731 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits732 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits733 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits734 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits735 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits736 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    edge9 = extrude3.FindObject("EDGE * 200 * 230 {(9.9999999999999,-59.9,25)(9.9999999999999,-59.9,15)(9.9999999999999,-59.9,5) EXTRUDE(2)}")
    point53 = NXOpen.Point3d(9.9999999999999432, -59.899999999999999, 20.895896207253379)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(edge9, workPart.ModelingViews.WorkView, point53)
    
    point1_85 = NXOpen.Point3d(9.9999999999999432, -59.899999999999999, 20.895896207253379)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge9, workPart.ModelingViews.WorkView, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    point1_86 = NXOpen.Point3d(5.9349068154941085, -59.899999999999999, 19.582260916616335)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    point1_87 = NXOpen.Point3d(9.9999999999999432, -59.899999999999999, 20.895896207253379)
    point2_87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge9, workPart.ModelingViews.WorkView, point1_87, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_87)
    
    point1_88 = NXOpen.Point3d(5.9349068154941085, -59.899999999999999, 19.582260916616335)
    point2_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_88, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_88)
    
    dimensionlinearunits737 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits738 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits739 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits740 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits741 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits742 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits743 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits744 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits745 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits746 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits747 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits748 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin18 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin18.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin18.View = NXOpen.View.Null
    assocOrigin18.ViewOfGeometry = workPart.ModelingViews.WorkView
    point54 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin18.PointOnGeometry = point54
    assocOrigin18.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.DimensionLine = 0
    assocOrigin18.AssociatedView = NXOpen.View.Null
    assocOrigin18.AssociatedPoint = NXOpen.Point.Null
    assocOrigin18.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.XOffsetFactor = 0.0
    assocOrigin18.YOffsetFactor = 0.0
    assocOrigin18.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder29.Origin.SetAssociativeOrigin(assocOrigin18)
    
    point55 = NXOpen.Point3d(12.764468466241208, -59.899999999999999, 19.233007505589487)
    sketchRapidDimensionBuilder29.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point55)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.TextCentered = False
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject26 = sketchRapidDimensionBuilder29.Commit()
    
    theSession.DeleteUndoMark(markId151, None)
    
    theSession.SetUndoMarkName(markId150, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId150, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder29.Destroy()
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder30 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines161 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBefore(lines161)
    
    lines162 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAfter(lines162)
    
    lines163 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAbove(lines163)
    
    lines164 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBelow(lines164)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder30.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId152, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder30.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits749 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits750 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits751 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits752 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits753 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits754 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits755 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits756 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits757 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits758 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder30.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits759 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits760 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits761 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits762 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits763 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits764 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits765 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits766 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits767 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits768 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    expression67 = workPart.Expressions.FindObject("p26")
    expression67.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId152, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId153, None)
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId152, "Edit Driving Value")
    
    point1_89 = NXOpen.Point3d(6.9999999999999432, -59.899999999999999, 19.582260916616335)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    point1_90 = NXOpen.Point3d(6.9999999999999432, -59.899999999999999, 19.582260916616335)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    point1_91 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_91 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_91, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_91)
    
    dimensionlinearunits769 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits770 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits771 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits772 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits773 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits774 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    point56 = NXOpen.Point3d(7.6966171849798197, -59.899999999999999, 25.0)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(edge7, workPart.ModelingViews.WorkView, point56)
    
    point1_92 = NXOpen.Point3d(7.6966171849798197, -59.899999999999999, 25.0)
    point2_92 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge7, workPart.ModelingViews.WorkView, point1_92, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_92)
    
    point1_93 = NXOpen.Point3d(6.9999999999999432, -59.899999999999999, 19.582260916616335)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    point1_94 = NXOpen.Point3d(7.6966171849798197, -59.899999999999999, 25.0)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge7, workPart.ModelingViews.WorkView, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    point1_95 = NXOpen.Point3d(6.9999999999999432, -59.899999999999999, 19.582260916616335)
    point2_95 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_95, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_95)
    
    dimensionlinearunits775 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits776 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits777 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits778 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits779 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits780 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits781 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits782 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits783 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits784 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits785 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits786 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin19 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin19.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin19.View = NXOpen.View.Null
    assocOrigin19.ViewOfGeometry = workPart.ModelingViews.WorkView
    point57 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin19.PointOnGeometry = point57
    assocOrigin19.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.DimensionLine = 0
    assocOrigin19.AssociatedView = NXOpen.View.Null
    assocOrigin19.AssociatedPoint = NXOpen.Point.Null
    assocOrigin19.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.XOffsetFactor = 0.0
    assocOrigin19.YOffsetFactor = 0.0
    assocOrigin19.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder30.Origin.SetAssociativeOrigin(assocOrigin19)
    
    point58 = NXOpen.Point3d(-1.5284558504412953, -59.899999999999999, 23.35063667161436)
    sketchRapidDimensionBuilder30.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point58)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.TextCentered = False
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject27 = sketchRapidDimensionBuilder30.Commit()
    
    theSession.DeleteUndoMark(markId155, None)
    
    theSession.SetUndoMarkName(markId154, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId154, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder30.Destroy()
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder31 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines165 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBefore(lines165)
    
    lines166 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAfter(lines166)
    
    lines167 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAbove(lines167)
    
    lines168 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBelow(lines168)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder31.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId156, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder31.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits787 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits788 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits789 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits790 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits791 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits792 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits793 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits794 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits795 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits796 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder31.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits797 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits798 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits799 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits800 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits801 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits802 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits803 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits804 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits805 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits806 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    expression68 = workPart.Expressions.FindObject("p27")
    expression68.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId157, None)
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId156, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder31.Destroy()
    
    theSession.UndoToMark(markId158, None)
    
    theSession.DeleteUndoMark(markId158, None)
    
    sketchRapidDimensionBuilder31.Destroy()
    
    sketch11 = theSession.ActiveSketch
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression69 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies41)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies42)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId160, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features5 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature5 = feature10
    features5[0] = sketchFeature5
    curveFeatureRule5 = workPart.ScRuleFactory.CreateRuleCurveFeature(features5)
    
    section6.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule5
    helpPoint5 = NXOpen.Point3d(5.6586954394789775, -59.899999999999999, 20.340476809543816)
    section6.AddToSection(rules5, arc2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId162, None)
    
    direction12 = workPart.Directions.CreateDirection(sketch11, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction12
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies43)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies44)
    
    expression70 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId161, None)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies45)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies46 = [NXOpen.Body.Null] * 1 
    targetBodies46[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies46)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies47)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies48 = [NXOpen.Body.Null] * 1 
    targetBodies48[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies50)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies51)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies52)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies53 = [NXOpen.Body.Null] * 1 
    targetBodies53[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies53)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies54 = [NXOpen.Body.Null] * 1 
    targetBodies54[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies54)
    
    targetBodies55 = []
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies55)
    
    direction13 = extrudeBuilder6.Direction
    
    success2 = direction13.ReverseDirection()
    
    extrudeBuilder6.Direction = direction13
    
    targetBodies56 = [NXOpen.Body.Null] * 1 
    targetBodies56[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies56)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies57 = [NXOpen.Body.Null] * 1 
    targetBodies57[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies57)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies58 = [NXOpen.Body.Null] * 1 
    targetBodies58[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies58)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies59 = [NXOpen.Body.Null] * 1 
    targetBodies59[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies59)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies60 = [NXOpen.Body.Null] * 1 
    targetBodies60[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies60)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies61 = [NXOpen.Body.Null] * 1 
    targetBodies61[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies61)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies62 = [NXOpen.Body.Null] * 1 
    targetBodies62[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies62)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies63 = [NXOpen.Body.Null] * 1 
    targetBodies63[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies63)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies64 = [NXOpen.Body.Null] * 1 
    targetBodies64[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies64)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies65 = [NXOpen.Body.Null] * 1 
    targetBodies65[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies65)
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId163, None)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    feature11 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId164, None)
    
    theSession.SetUndoMarkName(markId160, "Extrude")
    
    expression71 = extrudeBuilder6.Limits.StartExtend.Value
    expression72 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression69)
    
    workPart.Expressions.Delete(expression70)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.92424411121408812
    rotMatrix5.Xy = 0.26349453879178286
    rotMatrix5.Xz = 0.27630318657769209
    rotMatrix5.Yx = -0.35635035392451203
    rotMatrix5.Yy = 0.33553054977058971
    rotMatrix5.Yz = 0.87202848315208203
    rotMatrix5.Zx = 0.13706658288567708
    rotMatrix5.Zy = -0.90442792869169653
    rotMatrix5.Zz = 0.4040085069135208
    translation5 = NXOpen.Point3d(-35.791588265537143, -13.248858882333312, 14.816480091054629)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 2.1897701249376818)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.86630589635048438
    rotMatrix6.Xy = 0.46829306206938281
    rotMatrix6.Xz = 0.17382664342978582
    rotMatrix6.Yx = -0.35635035392451203
    rotMatrix6.Yy = 0.33553054977058971
    rotMatrix6.Yz = 0.87202848315208203
    rotMatrix6.Zx = 0.35004073935223545
    rotMatrix6.Zy = -0.81738660264793184
    rotMatrix6.Zz = 0.45754849208079945
    translation6 = NXOpen.Point3d(-16.696896324757969, -13.248858882333312, 5.5204607477504624)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 2.1897701249376818)
    
    scaleAboutPoint241 = NXOpen.Point3d(-41.56448461422714, -16.311643671281004, 0.0)
    viewCenter241 = NXOpen.Point3d(41.564484614227275, 16.311643671281036, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint241, viewCenter241)
    
    scaleAboutPoint242 = NXOpen.Point3d(-51.955605767783936, -20.389554589101269, 0.0)
    viewCenter242 = NXOpen.Point3d(51.955605767784093, 20.389554589101294, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint242, viewCenter242)
    
    scaleAboutPoint243 = NXOpen.Point3d(-64.944507209729935, -25.675735408497882, 0.0)
    viewCenter243 = NXOpen.Point3d(64.944507209730105, 25.675735408497918, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint243, viewCenter243)
    
    scaleAboutPoint244 = NXOpen.Point3d(-81.180634012162415, -32.802639906077289, 0.0)
    viewCenter244 = NXOpen.Point3d(81.180634012162656, 32.802639906077303, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint244, viewCenter244)
    
    scaleAboutPoint245 = NXOpen.Point3d(-131.5645449470365, -34.513568965926652, 0.0)
    viewCenter245 = NXOpen.Point3d(131.56454494703681, 34.51356896592668, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint245, viewCenter245)
    
    scaleAboutPoint246 = NXOpen.Point3d(-104.30767509702264, -28.554816033347851, 0.0)
    viewCenter246 = NXOpen.Point3d(104.30767509702291, 28.554816033347873, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint246, viewCenter246)
    
    scaleAboutPoint247 = NXOpen.Point3d(-83.257347905496772, -22.843852826678262, 0.0)
    viewCenter247 = NXOpen.Point3d(83.257347905497056, 22.843852826678294, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint247, viewCenter247)
    
    scaleAboutPoint248 = NXOpen.Point3d(-66.605878324397381, -18.275082261342611, 0.0)
    viewCenter248 = NXOpen.Point3d(66.605878324397679, 18.275082261342636, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint248, viewCenter248)
    
    scaleAboutPoint249 = NXOpen.Point3d(-53.043048679202613, -14.620065809074083, 0.0)
    viewCenter249 = NXOpen.Point3d(53.043048679202911, 14.620065809074115, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint249, viewCenter249)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.79322280400377254
    rotMatrix7.Xy = -0.36986617788444281
    rotMatrix7.Xz = 0.48373194402018532
    rotMatrix7.Yx = -0.35979052882066909
    rotMatrix7.Yy = 0.35622249778724985
    rotMatrix7.Yz = 0.86235509359031248
    rotMatrix7.Zx = -0.49127218380378196
    rotMatrix7.Zy = -0.85808189733111606
    rotMatrix7.Zz = 0.1494894608101065
    translation7 = NXOpen.Point3d(-44.82899636071744, -11.519962561272209, 63.569436972417975)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 2.737212656172102)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin18, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane16
    
    expression73 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId165, "Create Sketch Dialog")
    
    scalar10 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge10 = extrude3.FindObject("EDGE * 220 * 230 {(3.9999999999999,-59.9,25)(3.9999999999999,-59.9,15)(3.9999999999999,-59.9,5) EXTRUDE(2)}")
    point59 = workPart.Points.CreatePoint(edge10, scalar10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction14 = workPart.Directions.CreateDirection(edge10, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face4 = extrude3.FindObject("FACE 220 {(3.9999999999999,-56.95,15) EXTRUDE(2)}")
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction14, point59, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.Csystem = cartesianCoordinateSystem7
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin19, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane17.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom15 = [NXOpen.NXObject.Null] * 1 
    geom15[0] = face4
    plane17.SetGeometry(geom15)
    
    plane17.SetFlip(False)
    
    plane17.SetExpression(None)
    
    plane17.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane17.Evaluate()
    
    origin20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal18 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane18 = workPart.Planes.CreatePlane(origin20, normal18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression75 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression76 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane18.SynchronizeToPlane(plane17)
    
    scalar11 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point60 = workPart.Points.CreatePoint(edge10, scalar11, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane18.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom16 = [NXOpen.NXObject.Null] * 1 
    geom16[0] = face4
    plane18.SetGeometry(geom16)
    
    plane18.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane18.Evaluate()
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId166, None)
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject28 = sketchInPlaceBuilder7.Commit()
    
    sketch12 = nXObject28
    feature12 = sketch12.Feature
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId168)
    
    sketch12.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId167, None)
    
    theSession.SetUndoMarkName(markId165, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression74)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point60)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression73)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression76)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression75)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane18.DestroyPlane()
    
    scaleAboutPoint250 = NXOpen.Point3d(-17.979056135456272, 15.659177924429809, 0.0)
    viewCenter250 = NXOpen.Point3d(17.979056135456577, -15.659177924429775, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint250, viewCenter250)
    
    scaleAboutPoint251 = NXOpen.Point3d(-21.628031238216924, 18.365702503960879, 0.0)
    viewCenter251 = NXOpen.Point3d(21.628031238217226, -18.365702503960847, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint251, viewCenter251)
    
    scaleAboutPoint252 = NXOpen.Point3d(-25.373667933103672, 21.295757015283581, 0.0)
    viewCenter252 = NXOpen.Point3d(25.373667933103981, -21.295757015283556, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint252, viewCenter252)
    
    scaleAboutPoint253 = NXOpen.Point3d(-26.997280613346938, 24.542982375770087, 0.0)
    viewCenter253 = NXOpen.Point3d(26.997280613347211, -24.542982375770055, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint253, viewCenter253)
    
    scaleAboutPoint254 = NXOpen.Point3d(-31.858679045470616, 29.734767109106063, 0.0)
    viewCenter254 = NXOpen.Point3d(31.858679045470879, -29.734767109106002, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint254, viewCenter254)
    
    scaleAboutPoint255 = NXOpen.Point3d(-37.168458886382396, 36.28349557956394, 0.0)
    viewCenter255 = NXOpen.Point3d(37.168458886382702, -36.283495579563919, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint255, viewCenter255)
    
    scaleAboutPoint256 = NXOpen.Point3d(-44.985634763280359, 61.947431477304278, 0.0)
    viewCenter256 = NXOpen.Point3d(44.985634763280615, -61.947431477304221, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint256, viewCenter256)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint257 = NXOpen.Point3d(-37.168458886382446, 31.858679045470808, 0.0)
    viewCenter257 = NXOpen.Point3d(37.168458886382652, -31.85867904547073, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint257, viewCenter257)
    
    scaleAboutPoint258 = NXOpen.Point3d(-30.442737754560827, 21.475109578798854, 0.0)
    viewCenter258 = NXOpen.Point3d(30.442737754561069, -21.475109578798772, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint258, viewCenter258)
    
    scaleAboutPoint259 = NXOpen.Point3d(-26.242111924861728, 14.914581597583416, 0.0)
    viewCenter259 = NXOpen.Point3d(26.242111924861952, -14.914581597583302, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint259, viewCenter259)
    
    scaleAboutPoint260 = NXOpen.Point3d(-21.446790752980498, 11.176496589581497, 0.0)
    viewCenter260 = NXOpen.Point3d(21.446790752980714, -11.176496589581394, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint260, viewCenter260)
    
    scaleAboutPoint261 = NXOpen.Point3d(-17.519913572857295, 8.2162353307193943, 0.0)
    viewCenter261 = NXOpen.Point3d(17.519913572857501, -8.2162353307192912, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint261, viewCenter261)
    
    scaleAboutPoint262 = NXOpen.Point3d(-21.845519820500712, 9.6661592126110367, 0.0)
    viewCenter262 = NXOpen.Point3d(21.845519820500911, -9.6661592126109213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint262, viewCenter262)
    
    scaleAboutPoint263 = NXOpen.Point3d(-17.70840367750322, 7.7329273700888432, 0.0)
    viewCenter263 = NXOpen.Point3d(17.708403677503405, -7.7329273700887313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint263, viewCenter263)
    
    scaleAboutPoint264 = NXOpen.Point3d(-14.228586360963265, 6.1863418960710863, 0.0)
    viewCenter264 = NXOpen.Point3d(14.228586360963465, -6.18634189607097, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint264, viewCenter264)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    scaleAboutPoint265 = NXOpen.Point3d(18.70749789371888, 5.0975457223625904, 0.0)
    viewCenter265 = NXOpen.Point3d(-18.707497893718688, -5.0975457223624687, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint265, viewCenter265)
    
    scaleAboutPoint266 = NXOpen.Point3d(23.755552880912841, 6.3719321529532174, 0.0)
    viewCenter266 = NXOpen.Point3d(-23.755552880912642, -6.3719321529530957, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint266, viewCenter266)
    
    scaleAboutPoint267 = NXOpen.Point3d(32.091648585868555, 7.8875859174906253, 0.0)
    viewCenter267 = NXOpen.Point3d(-32.091648585868356, -7.8875859174905001, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint267, viewCenter267)
    
    scaleAboutPoint268 = NXOpen.Point3d(43.787701233127827, 9.7628208047371547, 0.0)
    viewCenter268 = NXOpen.Point3d(-43.787701233127628, -9.7628208047370215, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint268, viewCenter268)
    
    theSession.SetUndoMarkVisibility(markId170, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(3.9999999999999427, -55.450354840974555, 5.0)
    endPoint17 = NXOpen.Point3d(3.9999999999999427, -55.450354840974555, 65.0)
    line17 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(3.9999999999999427, -55.450354840974555, 65.0)
    endPoint18 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 65.0)
    line18 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 65.0)
    endPoint19 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 5.0)
    line19 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 5.0)
    endPoint20 = NXOpen.Point3d(3.9999999999999427, -55.450354840974555, 5.0)
    line20 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line17
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line18
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line18
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line19
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line19
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line20
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line20
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line17
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint41 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    geom17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom17.Geometry = line17
    geom17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint42 = theSession.ActiveSketch.CreateHorizontalConstraint(geom17)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line17
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line18
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint43 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line18
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_18.Geometry = line19
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint44 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_18, conGeom2_18)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line19
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line20
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint45 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line20
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = line17
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint46 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_20, conGeom2_20)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line17
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_21.Geometry = edge2
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = 3.9999999999999427
    help1.Point.Y = -55.450354840974555
    help1.Point.Z = 5.0
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_21, conGeom2_21, help1)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line19
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_22.SplineDefiningPointIndex = 0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    edge11 = extrude2.FindObject("EDGE * 130 * 150 {(60,-59.9,65)(60,-56.95,65)(60,-54,65) EXTRUDE(2)}")
    conGeom2_22.Geometry = edge11
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = 3.9999999999999427
    help2.Point.Y = -58.5037012130541
    help2.Point.Z = 65.0
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_22, conGeom2_22, help2)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = line17
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line17
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(3.9999999999999427, -59.560375293580798, 35.0)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_11, dimObject2_9, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint11
    dimension11 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression77 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = line18
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line18
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(3.9999999999999427, -56.977028027014327, 60.889979547393757)
    sketchDimensionalConstraint12 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_12, dimObject2_10, dimOrigin12, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint12
    dimension12 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression78 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line17
    geoms9[1] = line18
    geoms9[2] = line19
    geoms9[3] = line20
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line17
    geoms10[1] = line18
    geoms10[2] = line19
    geoms10[3] = line20
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    scaleAboutPoint269 = NXOpen.Point3d(77.81258166151845, 14.378411828758901, 0.0)
    viewCenter269 = NXOpen.Point3d(-77.812581661518237, -14.378411828758757, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint269, viewCenter269)
    
    scaleAboutPoint270 = NXOpen.Point3d(62.250065329214777, 11.40606787088103, 0.0)
    viewCenter270 = NXOpen.Point3d(-62.250065329214564, -11.406067870880889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint270, viewCenter270)
    
    scaleAboutPoint271 = NXOpen.Point3d(49.800052263371889, 9.047525023003951, 0.0)
    viewCenter271 = NXOpen.Point3d(-49.800052263371661, -9.0475250230038053, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint271, viewCenter271)
    
    scaleAboutPoint272 = NXOpen.Point3d(39.840041810697521, 7.1142931804817575, 0.0)
    viewCenter272 = NXOpen.Point3d(-39.840041810697301, -7.1142931804816092, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint272, viewCenter272)
    
    scaleAboutPoint273 = NXOpen.Point3d(31.971014918895182, 5.5429623388797182, 0.0)
    viewCenter273 = NXOpen.Point3d(-31.971014918894955, -5.5429623388795664, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint273, viewCenter273)
    
    scaleAboutPoint274 = NXOpen.Point3d(25.378848994441899, 4.078036577890094, 0.0)
    viewCenter274 = NXOpen.Point3d(-25.378848994441675, -4.0780365778899519, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint274, viewCenter274)
    
    scaleAboutPoint275 = NXOpen.Point3d(20.271405125045654, 3.1990811212963286, 0.0)
    viewCenter275 = NXOpen.Point3d(-20.271405125045426, -3.1990811212961718, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint275, viewCenter275)
    
    scaleAboutPoint276 = NXOpen.Point3d(16.217124100036546, 2.5339256406307711, 0.0)
    viewCenter276 = NXOpen.Point3d(-16.217124100036319, -2.5339256406306156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint276, viewCenter276)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder32 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines169 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBefore(lines169)
    
    lines170 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAfter(lines170)
    
    lines171 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAbove(lines171)
    
    lines172 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBelow(lines172)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder32.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines173 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBefore(lines173)
    
    lines174 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAfter(lines174)
    
    lines175 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAbove(lines175)
    
    lines176 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBelow(lines176)
    
    theSession.SetUndoMarkName(markId171, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder32.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits807 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits808 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits809 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits810 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits811 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits812 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits813 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits814 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits815 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits816 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder32.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits817 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits818 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits819 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits820 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits821 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits822 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits823 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits824 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits825 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits826 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    edge12 = extrude2.FindObject("EDGE * 150 * 160 {(60,-54,65)(60,-54,35)(60,-54,5) EXTRUDE(2)}")
    point61 = NXOpen.Point3d(59.99999999999995, -53.999999999999986, 62.509464589597535)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(edge12, workPart.ModelingViews.WorkView, point61)
    
    point1_96 = NXOpen.Point3d(3.9999999999999427, -55.450354840974555, 65.0)
    point2_96 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line17, workPart.ModelingViews.WorkView, point1_96, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_96)
    
    dimensionlinearunits827 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits828 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits829 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits830 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits831 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits832 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin20 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin20.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin20.View = NXOpen.View.Null
    assocOrigin20.ViewOfGeometry = workPart.ModelingViews.WorkView
    point62 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin20.PointOnGeometry = point62
    assocOrigin20.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.DimensionLine = 0
    assocOrigin20.AssociatedView = NXOpen.View.Null
    assocOrigin20.AssociatedPoint = NXOpen.Point.Null
    assocOrigin20.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.XOffsetFactor = 0.0
    assocOrigin20.YOffsetFactor = 0.0
    assocOrigin20.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder32.Origin.SetAssociativeOrigin(assocOrigin20)
    
    point63 = NXOpen.Point3d(3.9999999999999427, -54.900034569023177, 65.89478924548014)
    sketchRapidDimensionBuilder32.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point63)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.TextCentered = False
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject29 = sketchRapidDimensionBuilder32.Commit()
    
    theSession.DeleteUndoMark(markId172, None)
    
    theSession.SetUndoMarkName(markId171, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId171, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder32.Destroy()
    
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder33 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines177 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBefore(lines177)
    
    lines178 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAfter(lines178)
    
    lines179 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAbove(lines179)
    
    lines180 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBelow(lines180)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder33.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId173, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder33.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits833 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits834 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits835 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits836 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits837 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits838 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits839 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits840 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits841 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits842 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder33.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits843 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits844 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits845 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits846 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits847 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits848 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits849 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits850 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits851 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits852 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    point64 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 61.61752276409554)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(line19, workPart.ModelingViews.WorkView, point64)
    
    point1_97 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 65.0)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line19, workPart.ModelingViews.WorkView, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 5.0)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line19, workPart.ModelingViews.WorkView, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    dimensionlinearunits853 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits854 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits855 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits856 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits857 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits858 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    edge13 = extrude2.FindObject("EDGE * 140 * 150 {(60,-59.9,65)(60,-59.9,35)(60,-59.9,5) EXTRUDE(2)}")
    point1_99 = NXOpen.Point3d(59.99999999999995, -59.900000000000013, 65.0)
    point2_99 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge13, workPart.ModelingViews.WorkView, point1_99, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_99)
    
    point1_100 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 61.61752276409554)
    point2_100 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line19, workPart.ModelingViews.WorkView, point1_100, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_100)
    
    point1_101 = NXOpen.Point3d(59.99999999999995, -59.900000000000013, 65.0)
    point2_101 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge13, workPart.ModelingViews.WorkView, point1_101, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_101)
    
    point1_102 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 61.61752276409554)
    point2_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line19, workPart.ModelingViews.WorkView, point1_102, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_102)
    
    point1_103 = NXOpen.Point3d(59.99999999999995, -59.900000000000013, 65.0)
    point2_103 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge13, workPart.ModelingViews.WorkView, point1_103, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_103)
    
    dimensionlinearunits859 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits860 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits861 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits862 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits863 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits864 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits865 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits866 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits867 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits868 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits869 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits870 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin21 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin21.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin21.View = NXOpen.View.Null
    assocOrigin21.ViewOfGeometry = workPart.ModelingViews.WorkView
    point65 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin21.PointOnGeometry = point65
    assocOrigin21.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.DimensionLine = 0
    assocOrigin21.AssociatedView = NXOpen.View.Null
    assocOrigin21.AssociatedPoint = NXOpen.Point.Null
    assocOrigin21.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.XOffsetFactor = 0.0
    assocOrigin21.YOffsetFactor = 0.0
    assocOrigin21.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder33.Origin.SetAssociativeOrigin(assocOrigin21)
    
    point66 = NXOpen.Point3d(3.9999999999999427, -59.380015101658238, 67.029987932482697)
    sketchRapidDimensionBuilder33.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point66)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.TextCentered = False
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject30 = sketchRapidDimensionBuilder33.Commit()
    
    theSession.DeleteUndoMark(markId174, None)
    
    theSession.SetUndoMarkName(markId173, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId173, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder33.Destroy()
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder34 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines181 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBefore(lines181)
    
    lines182 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAfter(lines182)
    
    lines183 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAbove(lines183)
    
    lines184 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBelow(lines184)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder34.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId175, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder34.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits871 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits872 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits873 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits874 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits875 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits876 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits877 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits878 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits879 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits880 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder34.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits881 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits882 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits883 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits884 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits885 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits886 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits887 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits888 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits889 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits890 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    expression79 = workPart.Expressions.FindObject("p31")
    expression79.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId175, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId176, None)
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId175, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder34.Destroy()
    
    theSession.UndoToMark(markId177, None)
    
    theSession.DeleteUndoMark(markId177, None)
    
    sketchRapidDimensionBuilder34.Destroy()
    
    sketch13 = theSession.ActiveSketch
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    scaleAboutPoint277 = NXOpen.Point3d(4.5430948299273073, -9.0861896598543019, 0.0)
    viewCenter277 = NXOpen.Point3d(-4.5430948299270026, 9.0861896598543339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint277, viewCenter277)
    
    scaleAboutPoint278 = NXOpen.Point3d(5.5580415472514844, -11.720218045290792, 0.0)
    viewCenter278 = NXOpen.Point3d(-5.5580415472511451, 11.720218045290833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint278, viewCenter278)
    
    scaleAboutPoint279 = NXOpen.Point3d(6.7965181963672654, -14.801306294310539, 0.0)
    viewCenter279 = NXOpen.Point3d(-6.7965181963669439, 14.80130629431059, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint279, viewCenter279)
    
    scaleAboutPoint280 = NXOpen.Point3d(5.4372145570938546, -11.961872025606073, 0.0)
    viewCenter280 = NXOpen.Point3d(-5.4372145570935144, 11.961872025606114, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint280, viewCenter280)
    
    scaleAboutPoint281 = NXOpen.Point3d(4.253110053548987, -9.5694976204848494, 0.0)
    viewCenter281 = NXOpen.Point3d(-4.2531100535486406, 9.5694976204848903, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint281, viewCenter281)
    
    scaleAboutPoint282 = NXOpen.Point3d(2.4745367584285747, -8.8928664756020748, 0.0)
    viewCenter282 = NXOpen.Point3d(-2.4745367584282318, 8.892866475602121, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint282, viewCenter282)
    
    scaleAboutPoint283 = NXOpen.Point3d(1.8559025688214723, -7.2380200184030832, 0.0)
    viewCenter283 = NXOpen.Point3d(-1.8559025688211452, 7.2380200184031249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint283, viewCenter283)
    
    scaleAboutPoint284 = NXOpen.Point3d(1.3857405847200635, -5.9388882202281659, 0.0)
    viewCenter284 = NXOpen.Point3d(-1.3857405847197513, 5.9388882202282076, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint284, viewCenter284)
    
    scaleAboutPoint285 = NXOpen.Point3d(0.95022211523666855, -5.1074438693962172, 0.0)
    viewCenter285 = NXOpen.Point3d(-0.95022211523635458, 5.1074438693962607, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint285, viewCenter285)
    
    scaleAboutPoint286 = NXOpen.Point3d(-5.4796141978637181, -4.2759995185642721, 0.0)
    viewCenter286 = NXOpen.Point3d(5.4796141978640316, 4.2759995185643156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint286, viewCenter286)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.093220095037561262
    rotMatrix8.Xy = -0.88371909680684024
    rotMatrix8.Xz = 0.45863991520591901
    rotMatrix8.Yx = -0.2623681983596633
    rotMatrix8.Yy = 0.42256084982586151
    rotMatrix8.Yz = 0.8675282454675185
    rotMatrix8.Zx = -0.96045454987245249
    rotMatrix8.Zy = -0.20120359373865623
    rotMatrix8.Zz = -0.19246862470532022
    translation8 = NXOpen.Point3d(-75.572467473835161, 0.56832817735476748, 122.07185518636729)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 10.441637634933858)
    
    scaleAboutPoint287 = NXOpen.Point3d(-4.5610661531350889, -2.0524797689108372, 0.0)
    viewCenter287 = NXOpen.Point3d(4.5610661531354024, 2.0524797689108829, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint287, viewCenter287)
    
    scaleAboutPoint288 = NXOpen.Point3d(-5.8913771144662039, -2.2171849355518329, 0.0)
    viewCenter288 = NXOpen.Point3d(5.8913771144665175, 2.2171849355518787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint288, viewCenter288)
    
    scaleAboutPoint289 = NXOpen.Point3d(-7.5621843337570684, -2.6527034050352309, 0.0)
    viewCenter289 = NXOpen.Point3d(7.562184333757382, 2.6527034050352749, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint289, viewCenter289)
    
    scaleAboutPoint290 = NXOpen.Point3d(-9.6506933578706473, -3.1674070507883423, 0.0)
    viewCenter290 = NXOpen.Point3d(9.6506933578709546, 3.1674070507883845, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint290, viewCenter290)
    
    scaleAboutPoint291 = NXOpen.Point3d(-12.248956954220482, -3.7736685566033019, 0.0)
    viewCenter291 = NXOpen.Point3d(12.248956954220787, 3.7736685566033441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint291, viewCenter291)
    
    scaleAboutPoint292 = NXOpen.Point3d(-10.130134854816156, 10.207464128517216, 0.0)
    viewCenter292 = NXOpen.Point3d(10.130134854816472, -10.207464128517177, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint292, viewCenter292)
    
    scaleAboutPoint293 = NXOpen.Point3d(-12.662668568520232, 12.759330160646517, 0.0)
    viewCenter293 = NXOpen.Point3d(12.662668568520536, -12.759330160646467, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint293, viewCenter293)
    
    scaleAboutPoint294 = NXOpen.Point3d(-15.707508720492688, 17.278259592542145, 0.0)
    viewCenter294 = NXOpen.Point3d(15.707508720492998, -17.278259592542103, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint294, viewCenter294)
    
    scaleAboutPoint295 = NXOpen.Point3d(-12.566006976394114, 13.822607674033728, 0.0)
    viewCenter295 = NXOpen.Point3d(12.566006976394442, -13.822607674033678, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint295, viewCenter295)
    
    scaleAboutPoint296 = NXOpen.Point3d(-27.683879984917695, 16.935110940494472, 0.0)
    viewCenter296 = NXOpen.Point3d(27.683879984918025, -16.935110940494415, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint296, viewCenter296)
    
    scaleAboutPoint297 = NXOpen.Point3d(-22.270830825855537, 13.54808875239558, 0.0)
    viewCenter297 = NXOpen.Point3d(22.270830825855864, -13.548088752395527, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint297, viewCenter297)
    
    scaleAboutPoint298 = NXOpen.Point3d(-18.311572012370078, 10.739489531579331, 0.0)
    viewCenter298 = NXOpen.Point3d(18.311572012370405, -10.739489531579281, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint298, viewCenter298)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.10450289206760609
    rotMatrix9.Xy = -0.88170890937994972
    rotMatrix9.Xz = 0.46007449904284842
    rotMatrix9.Yx = -0.018456415497121532
    rotMatrix9.Yy = 0.46080842801412464
    rotMatrix9.Yz = 0.88730769939077547
    rotMatrix9.Zx = -0.99435331058759369
    rotMatrix9.Zy = -0.10121754685415474
    rotMatrix9.Zz = 0.031882627437572454
    translation9 = NXOpen.Point3d(-72.602037614207447, -25.538226744273228, 116.59407646504197)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 6.6826480863576698)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder35 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines185 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBefore(lines185)
    
    lines186 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAfter(lines186)
    
    lines187 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAbove(lines187)
    
    lines188 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBelow(lines188)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder35.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines189 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBefore(lines189)
    
    lines190 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAfter(lines190)
    
    lines191 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAbove(lines191)
    
    lines192 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBelow(lines192)
    
    theSession.SetUndoMarkName(markId179, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder35.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits891 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits892 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits893 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits894 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits895 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits896 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits897 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits898 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits899 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits900 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder35.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder35.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits901 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits902 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits903 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits904 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits905 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits906 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits907 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits908 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits909 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits910 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    point67 = NXOpen.Point3d(3.9999999999999942, -55.450354840974661, 62.37933157504623)
    sketchRapidDimensionBuilder35.FirstAssociativity.SetValue(line17, workPart.ModelingViews.WorkView, point67)
    
    point1_104 = NXOpen.Point3d(3.9999999999999427, -55.450354840974555, 65.0)
    point2_104 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line17, workPart.ModelingViews.WorkView, point1_104, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_104)
    
    point1_105 = NXOpen.Point3d(3.9999999999999427, -55.450354840974555, 5.0)
    point2_105 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line17, workPart.ModelingViews.WorkView, point1_105, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_105)
    
    dimensionlinearunits911 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits912 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits913 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits914 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits915 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits916 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    point1_106 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 65.0)
    point2_106 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line19, workPart.ModelingViews.WorkView, point1_106, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_106)
    
    point1_107 = NXOpen.Point3d(3.9999999999999942, -55.450354840974661, 62.37933157504623)
    point2_107 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line17, workPart.ModelingViews.WorkView, point1_107, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_107)
    
    point1_108 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 65.0)
    point2_108 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line19, workPart.ModelingViews.WorkView, point1_108, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_108)
    
    point1_109 = NXOpen.Point3d(3.9999999999999942, -55.450354840974661, 62.37933157504623)
    point2_109 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line17, workPart.ModelingViews.WorkView, point1_109, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_109)
    
    point1_110 = NXOpen.Point3d(3.9999999999999427, -58.5037012130541, 65.0)
    point2_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line19, workPart.ModelingViews.WorkView, point1_110, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_110)
    
    dimensionlinearunits917 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits918 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits919 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits920 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits921 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits922 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits923 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits924 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits925 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits926 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits927 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits928 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin22 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin22.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin22.View = NXOpen.View.Null
    assocOrigin22.ViewOfGeometry = workPart.ModelingViews.WorkView
    point68 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin22.PointOnGeometry = point68
    assocOrigin22.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.DimensionLine = 0
    assocOrigin22.AssociatedView = NXOpen.View.Null
    assocOrigin22.AssociatedPoint = NXOpen.Point.Null
    assocOrigin22.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.XOffsetFactor = 0.0
    assocOrigin22.YOffsetFactor = 0.0
    assocOrigin22.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder35.Origin.SetAssociativeOrigin(assocOrigin22)
    
    point69 = NXOpen.Point3d(3.9999999999999432, -56.793290799952004, 60.189014038460805)
    sketchRapidDimensionBuilder35.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point69)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder35.Style.DimensionStyle.TextCentered = True
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject31 = sketchRapidDimensionBuilder35.Commit()
    
    theSession.DeleteUndoMark(markId180, None)
    
    theSession.SetUndoMarkName(markId179, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId179, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder35.Destroy()
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder36 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines193 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBefore(lines193)
    
    lines194 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAfter(lines194)
    
    lines195 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAbove(lines195)
    
    lines196 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBelow(lines196)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder36.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId181, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder36.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits929 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits930 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits931 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits932 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits933 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits934 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits935 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits936 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits937 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits938 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder36.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits939 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits940 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits941 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits942 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits943 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits944 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits945 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits946 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits947 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits948 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder36.Destroy()
    
    theSession.UndoToMark(markId181, None)
    
    theSession.DeleteUndoMark(markId181, None)
    
    scaleAboutPoint299 = NXOpen.Point3d(3.8008884609461999, 3.4049625795975196, 0.0)
    viewCenter299 = NXOpen.Point3d(-3.8008884609458691, -3.4049625795974658, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint299, viewCenter299)
    
    scaleAboutPoint300 = NXOpen.Point3d(4.7511105761827119, 4.2562032244968959, 0.0)
    viewCenter300 = NXOpen.Point3d(-4.7511105761823833, -4.2562032244968364, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint300, viewCenter300)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    perpendicularDimension2 = nXObject31
    objects1[0] = perpendicularDimension2
    nErrs10 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs11 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId182, None)
    
    scaleAboutPoint301 = NXOpen.Point3d(7.9803810459317992, 3.0931709480355409, 0.0)
    viewCenter301 = NXOpen.Point3d(-7.9803810459314564, -3.0931709480354881, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint301, viewCenter301)
    
    scaleAboutPoint302 = NXOpen.Point3d(9.975476307414711, 3.8664636850444198, 0.0)
    viewCenter302 = NXOpen.Point3d(-9.9754763074143611, -3.8664636850443674, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint302, viewCenter302)
    
    scaleAboutPoint303 = NXOpen.Point3d(12.56600697639443, 4.7364180141793977, 0.0)
    viewCenter303 = NXOpen.Point3d(-12.5660069763941, -4.7364180141793488, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint303, viewCenter303)
    
    scaleAboutPoint304 = NXOpen.Point3d(15.707508720492985, 5.9205225177242466, 0.0)
    viewCenter304 = NXOpen.Point3d(-15.707508720492676, -5.9205225177242058, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint304, viewCenter304)
    
    scaleAboutPoint305 = NXOpen.Point3d(20.993689539889626, 11.176496589581458, 0.0)
    viewCenter305 = NXOpen.Point3d(-20.993689539889306, -11.176496589581433, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint305, viewCenter305)
    
    scaleAboutPoint306 = NXOpen.Point3d(16.794951631911754, 8.9411972716651675, 0.0)
    viewCenter306 = NXOpen.Point3d(-16.794951631911406, -8.941197271665148, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint306, viewCenter306)
    
    scaleAboutPoint307 = NXOpen.Point3d(13.435961305529418, 7.1529578173321244, 0.0)
    viewCenter307 = NXOpen.Point3d(-13.435961305529071, -7.1529578173321164, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint307, viewCenter307)
    
    scaleAboutPoint308 = NXOpen.Point3d(10.748769044423589, 5.7223662538657072, 0.0)
    viewCenter308 = NXOpen.Point3d(-10.748769044423232, -5.7223662538656939, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint308, viewCenter308)
    
    scaleAboutPoint309 = NXOpen.Point3d(8.5990152355388911, 4.5778930030925649, 0.0)
    viewCenter309 = NXOpen.Point3d(-8.5990152355385536, -4.5778930030925542, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint309, viewCenter309)
    
    scaleAboutPoint310 = NXOpen.Point3d(5.6914345443855137, -0.69287029235993658, 0.0)
    viewCenter310 = NXOpen.Point3d(-5.6914345443851717, 0.69287029235996189, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint310, viewCenter310)
    
    scaleAboutPoint311 = NXOpen.Point3d(5.815161382306929, -2.5364001773891083, 0.0)
    viewCenter311 = NXOpen.Point3d(-5.8151613823065915, 2.5364001773891292, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint311, viewCenter311)
    
    scaleAboutPoint312 = NXOpen.Point3d(5.9543540749685162, -4.9490735168568083, 0.0)
    viewCenter312 = NXOpen.Point3d(-5.9543540749681929, 4.9490735168568278, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint312, viewCenter312)
    
    scaleAboutPoint313 = NXOpen.Point3d(5.7030339354406197, -9.859482396863184, 0.0)
    viewCenter313 = NXOpen.Point3d(-5.7030339354402741, 9.8594823968632017, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint313, viewCenter313)
    
    scaleAboutPoint314 = NXOpen.Point3d(3.2623287342563798, -18.969837454749033, 0.0)
    viewCenter314 = NXOpen.Point3d(-3.2623287342560396, 18.969837454749044, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint314, viewCenter314)
    
    scaleAboutPoint315 = NXOpen.Point3d(-13.593036392734017, -58.147989013362896, 0.0)
    viewCenter315 = NXOpen.Point3d(13.593036392734351, 58.147989013362896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint315, viewCenter315)
    
    scaleAboutPoint316 = NXOpen.Point3d(-10.874429114187173, -46.518391210690304, 0.0)
    viewCenter316 = NXOpen.Point3d(10.874429114187523, 46.518391210690325, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint316, viewCenter316)
    
    scaleAboutPoint317 = NXOpen.Point3d(-8.6995432913496877, -37.118051376426138, 0.0)
    viewCenter317 = NXOpen.Point3d(8.699543291350059, 37.118051376426152, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint317, viewCenter317)
    
    scaleAboutPoint318 = NXOpen.Point3d(-6.80497608567795, -29.462453280038243, 0.0)
    viewCenter318 = NXOpen.Point3d(6.8049760856783061, 29.462453280038257, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint318, viewCenter318)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder37 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines197 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBefore(lines197)
    
    lines198 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAfter(lines198)
    
    lines199 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAbove(lines199)
    
    lines200 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBelow(lines200)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder37.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines201 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBefore(lines201)
    
    lines202 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAfter(lines202)
    
    lines203 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAbove(lines203)
    
    lines204 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBelow(lines204)
    
    theSession.SetUndoMarkName(markId184, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder37.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits949 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits950 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits951 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits952 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits953 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits954 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits955 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits956 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits957 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits958 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder37.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits959 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits960 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits961 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits962 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits963 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits964 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits965 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits966 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits967 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits968 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint319 = NXOpen.Point3d(13.238771657592176, 14.414176617845495, 0.0)
    viewCenter319 = NXOpen.Point3d(-13.238771657591807, -14.414176617845479, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint319, viewCenter319)
    
    scaleAboutPoint320 = NXOpen.Point3d(16.857781666793709, 18.636354961913966, 0.0)
    viewCenter320 = NXOpen.Point3d(-16.857781666793354, -18.636354961913955, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint320, viewCenter320)
    
    point1_111 = NXOpen.Point3d(3.9999999999999427, -56.977028027014327, 65.0)
    point2_111 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line18, workPart.ModelingViews.WorkView, point1_111, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_111)
    
    point1_112 = NXOpen.Point3d(3.9999999999999427, -56.977028027014327, 5.0)
    point2_112 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line20, workPart.ModelingViews.WorkView, point1_112, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_112)
    
    point1_113 = NXOpen.Point3d(3.9999999999999427, -56.977028027014327, 65.0)
    point2_113 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line18, workPart.ModelingViews.WorkView, point1_113, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_113)
    
    point1_114 = NXOpen.Point3d(3.9999999999999427, -56.977028027014327, 5.0)
    point2_114 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line20, workPart.ModelingViews.WorkView, point1_114, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_114)
    
    dimensionlinearunits969 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits970 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits971 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits972 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits973 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits974 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin23 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin23.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin23.View = NXOpen.View.Null
    assocOrigin23.ViewOfGeometry = workPart.ModelingViews.WorkView
    point70 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin23.PointOnGeometry = point70
    assocOrigin23.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.DimensionLine = 0
    assocOrigin23.AssociatedView = NXOpen.View.Null
    assocOrigin23.AssociatedPoint = NXOpen.Point.Null
    assocOrigin23.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.XOffsetFactor = 0.0
    assocOrigin23.YOffsetFactor = 0.0
    assocOrigin23.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder37.Origin.SetAssociativeOrigin(assocOrigin23)
    
    point71 = NXOpen.Point3d(3.9999999999999432, -45.410084472110249, 9.6648524152194959)
    sketchRapidDimensionBuilder37.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point71)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.TextCentered = False
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject32 = sketchRapidDimensionBuilder37.Commit()
    
    theSession.DeleteUndoMark(markId185, None)
    
    theSession.SetUndoMarkName(markId184, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder37.Destroy()
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder38 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines205 = []
    sketchRapidDimensionBuilder38.AppendedText.SetBefore(lines205)
    
    lines206 = []
    sketchRapidDimensionBuilder38.AppendedText.SetAfter(lines206)
    
    lines207 = []
    sketchRapidDimensionBuilder38.AppendedText.SetAbove(lines207)
    
    lines208 = []
    sketchRapidDimensionBuilder38.AppendedText.SetBelow(lines208)
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder38.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId186, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder38.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits975 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits976 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits977 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits978 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits979 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits980 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits981 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits982 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits983 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits984 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder38.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits985 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits986 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits987 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits988 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits989 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits990 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits991 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits992 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits993 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits994 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder38.Destroy()
    
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled4, undoUnavailable4 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled5, undoUnavailable5 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled6, undoUnavailable6 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled7, undoUnavailable7 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled8, undoUnavailable8 = theSession.UndoLastNVisibleMarks(1)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.73141311835623268
    rotMatrix10.Xy = -0.61380796975109464
    rotMatrix10.Xz = 0.29711046189330503
    rotMatrix10.Yx = 0.052406122357430668
    rotMatrix10.Yy = 0.48499230654110925
    rotMatrix10.Yz = 0.87294676867229182
    rotMatrix10.Zx = -0.67991797199064619
    rotMatrix10.Zy = -0.62291431101394268
    rotMatrix10.Zz = 0.38689703087275529
    translation10 = NXOpen.Point3d(-67.140284460325958, 4.1931309110743875, 54.888182187994403)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 2.7372126561721037)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal19 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin21, normal19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane19
    
    expression80 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression81 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId187, "Create Sketch Dialog")
    
    scalar12 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge14 = extrude3.FindObject("EDGE * 150 * 220 {(3.9999999999999,-54,25)(3.9999999999999,-56.95,25)(3.9999999999999,-59.9,25) EXTRUDE(2)}")
    point72 = workPart.Points.CreatePoint(edge14, scalar12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge15 = extrude3.FindObject("EDGE * 220 EXTRUDE(2) 140 {(3.9999999999999,-54,5)(3.9999999999999,-56.95,5)(3.9999999999999,-59.9,5) EXTRUDE(2)}")
    direction15 = workPart.Directions.CreateDirection(edge15, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform8 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction15, point72, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem8 = workPart.CoordinateSystems.CreateCoordinateSystem(xform8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.Csystem = cartesianCoordinateSystem8
    
    origin22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal20 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane20 = workPart.Planes.CreatePlane(origin22, normal20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane20.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom18 = [NXOpen.NXObject.Null] * 1 
    geom18[0] = face4
    plane20.SetGeometry(geom18)
    
    plane20.SetFlip(False)
    
    plane20.SetExpression(None)
    
    plane20.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane20.Evaluate()
    
    origin23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal21 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane21 = workPart.Planes.CreatePlane(origin23, normal21, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression82 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane21.SynchronizeToPlane(plane20)
    
    scalar13 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point73 = workPart.Points.CreatePoint(edge14, scalar13, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane21.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom19 = [NXOpen.NXObject.Null] * 1 
    geom19[0] = face4
    plane21.SetGeometry(geom19)
    
    plane21.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane21.Evaluate()
    
    extrude4 = feature11
    face5 = extrude4.FindObject("FACE 140 {(6.9999999999999,-56.95,22.5) EXTRUDE(2)}")
    line21 = workPart.Lines.CreateFaceAxis(face5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    line21.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint321 = NXOpen.Point3d(-15.949162700807925, -12.952653344898692, 0.0)
    viewCenter321 = NXOpen.Point3d(15.949162700808287, 12.95265334489871, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint321, viewCenter321)
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = line21
    nErrs12 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    theSession.DeleteUndoMark(markId188, None)
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject33 = sketchInPlaceBuilder8.Commit()
    
    sketch14 = nXObject33
    feature13 = sketch14.Feature
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs13 = theSession.UpdateManager.DoUpdate(markId191)
    
    sketch14.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId189, None)
    
    theSession.SetUndoMarkName(markId187, "Create Sketch")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression81)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point73)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression80)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane19.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression83)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression82)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane21.DestroyPlane()
    
    scaleAboutPoint322 = NXOpen.Point3d(6.9596346330800989, -5.1810613379594708, 0.0)
    viewCenter322 = NXOpen.Point3d(-6.9596346330797028, 5.181061337959477, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint322, viewCenter322)
    
    scaleAboutPoint323 = NXOpen.Point3d(9.3761744362328372, -6.4763266724493462, 0.0)
    viewCenter323 = NXOpen.Point3d(-9.3761744362324571, 6.4763266724493462, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint323, viewCenter323)
    
    scaleAboutPoint324 = NXOpen.Point3d(12.566006976394448, -8.8203702815074969, 0.0)
    viewCenter324 = NXOpen.Point3d(-12.566006976394066, 8.8203702815075165, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint324, viewCenter324)
    
    scaleAboutPoint325 = NXOpen.Point3d(9.7628208047372702, -6.9596346330798928, 0.0)
    viewCenter325 = NXOpen.Point3d(-9.7628208047368901, 6.9596346330799088, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint325, viewCenter325)
    
    scaleAboutPoint326 = NXOpen.Point3d(6.6503175382765383, -4.8717442431559306, 0.0)
    viewCenter326 = NXOpen.Point3d(-6.6503175382761563, 4.8717442431559368, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint326, viewCenter326)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.17704418491740043
    rotMatrix11.Xy = -0.98408920927437982
    rotMatrix11.Xz = -0.014959437711973533
    rotMatrix11.Yx = 0.042053012033578627
    rotMatrix11.Yy = -0.0076217969830083155
    rotMatrix11.Yz = 0.99908630877900395
    rotMatrix11.Zx = -0.98330407340040993
    rotMatrix11.Zy = -0.17751151061403025
    rotMatrix11.Zz = 0.040034520525267722
    translation11 = NXOpen.Point3d(-64.89369872242105, -26.734790747366382, -8.9535681498884223)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 4.2768947752689126)
    
    scaleAboutPoint327 = NXOpen.Point3d(-7.6092005321671614, -17.07430363315601, 0.0)
    viewCenter327 = NXOpen.Point3d(7.6092005321675362, 17.074303633156024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint327, viewCenter327)
    
    scaleAboutPoint328 = NXOpen.Point3d(-9.5115006652090148, -21.342879541445004, 0.0)
    viewCenter328 = NXOpen.Point3d(9.5115006652093719, 21.342879541445026, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint328, viewCenter328)
    
    scaleAboutPoint329 = NXOpen.Point3d(-7.6092005321671756, -17.07430363315601, 0.0)
    viewCenter329 = NXOpen.Point3d(7.6092005321675336, 17.074303633156024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint329, viewCenter329)
    
    scaleAboutPoint330 = NXOpen.Point3d(-6.0873604257336993, -13.659442906524806, 0.0)
    viewCenter330 = NXOpen.Point3d(6.0873604257340785, 13.659442906524827, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint330, viewCenter330)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.13203955863879302
    rotMatrix12.Xy = -0.99121685642490631
    rotMatrix12.Xz = -0.0073958429944845456
    rotMatrix12.Yx = 0.13236492886084475
    rotMatrix12.Yy = 0.010236942942846095
    rotMatrix12.Yz = 0.99114818801572313
    rotMatrix12.Zx = -0.98236708035343889
    rotMatrix12.Zy = -0.13184971952306671
    rotMatrix12.Zz = 0.13255403011433672
    translation12 = NXOpen.Point3d(-60.127584611474326, -24.677243128708277, -9.2769643288936159)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 6.6826480863576769)
    
    scaleAboutPoint331 = NXOpen.Point3d(-4.6323328117777889, -11.877776440456351, 0.0)
    viewCenter331 = NXOpen.Point3d(4.6323328117781628, 11.877776440456374, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint331, viewCenter331)
    
    scaleAboutPoint332 = NXOpen.Point3d(-5.7904160147222958, -14.847220550570436, 0.0)
    viewCenter332 = NXOpen.Point3d(5.7904160147226591, 14.847220550570457, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint332, viewCenter332)
    
    scaleAboutPoint333 = NXOpen.Point3d(-7.1142931804815035, -18.620889107173749, 0.0)
    viewCenter333 = NXOpen.Point3d(7.1142931804818517, 18.62088910717377, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint333, viewCenter333)
    
    scaleAboutPoint334 = NXOpen.Point3d(-8.0422444648921569, -23.662757752471634, 0.0)
    viewCenter334 = NXOpen.Point3d(8.0422444648925122, 23.662757752471652, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint334, viewCenter334)
    
    scaleAboutPoint335 = NXOpen.Point3d(-9.3761744362324748, -30.255078335472302, 0.0)
    viewCenter335 = NXOpen.Point3d(9.3761744362328212, 30.255078335472334, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint335, viewCenter335)
    
    scaleAboutPoint336 = NXOpen.Point3d(-12.324352996078815, -42.651927525645867, 0.0)
    viewCenter336 = NXOpen.Point3d(12.324352996079165, 42.651927525645895, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint336, viewCenter336)
    
    scaleAboutPoint337 = NXOpen.Point3d(-9.7628208047369167, -34.798173165399461, 0.0)
    viewCenter337 = NXOpen.Point3d(9.7628208047372453, 34.798173165399497, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint337, viewCenter337)
    
    scaleAboutPoint338 = NXOpen.Point3d(-7.7329273700886043, -28.225184900824001, 0.0)
    viewCenter338 = NXOpen.Point3d(7.7329273700889338, 28.225184900824026, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint338, viewCenter338)
    
    scaleAboutPoint339 = NXOpen.Point3d(-6.0626150581494365, -22.889465015462751, 0.0)
    viewCenter339 = NXOpen.Point3d(6.0626150581497642, 22.889465015462775, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint339, viewCenter339)
    
    scaleAboutPoint340 = NXOpen.Point3d(-4.7511105761823771, -18.509534953044462, 0.0)
    viewCenter340 = NXOpen.Point3d(4.7511105761827022, 18.50953495304449, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint340, viewCenter340)
    
    scaleAboutPoint341 = NXOpen.Point3d(-3.8008884609458651, -14.80762796243557, 0.0)
    viewCenter341 = NXOpen.Point3d(3.8008884609461959, 14.8076279624356, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint341, viewCenter341)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId193, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint21 = NXOpen.Point3d(3.9999999999999427, -55.190265948437172, 5.0)
    endPoint21 = NXOpen.Point3d(3.9999999999999427, -58.598460653519211, 5.0)
    line22 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    startPoint22 = NXOpen.Point3d(3.9999999999999427, -58.598460653519211, 5.0)
    endPoint22 = NXOpen.Point3d(3.9999999999999427, -58.598460653519211, 25.0)
    line23 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    startPoint23 = NXOpen.Point3d(3.9999999999999427, -58.598460653519211, 25.0)
    endPoint23 = NXOpen.Point3d(3.9999999999999427, -55.190265948437172, 25.0)
    line24 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    startPoint24 = NXOpen.Point3d(3.9999999999999427, -55.190265948437172, 25.0)
    endPoint24 = NXOpen.Point3d(3.9999999999999427, -55.190265948437172, 5.0)
    line25 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    theSession.ActiveSketch.AddGeometry(line22, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line23, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line22
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_22.SplineDefiningPointIndex = 0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = line23
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint47 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_22, geom2_22)
    
    geom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_23.Geometry = line23
    geom1_23.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_23.SplineDefiningPointIndex = 0
    geom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_23.Geometry = line24
    geom2_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint48 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_23, geom2_23)
    
    geom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_24.Geometry = line24
    geom1_24.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_24.SplineDefiningPointIndex = 0
    geom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_24.Geometry = line25
    geom2_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint49 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_24, geom2_24)
    
    geom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_25.Geometry = line25
    geom1_25.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_25.SplineDefiningPointIndex = 0
    geom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_25.Geometry = line22
    geom2_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint50 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_25, geom2_25)
    
    geom20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom20.Geometry = line22
    geom20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint51 = theSession.ActiveSketch.CreateHorizontalConstraint(geom20)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = line22
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_23.Geometry = line23
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint52 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_23, conGeom2_23)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line23
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = line24
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint53 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_24, conGeom2_24)
    
    conGeom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_25.Geometry = line24
    conGeom1_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_25.SplineDefiningPointIndex = 0
    conGeom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_25.Geometry = line25
    conGeom2_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint54 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_25, conGeom2_25)
    
    conGeom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_26.Geometry = line25
    conGeom1_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_26.SplineDefiningPointIndex = 0
    conGeom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_26.Geometry = line22
    conGeom2_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint55 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_26, conGeom2_26)
    
    conGeom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_27.Geometry = line22
    conGeom1_27.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_27.SplineDefiningPointIndex = 0
    conGeom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_27.Geometry = line9
    conGeom2_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_27.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = 3.9999999999999427
    help3.Point.Y = -55.190265948437172
    help3.Point.Z = 5.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_27, conGeom2_27, help3)
    
    conGeom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_28.Geometry = line24
    conGeom1_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_28.SplineDefiningPointIndex = 0
    conGeom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_28.Geometry = edge14
    conGeom2_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_28.SplineDefiningPointIndex = 0
    help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help4.Point.X = 3.9999999999999427
    help4.Point.Y = -58.598460653519211
    help4.Point.Z = 25.0
    help4.Parameter = 0.0
    sketchHelpedGeometricConstraint4 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_28, conGeom2_28, help4)
    
    dimObject1_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_13.Geometry = line23
    dimObject1_13.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_13.AssocValue = 0
    dimObject1_13.HelpPoint.X = 0.0
    dimObject1_13.HelpPoint.Y = 0.0
    dimObject1_13.HelpPoint.Z = 0.0
    dimObject1_13.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line23
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin13 = NXOpen.Point3d(3.9999999999999427, -59.675877855047219, 15.0)
    sketchDimensionalConstraint13 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_13, dimObject2_11, dimOrigin13, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint13
    dimension13 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression84 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    dimObject1_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_14.Geometry = line22
    dimObject1_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_14.AssocValue = 0
    dimObject1_14.HelpPoint.X = 0.0
    dimObject1_14.HelpPoint.Y = 0.0
    dimObject1_14.HelpPoint.Z = 0.0
    dimObject1_14.View = NXOpen.NXObject.Null
    dimObject2_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_12.Geometry = line22
    dimObject2_12.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_12.AssocValue = 0
    dimObject2_12.HelpPoint.X = 0.0
    dimObject2_12.HelpPoint.Y = 0.0
    dimObject2_12.HelpPoint.Z = 0.0
    dimObject2_12.View = NXOpen.NXObject.Null
    dimOrigin14 = NXOpen.Point3d(3.9999999999999427, -56.894363300978192, 3.9225827984719901)
    sketchDimensionalConstraint14 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_14, dimObject2_12, dimOrigin14, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint12 = sketchDimensionalConstraint14
    dimension14 = sketchHelpedDimensionalConstraint12.AssociatedDimension
    
    expression85 = sketchHelpedDimensionalConstraint12.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line22
    geoms11[1] = line23
    geoms11[2] = line24
    geoms11[3] = line25
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 4 
    geoms12[0] = line22
    geoms12[1] = line23
    geoms12[2] = line24
    geoms12[3] = line25
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms12)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder39 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines209 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBefore(lines209)
    
    lines210 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAfter(lines210)
    
    lines211 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAbove(lines211)
    
    lines212 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBelow(lines212)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder39.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines213 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBefore(lines213)
    
    lines214 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAfter(lines214)
    
    lines215 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAbove(lines215)
    
    lines216 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBelow(lines216)
    
    theSession.SetUndoMarkName(markId194, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder39.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits995 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits996 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits997 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits998 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits999 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1000 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1001 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1002 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1003 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1004 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder39.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1005 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1006 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1007 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1008 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1009 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1010 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1011 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1012 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1013 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1014 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    point74 = NXOpen.Point3d(3.9999999999999183, -58.59846065351919, 23.252349339888646)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(line23, workPart.ModelingViews.WorkView, point74)
    
    point1_115 = NXOpen.Point3d(3.9999999999999427, -58.598460653519211, 25.0)
    point2_115 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, workPart.ModelingViews.WorkView, point1_115, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_115)
    
    point1_116 = NXOpen.Point3d(3.9999999999999427, -58.598460653519211, 5.0)
    point2_116 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line23, workPart.ModelingViews.WorkView, point1_116, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_116)
    
    dimensionlinearunits1015 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1016 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1017 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1018 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1019 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1020 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    point1_117 = NXOpen.Point3d(3.9999999999999427, -59.899999999999999, 25.0)
    point2_117 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge10, workPart.ModelingViews.WorkView, point1_117, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_117)
    
    point1_118 = NXOpen.Point3d(3.9999999999999183, -58.59846065351919, 23.252349339888646)
    point2_118 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line23, workPart.ModelingViews.WorkView, point1_118, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_118)
    
    point1_119 = NXOpen.Point3d(3.9999999999999427, -59.899999999999999, 25.0)
    point2_119 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge10, workPart.ModelingViews.WorkView, point1_119, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_119)
    
    point1_120 = NXOpen.Point3d(3.9999999999999183, -58.59846065351919, 23.252349339888646)
    point2_120 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line23, workPart.ModelingViews.WorkView, point1_120, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_120)
    
    point1_121 = NXOpen.Point3d(3.9999999999999427, -59.899999999999999, 25.0)
    point2_121 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge10, workPart.ModelingViews.WorkView, point1_121, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_121)
    
    dimensionlinearunits1021 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1022 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1023 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1024 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1025 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1026 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1027 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1028 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1029 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1030 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1031 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1032 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin24 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin24.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin24.View = NXOpen.View.Null
    assocOrigin24.ViewOfGeometry = workPart.ModelingViews.WorkView
    point75 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin24.PointOnGeometry = point75
    assocOrigin24.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.DimensionLine = 0
    assocOrigin24.AssociatedView = NXOpen.View.Null
    assocOrigin24.AssociatedPoint = NXOpen.Point.Null
    assocOrigin24.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.XOffsetFactor = 0.0
    assocOrigin24.YOffsetFactor = 0.0
    assocOrigin24.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder39.Origin.SetAssociativeOrigin(assocOrigin24)
    
    point76 = NXOpen.Point3d(3.9999999999999427, -59.532890995344346, 21.696492928776578)
    sketchRapidDimensionBuilder39.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point76)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.TextCentered = False
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject34 = sketchRapidDimensionBuilder39.Commit()
    
    theSession.DeleteUndoMark(markId195, None)
    
    theSession.SetUndoMarkName(markId194, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder39.Destroy()
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder40 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines217 = []
    sketchRapidDimensionBuilder40.AppendedText.SetBefore(lines217)
    
    lines218 = []
    sketchRapidDimensionBuilder40.AppendedText.SetAfter(lines218)
    
    lines219 = []
    sketchRapidDimensionBuilder40.AppendedText.SetAbove(lines219)
    
    lines220 = []
    sketchRapidDimensionBuilder40.AppendedText.SetBelow(lines220)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder40.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId196, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder40.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1033 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1034 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1035 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1036 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1037 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1038 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1039 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1040 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1041 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1042 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder40.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1043 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1044 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1045 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1046 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1047 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1048 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1049 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1050 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1051 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1052 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    expression86 = workPart.Expressions.FindObject("p30")
    expression86.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId196, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId197, None)
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId196, "Edit Driving Value")
    
    point77 = NXOpen.Point3d(3.9999999999999192, -54.991805294917938, 21.297345131397432)
    sketchRapidDimensionBuilder40.FirstAssociativity.SetValue(line25, workPart.ModelingViews.WorkView, point77)
    
    point1_122 = NXOpen.Point3d(3.9999999999999427, -54.99180529491796, 25.0)
    point2_122 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, workPart.ModelingViews.WorkView, point1_122, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_122)
    
    point1_123 = NXOpen.Point3d(3.9999999999999427, -54.99180529491796, 5.0)
    point2_123 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line25, workPart.ModelingViews.WorkView, point1_123, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_123)
    
    dimensionlinearunits1053 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1054 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1055 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1056 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1057 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1058 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    edge16 = extrude3.FindObject("EDGE * 210 * 220 {(3.9999999999999,-54,25)(3.9999999999999,-54,15)(3.9999999999999,-54,5) EXTRUDE(2)}")
    point1_124 = NXOpen.Point3d(3.9999999999999427, -54.0, 25.0)
    point2_124 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge16, workPart.ModelingViews.WorkView, point1_124, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_124)
    
    point1_125 = NXOpen.Point3d(3.9999999999999192, -54.991805294917938, 21.297345131397432)
    point2_125 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, workPart.ModelingViews.WorkView, point1_125, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_125)
    
    point1_126 = NXOpen.Point3d(3.9999999999999427, -54.0, 25.0)
    point2_126 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge16, workPart.ModelingViews.WorkView, point1_126, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_126)
    
    point1_127 = NXOpen.Point3d(3.9999999999999192, -54.991805294917938, 21.297345131397432)
    point2_127 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, workPart.ModelingViews.WorkView, point1_127, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_127)
    
    point1_128 = NXOpen.Point3d(3.9999999999999427, -54.0, 25.0)
    point2_128 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge16, workPart.ModelingViews.WorkView, point1_128, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_128)
    
    dimensionlinearunits1059 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1060 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1061 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1062 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1063 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1064 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1065 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1066 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1067 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1068 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1069 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1070 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin25 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin25.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin25.View = NXOpen.View.Null
    assocOrigin25.ViewOfGeometry = workPart.ModelingViews.WorkView
    point78 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin25.PointOnGeometry = point78
    assocOrigin25.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.DimensionLine = 0
    assocOrigin25.AssociatedView = NXOpen.View.Null
    assocOrigin25.AssociatedPoint = NXOpen.Point.Null
    assocOrigin25.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.XOffsetFactor = 0.0
    assocOrigin25.YOffsetFactor = 0.0
    assocOrigin25.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder40.Origin.SetAssociativeOrigin(assocOrigin25)
    
    point79 = NXOpen.Point3d(3.9999999999999427, -51.714112058143449, 18.771569386446984)
    sketchRapidDimensionBuilder40.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point79)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.TextCentered = False
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject35 = sketchRapidDimensionBuilder40.Commit()
    
    theSession.DeleteUndoMark(markId199, None)
    
    theSession.SetUndoMarkName(markId198, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId198, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder40.Destroy()
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder41 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines221 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBefore(lines221)
    
    lines222 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAfter(lines222)
    
    lines223 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAbove(lines223)
    
    lines224 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBelow(lines224)
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder41.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId200, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder41.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1071 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1072 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1073 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1074 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1075 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1076 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1077 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1078 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1079 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1080 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder41.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1081 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1082 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1083 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1084 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1085 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1086 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1087 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1088 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1089 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1090 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    expression87 = workPart.Expressions.FindObject("p31")
    expression87.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId200, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId201, None)
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId200, "Edit Driving Value")
    
    point80 = NXOpen.Point3d(3.9999999999999183, -55.499999999999986, 22.101688319846424)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(line25, workPart.ModelingViews.WorkView, point80)
    
    point1_129 = NXOpen.Point3d(3.9999999999999427, -55.5, 25.0)
    point2_129 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, workPart.ModelingViews.WorkView, point1_129, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_129)
    
    point1_130 = NXOpen.Point3d(3.9999999999999427, -55.500000000000014, 5.0)
    point2_130 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line25, workPart.ModelingViews.WorkView, point1_130, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_130)
    
    dimensionlinearunits1091 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1092 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1093 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1094 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1095 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1096 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint342 = NXOpen.Point3d(-0.63348141015751191, 5.3845919863402276, 0.0)
    viewCenter342 = NXOpen.Point3d(0.63348141015784143, -5.3845919863401974, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint342, viewCenter342)
    
    scaleAboutPoint343 = NXOpen.Point3d(-0.55746364093858602, 4.3076735890721878, 0.0)
    viewCenter343 = NXOpen.Point3d(0.55746364093891876, -4.3076735890721594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint343, viewCenter343)
    
    scaleAboutPoint344 = NXOpen.Point3d(-0.6689563691263295, 3.4258674661327047, 0.0)
    viewCenter344 = NXOpen.Point3d(0.66895636912667855, -3.4258674661326838, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint344, viewCenter344)
    
    point1_131 = NXOpen.Point3d(3.9999999999999427, -58.399999999999999, 25.0)
    point2_131 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, workPart.ModelingViews.WorkView, point1_131, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_131)
    
    point1_132 = NXOpen.Point3d(3.9999999999999183, -55.499999999999986, 22.101688319846424)
    point2_132 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, workPart.ModelingViews.WorkView, point1_132, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_132)
    
    point1_133 = NXOpen.Point3d(3.9999999999999427, -58.399999999999999, 25.0)
    point2_133 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, workPart.ModelingViews.WorkView, point1_133, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_133)
    
    point1_134 = NXOpen.Point3d(3.9999999999999183, -55.499999999999986, 22.101688319846424)
    point2_134 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, workPart.ModelingViews.WorkView, point1_134, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_134)
    
    point1_135 = NXOpen.Point3d(3.9999999999999427, -58.399999999999999, 25.0)
    point2_135 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, workPart.ModelingViews.WorkView, point1_135, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_135)
    
    dimensionlinearunits1097 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1098 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1099 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1100 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1101 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1102 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1103 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1104 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1105 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1106 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1107 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1108 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint345 = NXOpen.Point3d(-2.4812199873053991, 1.8163178992040905, 0.0)
    viewCenter345 = NXOpen.Point3d(2.481219987305745, -1.8163178992040683, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint345, viewCenter345)
    
    dimensionlinearunits1109 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1110 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1111 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1112 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1113 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1114 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder41.Destroy()
    
    theSession.UndoToMark(markId202, None)
    
    theSession.DeleteUndoMark(markId202, None)
    
    sketchRapidDimensionBuilder41.Destroy()
    
    scaleAboutPoint346 = NXOpen.Point3d(-3.2563985192871359, 1.1935803337626913, 0.0)
    viewCenter346 = NXOpen.Point3d(3.256398519287492, -1.1935803337626694, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint346, viewCenter346)
    
    scaleAboutPoint347 = NXOpen.Point3d(-3.9569782804087072, 1.2162843075027421, 0.0)
    viewCenter347 = NXOpen.Point3d(3.9569782804090625, -1.2162843075027199, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint347, viewCenter347)
    
    scaleAboutPoint348 = NXOpen.Point3d(-4.9056800402608332, 1.3784555485031069, 0.0)
    viewCenter348 = NXOpen.Point3d(4.9056800402612035, -1.3784555485030863, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint348, viewCenter348)
    
    scaleAboutPoint349 = NXOpen.Point3d(-5.8026897170441005, -2.0271405125045407, 0.0)
    viewCenter349 = NXOpen.Point3d(5.8026897170444638, 2.0271405125045625, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint349, viewCenter349)
    
    scaleAboutPoint350 = NXOpen.Point3d(-7.3800584283367101, -5.6696586209111564, 0.0)
    viewCenter350 = NXOpen.Point3d(7.3800584283370618, 5.6696586209111786, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint350, viewCenter350)
    
    scaleAboutPoint351 = NXOpen.Point3d(-9.2250730354209267, -7.6809620981617694, 0.0)
    viewCenter351 = NXOpen.Point3d(9.2250730354212926, 7.6809620981617925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint351, viewCenter351)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder42 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines225 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBefore(lines225)
    
    lines226 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAfter(lines226)
    
    lines227 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAbove(lines227)
    
    lines228 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBelow(lines228)
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder42.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines229 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBefore(lines229)
    
    lines230 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAfter(lines230)
    
    lines231 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAbove(lines231)
    
    lines232 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBelow(lines232)
    
    theSession.SetUndoMarkName(markId203, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder42.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1115 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1116 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1117 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1118 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1119 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1120 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1121 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1122 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1123 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1124 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder42.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder42.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1125 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1126 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1127 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1128 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1129 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1130 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1131 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1132 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1133 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1134 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint352 = NXOpen.Point3d(-11.283887618433365, 0.98981470337137456, 0.0)
    viewCenter352 = NXOpen.Point3d(11.28388761843372, -0.98981470337135347, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint352, viewCenter352)
    
    scaleAboutPoint353 = NXOpen.Point3d(-9.0667026828815214, 0.79185176269710278, 0.0)
    viewCenter353 = NXOpen.Point3d(9.0667026828818518, -0.79185176269707913, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint353, viewCenter353)
    
    scaleAboutPoint354 = NXOpen.Point3d(-7.2533621463051849, 0.63348141015768222, 0.0)
    viewCenter354 = NXOpen.Point3d(7.2533621463055145, -0.63348141015766335, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint354, viewCenter354)
    
    scaleAboutPoint355 = NXOpen.Point3d(-5.8026897170441147, 0.50678512812614573, 0.0)
    viewCenter355 = NXOpen.Point3d(5.8026897170444425, -0.50678512812613496, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint355, viewCenter355)
    
    scaleAboutPoint356 = NXOpen.Point3d(-4.64215177363526, 0.40542810250091654, 0.0)
    viewCenter356 = NXOpen.Point3d(4.6421517736355886, -0.40542810250090788, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint356, viewCenter356)
    
    point81 = NXOpen.Point3d(3.9999999999999165, -56.769546212052283, 25.000000000000075)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(line24, workPart.ModelingViews.WorkView, point81)
    
    point1_136 = NXOpen.Point3d(3.9999999999999427, -55.5, 25.0)
    point2_136 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line24, workPart.ModelingViews.WorkView, point1_136, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_136)
    
    point1_137 = NXOpen.Point3d(3.9999999999999427, -58.399999999999999, 25.0)
    point2_137 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line24, workPart.ModelingViews.WorkView, point1_137, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_137)
    
    dimensionlinearunits1135 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1136 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1137 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1138 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1139 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1140 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint357 = NXOpen.Point3d(-3.3731618128074032, -0.98924457010221611, 0.0)
    viewCenter357 = NXOpen.Point3d(3.3731618128077434, 0.98924457010222311, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint357, viewCenter357)
    
    scaleAboutPoint358 = NXOpen.Point3d(-4.256995076259388, -1.540626789503456, 0.0)
    viewCenter358 = NXOpen.Point3d(4.2569950762597299, 1.5406267895034611, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint358, viewCenter358)
    
    scaleAboutPoint359 = NXOpen.Point3d(-5.1185297940738232, -3.9529239993838678, 0.0)
    viewCenter359 = NXOpen.Point3d(5.1185297940741563, 3.9529239993838785, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint359, viewCenter359)
    
    scaleAboutPoint360 = NXOpen.Point3d(-6.3348141015765522, -5.4479401273559782, 0.0)
    viewCenter360 = NXOpen.Point3d(6.3348141015769039, 5.4479401273559835, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint360, viewCenter360)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.13203955863879302
    rotMatrix13.Xy = -0.99121685642490631
    rotMatrix13.Xz = -0.0073958429944845456
    rotMatrix13.Yx = -0.090365376615472934
    rotMatrix13.Yy = -0.019466962539390488
    rotMatrix13.Yz = 0.99571840199859574
    rotMatrix13.Zx = -0.98711683891200064
    rotMatrix13.Zy = -0.13080589019083358
    rotMatrix13.Zz = -0.092142093680180878
    translation13 = NXOpen.Point3d(-64.904118417468027, -15.216145467039549, -1.6267250321241029)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 6.6826480863576823)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.10962398742788174
    rotMatrix14.Xy = -0.99389715994297889
    rotMatrix14.Xz = -0.012288890824317496
    rotMatrix14.Yx = -0.20912074819603632
    rotMatrix14.Yy = -0.035148572577695152
    rotMatrix14.Yz = 0.97725794472067806
    rotMatrix14.Zx = -0.97172583276063307
    rotMatrix14.Zy = -0.10456105060217674
    rotMatrix14.Zz = -0.21169764439555652
    translation14 = NXOpen.Point3d(-63.560978301428136, -8.4317549129717015, 2.9100603723629597)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 6.6826480863576823)
    
    point1_138 = NXOpen.Point3d(0.0, -60.0, 5.0)
    point2_138 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_138, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_138)
    
    point1_139 = NXOpen.Point3d(3.9999999999999165, -56.769546212052283, 25.000000000000075)
    point2_139 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line24, workPart.ModelingViews.WorkView, point1_139, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_139)
    
    point1_140 = NXOpen.Point3d(0.0, -60.0, 5.0)
    point2_140 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_140, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_140)
    
    point1_141 = NXOpen.Point3d(3.9999999999999165, -56.769546212052283, 25.000000000000075)
    point2_141 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line24, workPart.ModelingViews.WorkView, point1_141, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_141)
    
    point1_142 = NXOpen.Point3d(0.0, -60.0, 5.0)
    point2_142 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_142, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_142)
    
    dimensionlinearunits1141 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1142 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1143 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1144 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1145 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1146 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1147 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1148 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1149 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1150 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1151 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1152 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1153 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1154 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1155 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1156 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1157 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1158 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder42.Destroy()
    
    theSession.UndoToMark(markId203, None)
    
    theSession.DeleteUndoMark(markId203, None)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.10962398742788174
    rotMatrix15.Xy = -0.99389715994297889
    rotMatrix15.Xz = -0.012288890824317496
    rotMatrix15.Yx = -0.14133224569186706
    rotMatrix15.Yy = -0.027823940986471365
    rotMatrix15.Yz = 0.98957113167052246
    rotMatrix15.Zx = -0.98387386270197752
    rotMatrix15.Zy = -0.10674391675998135
    rotMatrix15.Zz = -0.14351988895840503
    translation15 = NXOpen.Point3d(-63.560978301428136, -12.45976574361837, 1.2921931476679269)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 6.6826480863576867)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.12105541124375818
    rotMatrix16.Xy = -0.99258151201466871
    rotMatrix16.Xz = -0.011292892245945478
    rotMatrix16.Yx = 0.053143632622499618
    rotMatrix16.Yy = -0.0048796748869149864
    rotMatrix16.Yz = 0.99857495616738123
    rotMatrix16.Zx = -0.99122214549529464
    rotMatrix16.Zy = -0.12148304729332435
    rotMatrix16.Zz = 0.052158676172221335
    translation16 = NXOpen.Point3d(-64.2002948084792, -23.0442867726549, -5.5108110834789805)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 6.6826480863576867)
    
    scaleAboutPoint361 = NXOpen.Point3d(-8.9875175066118, -6.0180733964978792, 0.0)
    viewCenter361 = NXOpen.Point3d(8.9875175066121376, 6.0180733964978828, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint361, viewCenter361)
    
    scaleAboutPoint362 = NXOpen.Point3d(-11.234396883264797, -7.5225917456223428, 0.0)
    viewCenter362 = NXOpen.Point3d(11.234396883265127, 7.5225917456223472, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint362, viewCenter362)
    
    scaleAboutPoint363 = NXOpen.Point3d(-13.795542428238191, -9.526966519949351, 0.0)
    viewCenter363 = NXOpen.Point3d(13.795542428238512, 9.526966519949351, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint363, viewCenter363)
    
    scaleAboutPoint364 = NXOpen.Point3d(-15.543184013878246, -12.527342339543795, 0.0)
    viewCenter364 = NXOpen.Point3d(15.54318401387857, 12.527342339543802, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint364, viewCenter364)
    
    scaleAboutPoint365 = NXOpen.Point3d(-17.979056135456197, -16.432470661438614, 0.0)
    viewCenter365 = NXOpen.Point3d(17.979056135456535, 16.432470661438614, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint365, viewCenter365)
    
    scaleAboutPoint366 = NXOpen.Point3d(-23.802917061054288, -24.890359972473195, 0.0)
    viewCenter366 = NXOpen.Point3d(23.802917061054661, 24.890359972473206, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint366, viewCenter366)
    
    scaleAboutPoint367 = NXOpen.Point3d(-19.138995240969493, -20.008949570104669, 0.0)
    viewCenter367 = NXOpen.Point3d(19.138995240969873, 20.008949570104676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint367, viewCenter367)
    
    scaleAboutPoint368 = NXOpen.Point3d(-15.311196192775549, -16.007159656083736, 0.0)
    viewCenter368 = NXOpen.Point3d(15.311196192775931, 16.007159656083743, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint368, viewCenter368)
    
    scaleAboutPoint369 = NXOpen.Point3d(-12.248956954220409, -12.805727724866975, 0.0)
    viewCenter369 = NXOpen.Point3d(12.248956954220779, 12.805727724866991, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint369, viewCenter369)
    
    scaleAboutPoint370 = NXOpen.Point3d(-9.7991655633763024, -10.244582179893575, 0.0)
    viewCenter370 = NXOpen.Point3d(9.7991655633766488, 10.244582179893593, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint370, viewCenter370)
    
    scaleAboutPoint371 = NXOpen.Point3d(-9.2646656235557625, -4.3551846948339801, 0.0)
    viewCenter371 = NXOpen.Point3d(9.2646656235561142, 4.3551846948339934, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint371, viewCenter371)
    
    scaleAboutPoint372 = NXOpen.Point3d(-7.5384287808761066, -5.5429623388796152, 0.0)
    viewCenter372 = NXOpen.Point3d(7.5384287808764663, 5.5429623388796285, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint372, viewCenter372)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder43 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines233 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBefore(lines233)
    
    lines234 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAfter(lines234)
    
    lines235 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAbove(lines235)
    
    lines236 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBelow(lines236)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder43.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines237 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBefore(lines237)
    
    lines238 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAfter(lines238)
    
    lines239 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAbove(lines239)
    
    lines240 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBelow(lines240)
    
    theSession.SetUndoMarkName(markId204, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder43.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1159 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1160 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1161 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1162 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1163 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1164 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1165 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1166 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1167 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1168 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder43.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1169 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1170 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1171 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1172 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1173 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1174 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1175 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1176 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1177 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1178 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint373 = NXOpen.Point3d(-7.5225917456221687, 4.9490735168568118, 0.0)
    viewCenter373 = NXOpen.Point3d(7.5225917456225195, -4.9490735168567985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint373, viewCenter373)
    
    scaleAboutPoint374 = NXOpen.Point3d(-6.0180733964976998, 3.9592588134854547, 0.0)
    viewCenter374 = NXOpen.Point3d(6.0180733964980506, -3.9592588134854387, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint374, viewCenter374)
    
    scaleAboutPoint375 = NXOpen.Point3d(-4.8397979736044272, 3.2180855636009751, 0.0)
    viewCenter375 = NXOpen.Point3d(4.8397979736047843, -3.2180855636009622, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint375, viewCenter375)
    
    scaleAboutPoint376 = NXOpen.Point3d(-3.8718383788835022, 2.5744684508807829, 0.0)
    viewCenter376 = NXOpen.Point3d(3.8718383788838704, -2.5744684508807691, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint376, viewCenter376)
    
    scaleAboutPoint377 = NXOpen.Point3d(-3.1461220754068737, 2.1406603812048095, 0.0)
    viewCenter377 = NXOpen.Point3d(3.1461220754072414, -2.1406603812047944, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint377, viewCenter377)
    
    scaleAboutPoint378 = NXOpen.Point3d(-2.7115031495258894, 1.9330811927243445, 0.0)
    viewCenter378 = NXOpen.Point3d(2.7115031495262798, -1.9330811927243301, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint378, viewCenter378)
    
    scaleAboutPoint379 = NXOpen.Point3d(-2.2833710732849295, 1.6191176701476393, 0.0)
    viewCenter379 = NXOpen.Point3d(2.2833710732853136, -1.6191176701476251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint379, viewCenter379)
    
    point82 = NXOpen.Point3d(3.9999999999999192, -57.224368692370469, 25.000000000000114)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(line24, workPart.ModelingViews.WorkView, point82)
    
    point1_143 = NXOpen.Point3d(3.9999999999999427, -58.399999999999999, 25.0)
    point2_143 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line24, workPart.ModelingViews.WorkView, point1_143, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_143)
    
    point1_144 = NXOpen.Point3d(3.9999999999999427, -55.5, 25.0)
    point2_144 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line24, workPart.ModelingViews.WorkView, point1_144, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_144)
    
    dimensionlinearunits1179 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1180 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1181 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1182 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1183 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1184 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint380 = NXOpen.Point3d(-1.9927602094122774, 0.99638010470624205, 0.0)
    viewCenter380 = NXOpen.Point3d(1.9927602094126611, -0.99638010470622784, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint380, viewCenter380)
    
    scaleAboutPoint381 = NXOpen.Point3d(-2.3664027486771158, 0.58122172774531111, 0.0)
    viewCenter381 = NXOpen.Point3d(2.3664027486774999, -0.5812217277452969, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint381, viewCenter381)
    
    scaleAboutPoint382 = NXOpen.Point3d(-2.8282664430461502, 0.37623727912085231, 0.0)
    viewCenter382 = NXOpen.Point3d(2.8282664430465463, -0.37623727912083793, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint382, viewCenter382)
    
    scaleAboutPoint383 = NXOpen.Point3d(-3.29207619230719, -0.69733633630155711, 0.0)
    viewCenter383 = NXOpen.Point3d(3.2920761923075883, 0.69733633630157099, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint383, viewCenter383)
    
    scaleAboutPoint384 = NXOpen.Point3d(-4.1150952403840302, -2.1893117535049078, 0.0)
    viewCenter384 = NXOpen.Point3d(4.1150952403844485, 2.1893117535049216, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint384, viewCenter384)
    
    scaleAboutPoint385 = NXOpen.Point3d(-5.2198868196990116, -3.4207996148514215, 0.0)
    viewCenter385 = NXOpen.Point3d(5.2198868196994228, 3.4207996148514344, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint385, viewCenter385)
    
    scaleAboutPoint386 = NXOpen.Point3d(-6.6198807361474659, -5.1945475632929021, 0.0)
    viewCenter386 = NXOpen.Point3d(6.6198807361478762, 5.1945475632929154, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint386, viewCenter386)
    
    scaleAboutPoint387 = NXOpen.Point3d(-8.3144435083192274, -10.016924798118181, 0.0)
    viewCenter387 = NXOpen.Point3d(8.3144435083196555, 10.016924798118195, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint387, viewCenter387)
    
    scaleAboutPoint388 = NXOpen.Point3d(-10.442545120567667, -12.867591143827699, 0.0)
    viewCenter388 = NXOpen.Point3d(10.442545120568079, 12.867591143827712, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint388, viewCenter388)
    
    scaleAboutPoint389 = NXOpen.Point3d(-13.053181400709631, -16.579396281470309, 0.0)
    viewCenter389 = NXOpen.Point3d(13.053181400710065, 16.579396281470327, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint389, viewCenter389)
    
    scaleAboutPoint390 = NXOpen.Point3d(-16.39380602458797, -22.88946501546274, 0.0)
    viewCenter390 = NXOpen.Point3d(16.393806024588418, 22.889465015462765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint390, viewCenter390)
    
    scaleAboutPoint391 = NXOpen.Point3d(-21.458873451996112, -36.731405007921637, 0.0)
    viewCenter391 = NXOpen.Point3d(21.458873451996549, 36.731405007921651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint391, viewCenter391)
    
    scaleAboutPoint392 = NXOpen.Point3d(-17.476415856400401, -30.081087469645293, 0.0)
    viewCenter392 = NXOpen.Point3d(17.476415856400838, 30.081087469645308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint392, viewCenter392)
    
    scaleAboutPoint393 = NXOpen.Point3d(-14.042996104080995, -24.31232365155908, 0.0)
    viewCenter393 = NXOpen.Point3d(14.042996104081428, 24.31232365155909, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint393, viewCenter393)
    
    scaleAboutPoint394 = NXOpen.Point3d(-11.333378353601884, -19.499349656415831, 0.0)
    viewCenter394 = NXOpen.Point3d(11.33337835360231, 19.499349656415838, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint394, viewCenter394)
    
    scaleAboutPoint395 = NXOpen.Point3d(-9.0667026828814663, -15.63907231326751, 0.0)
    viewCenter395 = NXOpen.Point3d(9.0667026828818926, 15.639072313267517, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint395, viewCenter395)
    
    scaleAboutPoint396 = NXOpen.Point3d(-7.221688075797247, -12.416235639090356, 0.0)
    viewCenter396 = NXOpen.Point3d(7.2216880757976734, 12.416235639090367, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint396, viewCenter396)
    
    scaleAboutPoint397 = NXOpen.Point3d(-4.9918335120422368, -8.6153471781443312, 0.0)
    viewCenter397 = NXOpen.Point3d(4.9918335120426738, 8.6153471781443418, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint397, viewCenter397)
    
    scaleAboutPoint398 = NXOpen.Point3d(-3.9934668096337438, -6.8314635271403255, 0.0)
    viewCenter398 = NXOpen.Point3d(3.993466809634183, 6.8314635271403352, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint398, viewCenter398)
    
    point1_145 = NXOpen.Point3d(3.9999999999999427, -56.95000000000001, 5.0)
    point2_145 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line22, workPart.ModelingViews.WorkView, point1_145, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_145)
    
    point1_146 = NXOpen.Point3d(3.9999999999999192, -57.224368692370469, 25.000000000000114)
    point2_146 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line24, workPart.ModelingViews.WorkView, point1_146, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_146)
    
    point1_147 = NXOpen.Point3d(3.9999999999999427, -56.95000000000001, 5.0)
    point2_147 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line22, workPart.ModelingViews.WorkView, point1_147, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_147)
    
    point1_148 = NXOpen.Point3d(3.9999999999999192, -57.224368692370469, 25.000000000000114)
    point2_148 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line24, workPart.ModelingViews.WorkView, point1_148, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_148)
    
    point1_149 = NXOpen.Point3d(3.9999999999999427, -56.95000000000001, 5.0)
    point2_149 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line22, workPart.ModelingViews.WorkView, point1_149, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_149)
    
    dimensionlinearunits1185 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1186 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1187 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1188 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1189 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1190 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1191 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1192 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1193 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1194 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1195 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1196 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin26 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin26.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin26.View = NXOpen.View.Null
    assocOrigin26.ViewOfGeometry = workPart.ModelingViews.WorkView
    point83 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin26.PointOnGeometry = point83
    assocOrigin26.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.DimensionLine = 0
    assocOrigin26.AssociatedView = NXOpen.View.Null
    assocOrigin26.AssociatedPoint = NXOpen.Point.Null
    assocOrigin26.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.XOffsetFactor = 0.0
    assocOrigin26.YOffsetFactor = 0.0
    assocOrigin26.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder43.Origin.SetAssociativeOrigin(assocOrigin26)
    
    point84 = NXOpen.Point3d(3.9999999999999427, -56.79592051643769, 6.5173089821922954)
    sketchRapidDimensionBuilder43.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point84)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.TextCentered = False
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject36 = sketchRapidDimensionBuilder43.Commit()
    
    theSession.DeleteUndoMark(markId205, None)
    
    theSession.SetUndoMarkName(markId204, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId204, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder43.Destroy()
    
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder44 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines241 = []
    sketchRapidDimensionBuilder44.AppendedText.SetBefore(lines241)
    
    lines242 = []
    sketchRapidDimensionBuilder44.AppendedText.SetAfter(lines242)
    
    lines243 = []
    sketchRapidDimensionBuilder44.AppendedText.SetAbove(lines243)
    
    lines244 = []
    sketchRapidDimensionBuilder44.AppendedText.SetBelow(lines244)
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder44.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId206, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder44.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1197 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1198 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1199 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1200 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1201 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1202 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1203 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1204 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1205 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1206 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder44.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1207 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1208 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1209 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1210 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1211 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1212 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1213 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1214 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1215 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1216 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder44.Destroy()
    
    marksRecycled9, undoUnavailable9 = theSession.UndoLastNVisibleMarks(1)
    
    scaleAboutPoint399 = NXOpen.Point3d(-4.946222850510873, 3.8110241635085536, 0.0)
    viewCenter399 = NXOpen.Point3d(4.9462228505113126, -3.8110241635085411, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint399, viewCenter399)
    
    scaleAboutPoint400 = NXOpen.Point3d(-5.6759934350125105, 4.2772664813845971, 0.0)
    viewCenter400 = NXOpen.Point3d(5.6759934350129422, -4.2772664813845847, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint400, viewCenter400)
    
    scaleAboutPoint401 = NXOpen.Point3d(-6.0054037682944985, 4.4850483839163147, 0.0)
    viewCenter401 = NXOpen.Point3d(6.0054037682949302, -4.4850483839162996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint401, viewCenter401)
    
    scaleAboutPoint402 = NXOpen.Point3d(-6.9999695822420458, 5.2895697748165542, 0.0)
    viewCenter402 = NXOpen.Point3d(6.999969582242473, -5.2895697748165409, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint402, viewCenter402)
    
    scaleAboutPoint403 = NXOpen.Point3d(-8.7103693896677594, 6.5723696303858334, 0.0)
    viewCenter403 = NXOpen.Point3d(8.7103693896681715, -6.5723696303858201, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint403, viewCenter403)
    
    scaleAboutPoint404 = NXOpen.Point3d(-10.393054385399065, 8.8093508600051074, 0.0)
    viewCenter404 = NXOpen.Point3d(10.393054385399475, -8.809350860005086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint404, viewCenter404)
    
    scaleAboutPoint405 = NXOpen.Point3d(-12.991317981748885, 11.011688575006385, 0.0)
    viewCenter405 = NXOpen.Point3d(12.991317981749292, -11.011688575006364, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint405, viewCenter405)
    
    scaleAboutPoint406 = NXOpen.Point3d(-17.089769487895929, 17.476415856400568, 0.0)
    viewCenter406 = NXOpen.Point3d(17.089769487896326, -17.476415856400557, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint406, viewCenter406)
    
    scaleAboutPoint407 = NXOpen.Point3d(-13.733679009277406, 14.104859523041876, 0.0)
    viewCenter407 = NXOpen.Point3d(13.733679009277816, -14.104859523041865, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint407, viewCenter407)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch15 = theSession.ActiveSketch
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression88 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies66 = [NXOpen.Body.Null] * 1 
    targetBodies66[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies66)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies67 = [NXOpen.Body.Null] * 1 
    targetBodies67[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies67)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId208, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scaleAboutPoint408 = NXOpen.Point3d(-19.564306246324414, -1.5465854740177469, 0.0)
    viewCenter408 = NXOpen.Point3d(19.564306246324811, 1.5465854740177536, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint408, viewCenter408)
    
    scaleAboutPoint409 = NXOpen.Point3d(-15.651444997059492, -1.2372683792142025, 0.0)
    viewCenter409 = NXOpen.Point3d(15.651444997059881, 1.2372683792142078, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint409, viewCenter409)
    
    scaleAboutPoint410 = NXOpen.Point3d(-12.570646732816124, -0.98981470337135813, 0.0)
    viewCenter410 = NXOpen.Point3d(12.57064673281652, 0.98981470337136657, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint410, viewCenter410)
    
    scaleAboutPoint411 = NXOpen.Point3d(-10.096109974387714, -0.79185176269708291, 0.0)
    viewCenter411 = NXOpen.Point3d(10.096109974388096, 0.79185176269709301, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint411, viewCenter411)
    
    scaleAboutPoint412 = NXOpen.Point3d(-8.076887979510138, -0.63348141015766612, 0.0)
    viewCenter412 = NXOpen.Point3d(8.0768879795105217, 0.63348141015767701, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint412, viewCenter412)
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features6 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature6 = feature13
    features6[0] = sketchFeature6
    curveFeatureRule6 = workPart.ScRuleFactory.CreateRuleCurveFeature(features6)
    
    section7.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = curveFeatureRule6
    helpPoint6 = NXOpen.Point3d(3.9999999999999538, -55.500000000000028, 24.401099574648818)
    section7.AddToSection(rules6, line25, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId210, None)
    
    direction16 = workPart.Directions.CreateDirection(sketch15, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction16
    
    targetBodies68 = [NXOpen.Body.Null] * 1 
    targetBodies68[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies68)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies69 = [NXOpen.Body.Null] * 1 
    targetBodies69[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies69)
    
    expression89 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId209, None)
    
    scaleAboutPoint413 = NXOpen.Point3d(-5.5999756657936341, 1.9004442304730218, 0.0)
    viewCenter413 = NXOpen.Point3d(5.5999756657940161, -1.9004442304730131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint413, viewCenter413)
    
    scaleAboutPoint414 = NXOpen.Point3d(-7.0633177232578568, 2.3755552880912743, 0.0)
    viewCenter414 = NXOpen.Point3d(7.0633177232582405, -2.3755552880912663, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint414, viewCenter414)
    
    scaleAboutPoint415 = NXOpen.Point3d(-8.9083323303420805, 2.9694441101140923, 0.0)
    viewCenter415 = NXOpen.Point3d(8.9083323303424482, -2.969444110114082, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint415, viewCenter415)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies70 = [NXOpen.Body.Null] * 1 
    targetBodies70[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies70)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies71 = [NXOpen.Body.Null] * 1 
    targetBodies71[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies71)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies72 = [NXOpen.Body.Null] * 1 
    targetBodies72[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies72)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies73 = [NXOpen.Body.Null] * 1 
    targetBodies73[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies73)
    
    direction17 = extrudeBuilder7.Direction
    
    success3 = direction17.ReverseDirection()
    
    extrudeBuilder7.Direction = direction17
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies74 = [NXOpen.Body.Null] * 1 
    targetBodies74[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies74)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies75 = [NXOpen.Body.Null] * 1 
    targetBodies75[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies75)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies76 = [NXOpen.Body.Null] * 1 
    targetBodies76[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies76)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies77 = [NXOpen.Body.Null] * 1 
    targetBodies77[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies77)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies78 = [NXOpen.Body.Null] * 1 
    targetBodies78[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies78)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies79 = [NXOpen.Body.Null] * 1 
    targetBodies79[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies79)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies80 = [NXOpen.Body.Null] * 1 
    targetBodies80[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies80)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies81 = [NXOpen.Body.Null] * 1 
    targetBodies81[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies81)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies82 = [NXOpen.Body.Null] * 1 
    targetBodies82[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies82)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies83 = [NXOpen.Body.Null] * 1 
    targetBodies83[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies83)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies84 = [NXOpen.Body.Null] * 1 
    targetBodies84[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies84)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies85 = [NXOpen.Body.Null] * 1 
    targetBodies85[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies85)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies86 = [NXOpen.Body.Null] * 1 
    targetBodies86[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies86)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies87 = [NXOpen.Body.Null] * 1 
    targetBodies87[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies87)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies88 = [NXOpen.Body.Null] * 1 
    targetBodies88[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies88)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies89 = [NXOpen.Body.Null] * 1 
    targetBodies89[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies89)
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("13.5")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies90 = [NXOpen.Body.Null] * 1 
    targetBodies90[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies90)
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId211, None)
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    feature14 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId212, None)
    
    theSession.SetUndoMarkName(markId208, "Extrude")
    
    expression90 = extrudeBuilder7.Limits.StartExtend.Value
    expression91 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression88)
    
    workPart.Expressions.Delete(expression89)
    
    scaleAboutPoint416 = NXOpen.Point3d(1.3857405847200868, -14.005878052704778, 0.0)
    viewCenter416 = NXOpen.Point3d(-1.3857405847197239, 14.005878052704787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint416, viewCenter416)
    
    scaleAboutPoint417 = NXOpen.Point3d(1.7321757309000663, -17.507347565880966, 0.0)
    viewCenter417 = NXOpen.Point3d(-1.732175730899697, 17.507347565880988, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint417, viewCenter417)
    
    scaleAboutPoint418 = NXOpen.Point3d(2.16521966362505, -21.884184457351218, 0.0)
    viewCenter418 = NXOpen.Point3d(-2.1652196636246543, 21.884184457351232, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint418, viewCenter418)
    
    scaleAboutPoint419 = NXOpen.Point3d(2.8031861716573672, -27.74187694019346, 0.0)
    viewCenter419 = NXOpen.Point3d(-2.8031861716569551, 27.741876940193478, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint419, viewCenter419)
    
    scaleAboutPoint420 = NXOpen.Point3d(12.566006976394435, -36.610578017764006, 0.0)
    viewCenter420 = NXOpen.Point3d(-12.566006976394045, 36.610578017764027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint420, viewCenter420)
    
    scaleAboutPoint421 = NXOpen.Point3d(16.915778622069386, -46.065289997599109, 0.0)
    viewCenter421 = NXOpen.Point3d(-16.915778622068974, 46.065289997599123, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint421, viewCenter421)
    
    scaleAboutPoint422 = NXOpen.Point3d(77.215998397615138, -69.853103684883905, 0.0)
    viewCenter422 = NXOpen.Point3d(-77.215998397614683, 69.853103684883905, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint422, viewCenter422)
    
    scaleAboutPoint423 = NXOpen.Point3d(65.548642160518312, -55.882482947907121, 0.0)
    viewCenter423 = NXOpen.Point3d(-65.548642160517815, 55.882482947907121, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint423, viewCenter423)
    
    scaleAboutPoint424 = NXOpen.Point3d(52.680567708729996, -44.705986358325703, 0.0)
    viewCenter424 = NXOpen.Point3d(-52.680567708729505, 44.705986358325696, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint424, viewCenter424)
    
    scaleAboutPoint425 = NXOpen.Point3d(42.24111575911013, -35.764789086660556, 0.0)
    viewCenter425 = NXOpen.Point3d(-42.241115759109654, 35.764789086660556, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint425, viewCenter425)
    
    scaleAboutPoint426 = NXOpen.Point3d(33.947551154689911, -28.61183126932843, 0.0)
    viewCenter426 = NXOpen.Point3d(-33.947551154689464, 28.611831269328448, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint426, viewCenter426)
    
    scaleAboutPoint427 = NXOpen.Point3d(27.034314085830562, -22.951328434423448, 0.0)
    viewCenter427 = NXOpen.Point3d(-27.034314085830097, 22.951328434423477, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint427, viewCenter427)
    
    scaleAboutPoint428 = NXOpen.Point3d(33.715563333587248, -28.689160543029306, 0.0)
    viewCenter428 = NXOpen.Point3d(-33.7155633335868, 28.689160543029331, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint428, viewCenter428)
    
    scaleAboutPoint429 = NXOpen.Point3d(42.047792574857894, -35.861450678786639, 0.0)
    viewCenter429 = NXOpen.Point3d(-42.047792574857446, 35.861450678786653, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint429, viewCenter429)
    
    scaleAboutPoint430 = NXOpen.Point3d(52.559740718572279, -44.826813348483284, 0.0)
    viewCenter430 = NXOpen.Point3d(-52.559740718571867, 44.826813348483292, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint430, viewCenter430)
    
    scaleAboutPoint431 = NXOpen.Point3d(65.699675898215304, -56.03351668560412, 0.0)
    viewCenter431 = NXOpen.Point3d(-65.699675898214892, 56.03351668560412, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint431, viewCenter431)
    
    scaleAboutPoint432 = NXOpen.Point3d(82.124594872769066, -70.04189585700513, 0.0)
    viewCenter432 = NXOpen.Point3d(-82.124594872768654, 70.041895857005159, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint432, viewCenter432)
    
    scaleAboutPoint433 = NXOpen.Point3d(112.56733262732992, -49.557945181843252, 0.0)
    viewCenter433 = NXOpen.Point3d(-112.56733262732951, 49.557945181843287, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint433, viewCenter433)
    
    scaleAboutPoint434 = NXOpen.Point3d(135.98936148112958, -78.466746537918468, 0.0)
    viewCenter434 = NXOpen.Point3d(-135.98936148112912, 78.466746537918482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint434, viewCenter434)
    
    scaleAboutPoint435 = NXOpen.Point3d(169.98670185141199, -100.66457615061914, 0.0)
    viewCenter435 = NXOpen.Point3d(-169.98670185141154, 100.66457615061914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint435, viewCenter435)
    
    scaleAboutPoint436 = NXOpen.Point3d(208.79603020252071, -143.3456189690593, 0.0)
    viewCenter436 = NXOpen.Point3d(-208.79603020252026, 143.3456189690593, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint436, viewCenter436)
    
    scaleAboutPoint437 = NXOpen.Point3d(166.66808945084207, -116.15143401994517, 0.0)
    viewCenter437 = NXOpen.Point3d(-166.66808945084176, 116.15143401994517, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint437, viewCenter437)
    
    scaleAboutPoint438 = NXOpen.Point3d(133.33447156067376, -93.806110522774787, 0.0)
    viewCenter438 = NXOpen.Point3d(-133.33447156067339, 93.806110522774787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint438, viewCenter438)
    
    scaleAboutPoint439 = NXOpen.Point3d(106.66757724853903, -75.752859063674705, 0.0)
    viewCenter439 = NXOpen.Point3d(-106.66757724853868, 75.75285906367472, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint439, viewCenter439)
    
    scaleAboutPoint440 = NXOpen.Point3d(85.334061798831186, -60.791079423061035, 0.0)
    viewCenter440 = NXOpen.Point3d(-85.334061798830888, 60.791079423061049, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint440, viewCenter440)
    
    scaleAboutPoint441 = NXOpen.Point3d(68.116215701367977, -48.934931013842956, 0.0)
    viewCenter441 = NXOpen.Point3d(-68.116215701367636, 48.93493101384297, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint441, viewCenter441)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder9 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal22 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane22 = workPart.Planes.CreatePlane(origin24, normal22, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder9.PlaneReference = plane22
    
    expression92 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression93 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder8 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder8.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId213, "Create Sketch Dialog")
    
    scalar14 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge17 = extrude3.FindObject("EDGE * 130 * 160 {(60.1,-115.9,25)(63.05,-115.9,25)(66,-115.9,25) EXTRUDE(2)}")
    point85 = workPart.Points.CreatePoint(edge17, scalar14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge18 = extrude3.FindObject("EDGE * 160 EXTRUDE(2) 140 {(60.1,-115.9,5)(63.05,-115.9,5)(66,-115.9,5) EXTRUDE(2)}")
    direction18 = workPart.Directions.CreateDirection(edge18, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face6 = extrude3.FindObject("FACE 160 {(63.05,-115.9,15) EXTRUDE(2)}")
    xform9 = workPart.Xforms.CreateXformByPlaneXDirPoint(face6, direction18, point85, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem9 = workPart.CoordinateSystems.CreateCoordinateSystem(xform9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder9.Csystem = cartesianCoordinateSystem9
    
    origin25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal23 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane23 = workPart.Planes.CreatePlane(origin25, normal23, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane23.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom21 = [NXOpen.NXObject.Null] * 1 
    geom21[0] = face6
    plane23.SetGeometry(geom21)
    
    plane23.SetFlip(False)
    
    plane23.SetExpression(None)
    
    plane23.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane23.Evaluate()
    
    origin26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal24 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane24 = workPart.Planes.CreatePlane(origin26, normal24, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression94 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression95 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane24.SynchronizeToPlane(plane23)
    
    scalar15 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point86 = workPart.Points.CreatePoint(edge17, scalar15, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane24.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom22 = [NXOpen.NXObject.Null] * 1 
    geom22[0] = face6
    plane24.SetGeometry(geom22)
    
    plane24.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane24.Evaluate()
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.95166404712537944
    rotMatrix17.Xy = 0.24065888475550315
    rotMatrix17.Xz = -0.19083721491675659
    rotMatrix17.Yx = 0.052406122357430668
    rotMatrix17.Yy = 0.48499230654110925
    rotMatrix17.Yz = 0.87294676867229182
    rotMatrix17.Zx = 0.30263697683595314
    rotMatrix17.Zy = -0.84075309323497205
    rotMatrix17.Zz = 0.4489377423066841
    translation17 = NXOpen.Point3d(-20.526992053839436, 1.6277209927065357, -19.151764796466011)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 2.1897701249376849)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.79583097179800144
    rotMatrix18.Xy = 0.50784249931512937
    rotMatrix18.Xz = -0.32977122405754894
    rotMatrix18.Yx = 0.087030903704611848
    rotMatrix18.Yy = 0.44302167831766842
    rotMatrix18.Yz = 0.89227653468022927
    rotMatrix18.Zx = 0.59923174659509748
    rotMatrix18.Zy = -0.73880158935262252
    rotMatrix18.Zz = 0.30837238112812676
    translation18 = NXOpen.Point3d(9.3693646364565613, -3.5962209767887536, -26.261986510770583)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 2.1897701249376849)
    
    sketchInPlaceBuilder9.Destroy()
    
    sketchAlongPathBuilder8.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression93)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point86)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression92)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane22.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression95)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression94)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane24.DestroyPlane()
    
    theSession.UndoToMark(markId213, None)
    
    theSession.DeleteUndoMark(markId213, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder10 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal25 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane25 = workPart.Planes.CreatePlane(origin27, normal25, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.PlaneReference = plane25
    
    expression96 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression97 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder9 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder9.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId214, "Create Sketch Dialog")
    
    scalar16 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge19 = extrude3.FindObject("EDGE * 130 * 170 {(66,-115.9,25)(66,-112.9,25)(66,-109.9,25) EXTRUDE(2)}")
    point87 = workPart.Points.CreatePoint(edge19, scalar16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge20 = extrude3.FindObject("EDGE * 170 EXTRUDE(2) 140 {(66,-115.9,5)(66,-112.9,5)(66,-109.9,5) EXTRUDE(2)}")
    direction19 = workPart.Directions.CreateDirection(edge20, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face7 = extrude3.FindObject("FACE 170 {(66,-112.9,15) EXTRUDE(2)}")
    xform10 = workPart.Xforms.CreateXformByPlaneXDirPoint(face7, direction19, point87, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem10 = workPart.CoordinateSystems.CreateCoordinateSystem(xform10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem10
    
    origin28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal26 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane26 = workPart.Planes.CreatePlane(origin28, normal26, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane26.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom23 = [NXOpen.NXObject.Null] * 1 
    geom23[0] = face7
    plane26.SetGeometry(geom23)
    
    plane26.SetFlip(False)
    
    plane26.SetExpression(None)
    
    plane26.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane26.Evaluate()
    
    origin29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal27 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane27 = workPart.Planes.CreatePlane(origin29, normal27, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression98 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression99 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane27.SynchronizeToPlane(plane26)
    
    scalar17 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point88 = workPart.Points.CreatePoint(edge19, scalar17, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane27.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom24 = [NXOpen.NXObject.Null] * 1 
    geom24[0] = face7
    plane27.SetGeometry(geom24)
    
    plane27.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane27.Evaluate()
    
    plane27.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom25 = [NXOpen.NXObject.Null] * 1 
    geom25[0] = face1
    plane27.SetGeometry(geom25)
    
    plane27.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane27.Evaluate()
    
    plane26.SynchronizeToPlane(plane27)
    
    xform11 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane26, direction19, point87, NXOpen.SmartObject.UpdateOption.WithinModeling, 1.0, False, False)
    
    cartesianCoordinateSystem11 = workPart.CoordinateSystems.CreateCoordinateSystem(xform11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem11
    
    plane27.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom26 = [NXOpen.NXObject.Null] * 1 
    geom26[0] = face7
    plane27.SetGeometry(geom26)
    
    plane27.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane27.Evaluate()
    
    plane26.SynchronizeToPlane(plane27)
    
    xform12 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane26, direction19, point87, NXOpen.SmartObject.UpdateOption.WithinModeling, 1.0, False, False)
    
    cartesianCoordinateSystem12 = workPart.CoordinateSystems.CreateCoordinateSystem(xform12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem12
    
    nErrs14 = theSession.UpdateManager.AddToDeleteList(xform11)
    
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId215, None)
    
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject37 = sketchInPlaceBuilder10.Commit()
    
    sketch16 = nXObject37
    feature15 = sketch16.Feature
    
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs15 = theSession.UpdateManager.DoUpdate(markId217)
    
    sketch16.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId216, None)
    
    theSession.SetUndoMarkName(markId214, "Create Sketch")
    
    sketchInPlaceBuilder10.Destroy()
    
    sketchAlongPathBuilder9.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression97)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point88)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression96)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane25.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression99)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression98)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane27.DestroyPlane()
    
    scaleAboutPoint442 = NXOpen.Point3d(1.0874429114189075, -2.537366793310365, 0.0)
    viewCenter442 = NXOpen.Point3d(-1.0874429114185675, 2.5373667933103961, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint442, viewCenter442)
    
    scaleAboutPoint443 = NXOpen.Point3d(0.96661592126126283, -2.1265550267743958, 0.0)
    viewCenter443 = NXOpen.Point3d(-0.96661592126092499, 2.1265550267744122, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint443, viewCenter443)
    
    scaleAboutPoint444 = NXOpen.Point3d(0.77329273700904977, -1.855902568821296, 0.0)
    viewCenter444 = NXOpen.Point3d(-0.77329273700870027, 1.8559025688213158, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint444, viewCenter444)
    
    scaleAboutPoint445 = NXOpen.Point3d(0.80422444648939639, -1.8559025688212973, 0.0)
    viewCenter445 = NXOpen.Point3d(-0.80422444648905889, 1.855902568821308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint445, viewCenter445)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId219, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(66.0, -113.40000000000001, 20.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 1.8680251479222079, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_15.Geometry = arc3
    dimObject1_15.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_15.AssocValue = 0
    dimObject1_15.HelpPoint.X = 0.0
    dimObject1_15.HelpPoint.Y = 0.0
    dimObject1_15.HelpPoint.Z = 0.0
    dimObject1_15.View = NXOpen.NXObject.Null
    dimOrigin15 = NXOpen.Point3d(66.0, -113.40000000000001, 20.561154792462503)
    sketchDimensionalConstraint15 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_15, dimOrigin15, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension15 = sketchDimensionalConstraint15.AssociatedDimension
    
    expression100 = sketchDimensionalConstraint15.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder45 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines245 = []
    sketchRapidDimensionBuilder45.AppendedText.SetBefore(lines245)
    
    lines246 = []
    sketchRapidDimensionBuilder45.AppendedText.SetAfter(lines246)
    
    lines247 = []
    sketchRapidDimensionBuilder45.AppendedText.SetAbove(lines247)
    
    lines248 = []
    sketchRapidDimensionBuilder45.AppendedText.SetBelow(lines248)
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder45.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder45.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines249 = []
    sketchRapidDimensionBuilder45.AppendedText.SetBefore(lines249)
    
    lines250 = []
    sketchRapidDimensionBuilder45.AppendedText.SetAfter(lines250)
    
    lines251 = []
    sketchRapidDimensionBuilder45.AppendedText.SetAbove(lines251)
    
    lines252 = []
    sketchRapidDimensionBuilder45.AppendedText.SetBelow(lines252)
    
    theSession.SetUndoMarkName(markId220, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder45.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1217 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1218 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1219 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1220 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1221 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1222 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1223 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1224 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1225 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1226 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder45.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder45.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder45.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1227 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1228 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1229 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1230 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1231 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1232 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1233 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1234 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1235 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1236 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    point1_150 = NXOpen.Point3d(66.0, -112.18010921924923, 21.414702949848149)
    point2_150 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder45.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc3, workPart.ModelingViews.WorkView, point1_150, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_150)
    
    point1_151 = NXOpen.Point3d(66.0, -112.18010921924923, 21.414702949848149)
    point2_151 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder45.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_151, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_151)
    
    point1_152 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_152 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder45.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_152, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_152)
    
    dimensionlinearunits1237 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1238 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1239 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1240 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1241 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1242 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin27 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin27.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin27.View = NXOpen.View.Null
    assocOrigin27.ViewOfGeometry = workPart.ModelingViews.WorkView
    point89 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin27.PointOnGeometry = point89
    assocOrigin27.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.DimensionLine = 0
    assocOrigin27.AssociatedView = NXOpen.View.Null
    assocOrigin27.AssociatedPoint = NXOpen.Point.Null
    assocOrigin27.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.XOffsetFactor = 0.0
    assocOrigin27.YOffsetFactor = 0.0
    assocOrigin27.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder45.Origin.SetAssociativeOrigin(assocOrigin27)
    
    point90 = NXOpen.Point3d(66.0, -118.63803625856401, 18.672725502609147)
    sketchRapidDimensionBuilder45.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point90)
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder45.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder45.Style.DimensionStyle.TextCentered = False
    
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject38 = sketchRapidDimensionBuilder45.Commit()
    
    theSession.DeleteUndoMark(markId221, None)
    
    theSession.SetUndoMarkName(markId220, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId220, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder45.Destroy()
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder46 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines253 = []
    sketchRapidDimensionBuilder46.AppendedText.SetBefore(lines253)
    
    lines254 = []
    sketchRapidDimensionBuilder46.AppendedText.SetAfter(lines254)
    
    lines255 = []
    sketchRapidDimensionBuilder46.AppendedText.SetAbove(lines255)
    
    lines256 = []
    sketchRapidDimensionBuilder46.AppendedText.SetBelow(lines256)
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder46.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder46.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder46.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId222, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder46.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1243 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1244 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1245 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1246 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1247 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1248 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1249 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1250 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1251 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1252 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder46.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder46.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1253 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1254 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1255 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1256 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1257 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1258 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1259 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1260 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1261 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1262 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    expression101 = workPart.Expressions.FindObject("p34")
    expression101.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId222, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.80298704847213276)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId223, None)
    
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId222, "Edit Driving Value")
    
    point1_153 = NXOpen.Point3d(66.0, -113.89253237881968, 20.985064757639336)
    point2_153 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_153, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_153)
    
    point1_154 = NXOpen.Point3d(66.0, -113.89253237881968, 20.985064757639336)
    point2_154 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_154, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_154)
    
    point1_155 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_155 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_155, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_155)
    
    dimensionlinearunits1263 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1264 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1265 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1266 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1267 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1268 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    edge21 = extrude3.FindObject("EDGE * 170 * 180 {(66,-109.9,25)(66,-109.9,15)(66,-109.9,5) EXTRUDE(2)}")
    point91 = NXOpen.Point3d(66.0, -109.90000000000001, 21.295734466543255)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(edge21, workPart.ModelingViews.WorkView, point91)
    
    point1_156 = NXOpen.Point3d(66.0, -109.90000000000001, 21.295734466543255)
    point2_156 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge21, workPart.ModelingViews.WorkView, point1_156, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_156)
    
    point1_157 = NXOpen.Point3d(66.0, -113.89253237881968, 20.985064757639336)
    point2_157 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_157, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_157)
    
    point1_158 = NXOpen.Point3d(66.0, -109.90000000000001, 21.295734466543255)
    point2_158 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge21, workPart.ModelingViews.WorkView, point1_158, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_158)
    
    point1_159 = NXOpen.Point3d(66.0, -113.89253237881968, 20.985064757639336)
    point2_159 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_159, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_159)
    
    dimensionlinearunits1269 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1270 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1271 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1272 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1273 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1274 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1275 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1276 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1277 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1278 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1279 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1280 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin28 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin28.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin28.View = NXOpen.View.Null
    assocOrigin28.ViewOfGeometry = workPart.ModelingViews.WorkView
    point92 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin28.PointOnGeometry = point92
    assocOrigin28.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.DimensionLine = 0
    assocOrigin28.AssociatedView = NXOpen.View.Null
    assocOrigin28.AssociatedPoint = NXOpen.Point.Null
    assocOrigin28.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.XOffsetFactor = 0.0
    assocOrigin28.YOffsetFactor = 0.0
    assocOrigin28.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder46.Origin.SetAssociativeOrigin(assocOrigin28)
    
    point93 = NXOpen.Point3d(66.0, -106.76025981810768, 20.998790055531845)
    sketchRapidDimensionBuilder46.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point93)
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder46.Style.DimensionStyle.TextCentered = False
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject39 = sketchRapidDimensionBuilder46.Commit()
    
    theSession.DeleteUndoMark(markId225, None)
    
    theSession.SetUndoMarkName(markId224, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId224, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder46.Destroy()
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder47 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines257 = []
    sketchRapidDimensionBuilder47.AppendedText.SetBefore(lines257)
    
    lines258 = []
    sketchRapidDimensionBuilder47.AppendedText.SetAfter(lines258)
    
    lines259 = []
    sketchRapidDimensionBuilder47.AppendedText.SetAbove(lines259)
    
    lines260 = []
    sketchRapidDimensionBuilder47.AppendedText.SetBelow(lines260)
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder47.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId226, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder47.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1281 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1282 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1283 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1284 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1285 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1286 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1287 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1288 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1289 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1290 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder47.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1291 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1292 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1293 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1294 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1295 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1296 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1297 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1298 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1299 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1300 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    expression102 = workPart.Expressions.FindObject("p35")
    expression102.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId226, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId227, None)
    
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId226, "Edit Driving Value")
    
    point1_160 = NXOpen.Point3d(66.0, -112.90000000000001, 20.985064757639336)
    point2_160 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_160, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_160)
    
    point1_161 = NXOpen.Point3d(66.0, -112.90000000000001, 20.985064757639336)
    point2_161 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_161, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_161)
    
    point1_162 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_162 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_162, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_162)
    
    dimensionlinearunits1301 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1302 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1303 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1304 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1305 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1306 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    datumAxis2 = workPart.Datums.FindObject("SKETCH(14:1B) X axis")
    point94 = NXOpen.Point3d(66.0, -113.63947200653864, 25.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(datumAxis2, workPart.ModelingViews.WorkView, point94)
    
    point1_163 = NXOpen.Point3d(66.0, -113.63947200653864, 25.0)
    point2_163 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, datumAxis2, workPart.ModelingViews.WorkView, point1_163, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_163)
    
    point1_164 = NXOpen.Point3d(66.0, -112.90000000000001, 20.985064757639336)
    point2_164 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_164, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_164)
    
    point1_165 = NXOpen.Point3d(66.0, -113.63947200653864, 25.0)
    point2_165 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, datumAxis2, workPart.ModelingViews.WorkView, point1_165, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_165)
    
    point1_166 = NXOpen.Point3d(66.0, -112.90000000000001, 20.985064757639336)
    point2_166 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_166, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_166)
    
    dimensionlinearunits1307 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1308 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1309 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1310 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1311 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1312 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1313 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1314 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1315 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1316 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1317 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1318 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin29 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin29.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin29.View = NXOpen.View.Null
    assocOrigin29.ViewOfGeometry = workPart.ModelingViews.WorkView
    point95 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin29.PointOnGeometry = point95
    assocOrigin29.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.DimensionLine = 0
    assocOrigin29.AssociatedView = NXOpen.View.Null
    assocOrigin29.AssociatedPoint = NXOpen.Point.Null
    assocOrigin29.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.XOffsetFactor = 0.0
    assocOrigin29.YOffsetFactor = 0.0
    assocOrigin29.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder47.Origin.SetAssociativeOrigin(assocOrigin29)
    
    point96 = NXOpen.Point3d(66.0, -121.01359154665528, 23.968234165645931)
    sketchRapidDimensionBuilder47.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point96)
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.TextCentered = False
    
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject40 = sketchRapidDimensionBuilder47.Commit()
    
    theSession.DeleteUndoMark(markId229, None)
    
    theSession.SetUndoMarkName(markId228, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId228, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder47.Destroy()
    
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder48 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines261 = []
    sketchRapidDimensionBuilder48.AppendedText.SetBefore(lines261)
    
    lines262 = []
    sketchRapidDimensionBuilder48.AppendedText.SetAfter(lines262)
    
    lines263 = []
    sketchRapidDimensionBuilder48.AppendedText.SetAbove(lines263)
    
    lines264 = []
    sketchRapidDimensionBuilder48.AppendedText.SetBelow(lines264)
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder48.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder48.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder48.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder48.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId230, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder48.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1319 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1320 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1321 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1322 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1323 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1324 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1325 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1326 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1327 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1328 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder48.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder48.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder48.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1329 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1330 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1331 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1332 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1333 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1334 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1335 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1336 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1337 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1338 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    expression103 = workPart.Expressions.FindObject("p36")
    expression103.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId230, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId231, None)
    
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId230, "Edit Driving Value")
    
    expression103.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId232, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId233, None)
    
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId232, "Edit Driving Value")
    
    expression103.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId234, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId235, None)
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId234, "Edit Driving Value")
    
    sketchRapidDimensionBuilder48.Destroy()
    
    theSession.UndoToMark(markId236, None)
    
    theSession.DeleteUndoMark(markId236, None)
    
    sketchRapidDimensionBuilder48.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch17 = theSession.ActiveSketch
    
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression104 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies91 = [NXOpen.Body.Null] * 1 
    targetBodies91[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies91)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("13.5")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies92 = [NXOpen.Body.Null] * 1 
    targetBodies92[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies92)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId238, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features7 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature7 = feature15
    features7[0] = sketchFeature7
    curveFeatureRule7 = workPart.ScRuleFactory.CreateRuleCurveFeature(features7)
    
    section8.AllowSelfIntersection(True)
    
    rules7 = [None] * 1 
    rules7[0] = curveFeatureRule7
    helpPoint7 = NXOpen.Point3d(66.0, -111.40698554047276, 20.954856838522193)
    section8.AddToSection(rules7, arc3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId240, None)
    
    direction20 = workPart.Directions.CreateDirection(sketch17, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction20
    
    targetBodies93 = [NXOpen.Body.Null] * 1 
    targetBodies93[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies93)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies94 = [NXOpen.Body.Null] * 1 
    targetBodies94[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies94)
    
    expression105 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId239, None)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies95 = [NXOpen.Body.Null] * 1 
    targetBodies95[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies95)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies96 = [NXOpen.Body.Null] * 1 
    targetBodies96[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies96)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies97 = [NXOpen.Body.Null] * 1 
    targetBodies97[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies97)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies98 = [NXOpen.Body.Null] * 1 
    targetBodies98[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies98)
    
    targetBodies99 = []
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies99)
    
    direction21 = extrudeBuilder8.Direction
    
    success4 = direction21.ReverseDirection()
    
    extrudeBuilder8.Direction = direction21
    
    targetBodies100 = [NXOpen.Body.Null] * 1 
    targetBodies100[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies100)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies101 = [NXOpen.Body.Null] * 1 
    targetBodies101[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies101)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies102 = [NXOpen.Body.Null] * 1 
    targetBodies102[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies102)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies103 = [NXOpen.Body.Null] * 1 
    targetBodies103[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies103)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies104 = [NXOpen.Body.Null] * 1 
    targetBodies104[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies104)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies105 = [NXOpen.Body.Null] * 1 
    targetBodies105[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies105)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies106 = [NXOpen.Body.Null] * 1 
    targetBodies106[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies106)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies107 = [NXOpen.Body.Null] * 1 
    targetBodies107[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies107)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies108 = [NXOpen.Body.Null] * 1 
    targetBodies108[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies108)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies109 = [NXOpen.Body.Null] * 1 
    targetBodies109[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies109)
    
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId241, None)
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    feature16 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId242, None)
    
    theSession.SetUndoMarkName(markId238, "Extrude")
    
    expression106 = extrudeBuilder8.Limits.StartExtend.Value
    expression107 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression104)
    
    workPart.Expressions.Delete(expression105)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder11 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal28 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane28 = workPart.Planes.CreatePlane(origin30, normal28, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder11.PlaneReference = plane28
    
    expression108 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression109 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder10 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder10.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId243, "Create Sketch Dialog")
    
    scalar18 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge22 = extrude3.FindObject("EDGE * 160 * 170 {(66,-115.9,25)(66,-115.9,15)(66,-115.9,5) EXTRUDE(2)}")
    point97 = workPart.Points.CreatePoint(edge22, scalar18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction22 = workPart.Directions.CreateDirection(edge18, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform13 = workPart.Xforms.CreateXformByPlaneXDirPoint(face6, direction22, point97, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem13 = workPart.CoordinateSystems.CreateCoordinateSystem(xform13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder11.Csystem = cartesianCoordinateSystem13
    
    origin31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal29 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane29 = workPart.Planes.CreatePlane(origin31, normal29, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane29.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom27 = [NXOpen.NXObject.Null] * 1 
    geom27[0] = face6
    plane29.SetGeometry(geom27)
    
    plane29.SetFlip(False)
    
    plane29.SetExpression(None)
    
    plane29.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane29.Evaluate()
    
    origin32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal30 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane30 = workPart.Planes.CreatePlane(origin32, normal30, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression110 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression111 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane30.SynchronizeToPlane(plane29)
    
    scalar19 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point98 = workPart.Points.CreatePoint(edge22, scalar19, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane30.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom28 = [NXOpen.NXObject.Null] * 1 
    geom28[0] = face6
    plane30.SetGeometry(geom28)
    
    plane30.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane30.Evaluate()
    
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId244, None)
    
    markId245 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject41 = sketchInPlaceBuilder11.Commit()
    
    sketch18 = nXObject41
    feature17 = sketch18.Feature
    
    markId246 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs16 = theSession.UpdateManager.DoUpdate(markId246)
    
    sketch18.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId245, None)
    
    theSession.SetUndoMarkName(markId243, "Create Sketch")
    
    sketchInPlaceBuilder11.Destroy()
    
    sketchAlongPathBuilder10.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression109)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point98)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression108)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane28.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression111)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression110)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane30.DestroyPlane()
    
    scaleAboutPoint446 = NXOpen.Point3d(4.4705986358327348, -9.7869862027685812, 0.0)
    viewCenter446 = NXOpen.Point3d(-4.4705986358323946, 9.7869862027686114, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint446, viewCenter446)
    
    scaleAboutPoint447 = NXOpen.Point3d(3.4798173165401249, -7.8295889622148573, 0.0)
    viewCenter447 = NXOpen.Point3d(-3.4798173165397626, 7.8295889622148902, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint447, viewCenter447)
    
    scaleAboutPoint448 = NXOpen.Point3d(2.7838538532321193, -6.1863418960709939, 0.0)
    viewCenter448 = NXOpen.Point3d(-2.7838538532317894, 6.1863418960710206, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint448, viewCenter448)
    
    scaleAboutPoint449 = NXOpen.Point3d(2.2270830825857275, -4.9490735168567959, 0.0)
    viewCenter449 = NXOpen.Point3d(-2.2270830825854055, 4.9490735168568225, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint449, viewCenter449)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = 0.85927127769702805
    rotMatrix19.Xy = 0.51138581324113774
    rotMatrix19.Xz = -0.011722684872364008
    rotMatrix19.Yx = -0.036349496470696192
    rotMatrix19.Yy = 0.083904658386414407
    rotMatrix19.Yz = 0.99581058560721569
    rotMatrix19.Zx = 0.51022699402446703
    rotMatrix19.Zy = -0.85524532054654301
    rotMatrix19.Zz = 0.090685479829999832
    translation19 = NXOpen.Point3d(-29.08441118663956, -11.898196625225609, -140.77561696873568)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 5.3461184690861501)
    
    # ----------------------------------------------
    #   Menu: View->Orient View to Sketch
    # ----------------------------------------------
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.97210407634377338
    rotMatrix20.Xy = 0.23454249625849369
    rotMatrix20.Xz = -0.0018660666263714922
    rotMatrix20.Yx = -0.0090062142379971621
    rotMatrix20.Yy = 0.045275611120544138
    rotMatrix20.Yz = 0.99893393532443409
    rotMatrix20.Zx = 0.23437694609521412
    rotMatrix20.Zy = -0.97105094433119021
    rotMatrix20.Zz = 0.046124946098455064
    translation20 = NXOpen.Point3d(-50.193047639759691, -21.708443376531633, -129.72473417378416)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 5.3461184690861518)
    
    scaleAboutPoint450 = NXOpen.Point3d(-9.8981470337134621, -6.1863418960709913, 0.0)
    viewCenter450 = NXOpen.Point3d(9.8981470337137747, 6.186341896071025, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint450, viewCenter450)
    
    scaleAboutPoint451 = NXOpen.Point3d(-12.372683792141864, -7.9185176269708686, 0.0)
    viewCenter451 = NXOpen.Point3d(12.37268379214218, 7.9185176269709103, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint451, viewCenter451)
    
    scaleAboutPoint452 = NXOpen.Point3d(-15.465854740177363, -9.975476307414489, 0.0)
    viewCenter452 = NXOpen.Point3d(15.465854740177686, 9.9754763074145227, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint452, viewCenter452)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = 0.98254581620564208
    rotMatrix21.Xy = 0.18545218301649921
    rotMatrix21.Xz = 0.014532958102339118
    rotMatrix21.Yx = -0.044876795555201542
    rotMatrix21.Yy = 0.16049298621187982
    rotMatrix21.Yz = 0.98601626487471883
    rotMatrix21.Zx = 0.18052643096645479
    rotMatrix21.Zy = -0.96945834835293987
    rotMatrix21.Zz = 0.16601421183532952
    translation21 = NXOpen.Point3d(-63.732110521182875, -18.243425660017575, -130.29454864381202)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 2.73721265617211)
    
    scaleAboutPoint453 = NXOpen.Point3d(-24.842029176409998, -29.481785598463397, 0.0)
    viewCenter453 = NXOpen.Point3d(24.842029176410303, 29.481785598463421, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint453, viewCenter453)
    
    scaleAboutPoint454 = NXOpen.Point3d(-19.796294067427073, -24.900026131685809, 0.0)
    viewCenter454 = NXOpen.Point3d(19.796294067427397, 24.900026131685827, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint454, viewCenter454)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId247 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder12 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal31 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane31 = workPart.Planes.CreatePlane(origin33, normal31, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder12.PlaneReference = plane31
    
    expression112 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression113 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder11 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder11.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId247, "Create Sketch Dialog")
    
    scalar20 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point99 = workPart.Points.CreatePoint(edge17, scalar20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction23 = workPart.Directions.CreateDirection(edge18, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform14 = workPart.Xforms.CreateXformByPlaneXDirPoint(face6, direction23, point99, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem14 = workPart.CoordinateSystems.CreateCoordinateSystem(xform14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder12.Csystem = cartesianCoordinateSystem14
    
    origin34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal32 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane32 = workPart.Planes.CreatePlane(origin34, normal32, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane32.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom29 = [NXOpen.NXObject.Null] * 1 
    geom29[0] = face6
    plane32.SetGeometry(geom29)
    
    plane32.SetFlip(False)
    
    plane32.SetExpression(None)
    
    plane32.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane32.Evaluate()
    
    origin35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal33 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane33 = workPart.Planes.CreatePlane(origin35, normal33, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression114 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression115 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane33.SynchronizeToPlane(plane32)
    
    scalar21 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point100 = workPart.Points.CreatePoint(edge17, scalar21, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane33.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom30 = [NXOpen.NXObject.Null] * 1 
    geom30[0] = face6
    plane33.SetGeometry(geom30)
    
    plane33.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane33.Evaluate()
    
    markId248 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId248, None)
    
    markId249 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId250 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject42 = sketchInPlaceBuilder12.Commit()
    
    sketch19 = nXObject42
    feature18 = sketch19.Feature
    
    markId251 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs17 = theSession.UpdateManager.DoUpdate(markId251)
    
    sketch19.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId249, None)
    
    theSession.SetUndoMarkName(markId247, "Create Sketch")
    
    sketchInPlaceBuilder12.Destroy()
    
    sketchAlongPathBuilder11.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression113)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point100)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression112)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane31.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression115)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression114)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane33.DestroyPlane()
    
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = 0.8955770589058959
    rotMatrix22.Xy = 0.44311743067762949
    rotMatrix22.Xz = -0.039858175963304293
    rotMatrix22.Yx = -0.049079616203245996
    rotMatrix22.Yy = 0.18743883930053423
    rotMatrix22.Yz = 0.98104937327079056
    rotMatrix22.Zx = 0.44219104789084956
    rotMatrix22.Zy = -0.87664908837648703
    rotMatrix22.Zz = 0.18961395785613372
    translation22 = NXOpen.Point3d(-25.952186974888587, -10.192997301073881, -141.19286180636465)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 4.2768947752689197)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = 0.98072797496074882
    rotMatrix23.Xy = 0.19536350507943576
    rotMatrix23.Xz = -0.0023958323118747917
    rotMatrix23.Yx = -0.012180056119380871
    rotMatrix23.Yy = 0.073373570845260819
    rotMatrix23.Yz = 0.997230146623308
    rotMatrix23.Zx = 0.19499816758707786
    rotMatrix23.Zy = -0.97798232089567627
    rotMatrix23.Zz = 0.074339052006258094
    translation23 = NXOpen.Point3d(-47.144003642742852, -19.77676214737901, -128.6948484991687)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 4.2768947752689197)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId252 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId253 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId253, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint25 = NXOpen.Point3d(61.566968441432067, -115.90000000000001, 25.0)
    endPoint25 = NXOpen.Point3d(64.419779993660711, -115.90000000000001, 25.0)
    line26 = workPart.Curves.CreateLine(startPoint25, endPoint25)
    
    startPoint26 = NXOpen.Point3d(64.419779993660711, -115.90000000000001, 25.0)
    endPoint26 = NXOpen.Point3d(64.419779993660711, -115.90000000000001, 5.0)
    line27 = workPart.Curves.CreateLine(startPoint26, endPoint26)
    
    startPoint27 = NXOpen.Point3d(64.419779993660711, -115.90000000000001, 5.0)
    endPoint27 = NXOpen.Point3d(61.566968441432067, -115.90000000000001, 5.0)
    line28 = workPart.Curves.CreateLine(startPoint27, endPoint27)
    
    startPoint28 = NXOpen.Point3d(61.566968441432067, -115.90000000000001, 5.0)
    endPoint28 = NXOpen.Point3d(61.566968441432067, -115.90000000000001, 25.0)
    line29 = workPart.Curves.CreateLine(startPoint28, endPoint28)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line27, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line28, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line29, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_26.Geometry = line26
    geom1_26.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_26.SplineDefiningPointIndex = 0
    geom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_26.Geometry = line27
    geom2_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint56 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_26, geom2_26)
    
    geom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_27.Geometry = line27
    geom1_27.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_27.SplineDefiningPointIndex = 0
    geom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_27.Geometry = line28
    geom2_27.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint57 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_27, geom2_27)
    
    geom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_28.Geometry = line28
    geom1_28.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_28.SplineDefiningPointIndex = 0
    geom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_28.Geometry = line29
    geom2_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint58 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_28, geom2_28)
    
    geom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_29.Geometry = line29
    geom1_29.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_29.SplineDefiningPointIndex = 0
    geom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_29.Geometry = line26
    geom2_29.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint59 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_29, geom2_29)
    
    geom31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom31.Geometry = line26
    geom31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint60 = theSession.ActiveSketch.CreateHorizontalConstraint(geom31)
    
    conGeom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_29.Geometry = line26
    conGeom1_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_29.SplineDefiningPointIndex = 0
    conGeom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_29.Geometry = line27
    conGeom2_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint61 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_29, conGeom2_29)
    
    conGeom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_30.Geometry = line27
    conGeom1_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_30.SplineDefiningPointIndex = 0
    conGeom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_30.Geometry = line28
    conGeom2_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint62 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_30, conGeom2_30)
    
    conGeom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_31.Geometry = line28
    conGeom1_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_31.SplineDefiningPointIndex = 0
    conGeom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_31.Geometry = line29
    conGeom2_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint63 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_31, conGeom2_31)
    
    conGeom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_32.Geometry = line29
    conGeom1_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_32.SplineDefiningPointIndex = 0
    conGeom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_32.Geometry = line26
    conGeom2_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint64 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_32, conGeom2_32)
    
    conGeom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_33.Geometry = line26
    conGeom1_33.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_33.SplineDefiningPointIndex = 0
    conGeom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_33.Geometry = edge17
    conGeom2_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_33.SplineDefiningPointIndex = 0
    help5 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help5.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help5.Point.X = 61.566968441432067
    help5.Point.Y = -115.90000000000001
    help5.Point.Z = 25.0
    help5.Parameter = 0.0
    sketchHelpedGeometricConstraint5 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_33, conGeom2_33, help5)
    
    conGeom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_34.Geometry = line28
    conGeom1_34.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_34.SplineDefiningPointIndex = 0
    conGeom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_34.Geometry = line16
    conGeom2_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_34.SplineDefiningPointIndex = 0
    help6 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help6.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help6.Point.X = 64.419779993660711
    help6.Point.Y = -115.90000000000001
    help6.Point.Z = 5.0
    help6.Parameter = 0.0
    sketchHelpedGeometricConstraint6 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_34, conGeom2_34, help6)
    
    dimObject1_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_16.Geometry = line27
    dimObject1_16.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_16.AssocValue = 0
    dimObject1_16.HelpPoint.X = 0.0
    dimObject1_16.HelpPoint.Y = 0.0
    dimObject1_16.HelpPoint.Z = 0.0
    dimObject1_16.View = NXOpen.NXObject.Null
    dimObject2_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_13.Geometry = line27
    dimObject2_13.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_13.AssocValue = 0
    dimObject2_13.HelpPoint.X = 0.0
    dimObject2_13.HelpPoint.Y = 0.0
    dimObject2_13.HelpPoint.Z = 0.0
    dimObject2_13.View = NXOpen.NXObject.Null
    dimOrigin16 = NXOpen.Point3d(62.315449521926318, -115.90000000000001, 15.0)
    sketchDimensionalConstraint16 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_16, dimObject2_13, dimOrigin16, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint13 = sketchDimensionalConstraint16
    dimension16 = sketchHelpedDimensionalConstraint13.AssociatedDimension
    
    expression116 = sketchHelpedDimensionalConstraint13.AssociatedExpression
    
    dimObject1_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_17.Geometry = line26
    dimObject1_17.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_17.AssocValue = 0
    dimObject1_17.HelpPoint.X = 0.0
    dimObject1_17.HelpPoint.Y = 0.0
    dimObject1_17.HelpPoint.Z = 0.0
    dimObject1_17.View = NXOpen.NXObject.Null
    dimObject2_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_14.Geometry = line26
    dimObject2_14.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_14.AssocValue = 0
    dimObject2_14.HelpPoint.X = 0.0
    dimObject2_14.HelpPoint.Y = 0.0
    dimObject2_14.HelpPoint.Z = 0.0
    dimObject2_14.View = NXOpen.NXObject.Null
    dimOrigin17 = NXOpen.Point3d(62.993374217546389, -115.90000000000001, 22.895669528265607)
    sketchDimensionalConstraint17 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_17, dimObject2_14, dimOrigin17, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint14 = sketchDimensionalConstraint17
    dimension17 = sketchHelpedDimensionalConstraint14.AssociatedDimension
    
    expression117 = sketchHelpedDimensionalConstraint14.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms13 = [NXOpen.SmartObject.Null] * 4 
    geoms13[0] = line26
    geoms13[1] = line27
    geoms13[2] = line28
    geoms13[3] = line29
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms13)
    
    geoms14 = [NXOpen.SmartObject.Null] * 4 
    geoms14[0] = line26
    geoms14[1] = line27
    geoms14[2] = line28
    geoms14[3] = line29
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms14)
    
    scaleAboutPoint455 = NXOpen.Point3d(-6.5575224098351104, -7.7329273700887526, 0.0)
    viewCenter455 = NXOpen.Point3d(6.5575224098354328, 7.7329273700887731, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint455, viewCenter455)
    
    scaleAboutPoint456 = NXOpen.Point3d(-5.2460179278680545, -6.2358326312395631, 0.0)
    viewCenter456 = NXOpen.Point3d(5.2460179278683796, 6.235832631239588, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint456, viewCenter456)
    
    scaleAboutPoint457 = NXOpen.Point3d(-4.1968143422944104, -5.028258693126503, 0.0)
    viewCenter457 = NXOpen.Point3d(4.1968143422947408, 5.0282586931265261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint457, viewCenter457)
    
    scaleAboutPoint458 = NXOpen.Point3d(-3.2941033328197298, -4.0542810250090842, 0.0)
    viewCenter458 = NXOpen.Point3d(3.2941033328200566, 4.0542810250091117, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint458, viewCenter458)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId254 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder49 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines265 = []
    sketchRapidDimensionBuilder49.AppendedText.SetBefore(lines265)
    
    lines266 = []
    sketchRapidDimensionBuilder49.AppendedText.SetAfter(lines266)
    
    lines267 = []
    sketchRapidDimensionBuilder49.AppendedText.SetAbove(lines267)
    
    lines268 = []
    sketchRapidDimensionBuilder49.AppendedText.SetBelow(lines268)
    
    sketchRapidDimensionBuilder49.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder49.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder49.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines269 = []
    sketchRapidDimensionBuilder49.AppendedText.SetBefore(lines269)
    
    lines270 = []
    sketchRapidDimensionBuilder49.AppendedText.SetAfter(lines270)
    
    lines271 = []
    sketchRapidDimensionBuilder49.AppendedText.SetAbove(lines271)
    
    lines272 = []
    sketchRapidDimensionBuilder49.AppendedText.SetBelow(lines272)
    
    theSession.SetUndoMarkName(markId254, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder49.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder49.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1339 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1340 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1341 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1342 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1343 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1344 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1345 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1346 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1347 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1348 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder49.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder49.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder49.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder49.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder49.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1349 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1350 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1351 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1352 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1353 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1354 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1355 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1356 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1357 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1358 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    point101 = NXOpen.Point3d(64.419779993660754, -115.90000000000009, 23.430280346801066)
    sketchRapidDimensionBuilder49.FirstAssociativity.SetValue(line27, workPart.ModelingViews.WorkView, point101)
    
    point1_167 = NXOpen.Point3d(64.419779993660711, -115.90000000000001, 25.0)
    point2_167 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder49.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line27, workPart.ModelingViews.WorkView, point1_167, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_167)
    
    point1_168 = NXOpen.Point3d(64.419779993660711, -115.90000000000001, 5.0)
    point2_168 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder49.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, workPart.ModelingViews.WorkView, point1_168, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_168)
    
    dimensionlinearunits1359 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1360 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1361 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1362 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1363 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1364 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    point1_169 = NXOpen.Point3d(66.0, -115.90000000000001, 25.0)
    point2_169 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder49.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge22, workPart.ModelingViews.WorkView, point1_169, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_169)
    
    point1_170 = NXOpen.Point3d(64.419779993660754, -115.90000000000009, 23.430280346801066)
    point2_170 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder49.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_170, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_170)
    
    point1_171 = NXOpen.Point3d(66.0, -115.90000000000001, 25.0)
    point2_171 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder49.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge22, workPart.ModelingViews.WorkView, point1_171, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_171)
    
    point1_172 = NXOpen.Point3d(64.419779993660754, -115.90000000000009, 23.430280346801066)
    point2_172 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder49.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_172, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_172)
    
    point1_173 = NXOpen.Point3d(66.0, -115.90000000000001, 25.0)
    point2_173 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder49.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge22, workPart.ModelingViews.WorkView, point1_173, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_173)
    
    dimensionlinearunits1365 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1366 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1367 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1368 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1369 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1370 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1371 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1372 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1373 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1374 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1375 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1376 = sketchRapidDimensionBuilder49.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder49.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin30 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin30.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin30.View = NXOpen.View.Null
    assocOrigin30.ViewOfGeometry = workPart.ModelingViews.WorkView
    point102 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin30.PointOnGeometry = point102
    assocOrigin30.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin30.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin30.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.DimensionLine = 0
    assocOrigin30.AssociatedView = NXOpen.View.Null
    assocOrigin30.AssociatedPoint = NXOpen.Point.Null
    assocOrigin30.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin30.XOffsetFactor = 0.0
    assocOrigin30.YOffsetFactor = 0.0
    assocOrigin30.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder49.Origin.SetAssociativeOrigin(assocOrigin30)
    
    point103 = NXOpen.Point3d(65.45367258811136, -115.90000000000001, 26.543050082792504)
    sketchRapidDimensionBuilder49.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point103)
    
    sketchRapidDimensionBuilder49.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder49.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder49.Style.DimensionStyle.TextCentered = False
    
    markId255 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject43 = sketchRapidDimensionBuilder49.Commit()
    
    theSession.DeleteUndoMark(markId255, None)
    
    theSession.SetUndoMarkName(markId254, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId254, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder49.Destroy()
    
    markId256 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder50 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines273 = []
    sketchRapidDimensionBuilder50.AppendedText.SetBefore(lines273)
    
    lines274 = []
    sketchRapidDimensionBuilder50.AppendedText.SetAfter(lines274)
    
    lines275 = []
    sketchRapidDimensionBuilder50.AppendedText.SetAbove(lines275)
    
    lines276 = []
    sketchRapidDimensionBuilder50.AppendedText.SetBelow(lines276)
    
    sketchRapidDimensionBuilder50.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder50.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder50.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder50.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder50.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId256, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder50.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder50.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1377 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1378 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1379 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1380 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1381 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1382 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1383 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1384 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1385 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1386 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder50.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder50.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder50.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder50.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder50.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1387 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1388 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1389 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1390 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1391 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1392 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1393 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1394 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1395 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1396 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    expression118 = workPart.Expressions.FindObject("p39")
    expression118.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId256, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId257 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId257, None)
    
    markId258 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId256, "Edit Driving Value")
    
    point104 = NXOpen.Point3d(61.647188447771399, -115.90000000000009, 22.736055964020313)
    sketchRapidDimensionBuilder50.FirstAssociativity.SetValue(line29, workPart.ModelingViews.WorkView, point104)
    
    point1_174 = NXOpen.Point3d(61.647188447771356, -115.90000000000001, 25.0)
    point2_174 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder50.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line29, workPart.ModelingViews.WorkView, point1_174, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_174)
    
    point1_175 = NXOpen.Point3d(61.647188447771356, -115.90000000000001, 5.0)
    point2_175 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder50.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line29, workPart.ModelingViews.WorkView, point1_175, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_175)
    
    dimensionlinearunits1397 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1398 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1399 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1400 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1401 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1402 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    edge23 = extrude3.FindObject("EDGE * 160 * 190 {(60.1,-115.9,25)(60.1,-115.9,15)(60.1,-115.9,5) EXTRUDE(2)}")
    point1_176 = NXOpen.Point3d(60.099999999999994, -115.90000000000001, 25.0)
    point2_176 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder50.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge23, workPart.ModelingViews.WorkView, point1_176, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_176)
    
    point1_177 = NXOpen.Point3d(61.647188447771399, -115.90000000000009, 22.736055964020313)
    point2_177 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder50.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line29, workPart.ModelingViews.WorkView, point1_177, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_177)
    
    point1_178 = NXOpen.Point3d(60.099999999999994, -115.90000000000001, 25.0)
    point2_178 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder50.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge23, workPart.ModelingViews.WorkView, point1_178, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_178)
    
    point1_179 = NXOpen.Point3d(61.647188447771399, -115.90000000000009, 22.736055964020313)
    point2_179 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder50.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line29, workPart.ModelingViews.WorkView, point1_179, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_179)
    
    point1_180 = NXOpen.Point3d(60.099999999999994, -115.90000000000001, 25.0)
    point2_180 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder50.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge23, workPart.ModelingViews.WorkView, point1_180, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_180)
    
    dimensionlinearunits1403 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1404 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1405 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1406 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1407 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1408 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1409 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1410 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1411 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1412 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1413 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1414 = sketchRapidDimensionBuilder50.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder50.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin31 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin31.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin31.View = NXOpen.View.Null
    assocOrigin31.ViewOfGeometry = workPart.ModelingViews.WorkView
    point105 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin31.PointOnGeometry = point105
    assocOrigin31.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin31.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin31.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.DimensionLine = 0
    assocOrigin31.AssociatedView = NXOpen.View.Null
    assocOrigin31.AssociatedPoint = NXOpen.Point.Null
    assocOrigin31.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin31.XOffsetFactor = 0.0
    assocOrigin31.YOffsetFactor = 0.0
    assocOrigin31.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder50.Origin.SetAssociativeOrigin(assocOrigin31)
    
    point106 = NXOpen.Point3d(58.752142809952218, -115.90000000000001, 22.57352383817134)
    sketchRapidDimensionBuilder50.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point106)
    
    sketchRapidDimensionBuilder50.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder50.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder50.Style.DimensionStyle.TextCentered = False
    
    markId259 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject44 = sketchRapidDimensionBuilder50.Commit()
    
    theSession.DeleteUndoMark(markId259, None)
    
    theSession.SetUndoMarkName(markId258, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId258, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder50.Destroy()
    
    markId260 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder51 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines277 = []
    sketchRapidDimensionBuilder51.AppendedText.SetBefore(lines277)
    
    lines278 = []
    sketchRapidDimensionBuilder51.AppendedText.SetAfter(lines278)
    
    lines279 = []
    sketchRapidDimensionBuilder51.AppendedText.SetAbove(lines279)
    
    lines280 = []
    sketchRapidDimensionBuilder51.AppendedText.SetBelow(lines280)
    
    sketchRapidDimensionBuilder51.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder51.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder51.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder51.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder51.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId260, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder51.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder51.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1415 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1416 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1417 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1418 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1419 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1420 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1421 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1422 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1423 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1424 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder51.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder51.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder51.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder51.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder51.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1425 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1426 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1427 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1428 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1429 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1430 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1431 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1432 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1433 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1434 = sketchRapidDimensionBuilder51.Style.UnitsStyle.DimensionLinearUnits
    
    expression119 = workPart.Expressions.FindObject("p40")
    expression119.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId260, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId261 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId261, None)
    
    markId262 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId260, "Edit Driving Value")
    
    sketchRapidDimensionBuilder51.Destroy()
    
    theSession.UndoToMark(markId262, None)
    
    theSession.DeleteUndoMark(markId262, None)
    
    sketchRapidDimensionBuilder51.Destroy()
    
    scaleAboutPoint459 = NXOpen.Point3d(-0.40542810250074862, -4.5610661531352266, 0.0)
    viewCenter459 = NXOpen.Point3d(0.4054281025010727, 4.5610661531352479, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint459, viewCenter459)
    
    scaleAboutPoint460 = NXOpen.Point3d(-0.88687397422057923, -5.447940127355964, 0.0)
    viewCenter460 = NXOpen.Point3d(0.88687397422090331, 5.4479401273559853, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint460, viewCenter460)
    
    scaleAboutPoint461 = NXOpen.Point3d(-1.2273702321803375, -6.8099251591949557, 0.0)
    viewCenter461 = NXOpen.Point3d(1.2273702321806415, 6.8099251591949752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint461, viewCenter461)
    
    scaleAboutPoint462 = NXOpen.Point3d(-2.2270830825853998, -9.2547674765222183, 0.0)
    viewCenter462 = NXOpen.Point3d(2.227083082585716, 9.2547674765222396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint462, viewCenter462)
    
    scaleAboutPoint463 = NXOpen.Point3d(-3.1550343669960572, -11.815913021495618, 0.0)
    viewCenter463 = NXOpen.Point3d(3.1550343669963739, 11.815913021495639, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint463, viewCenter463)
    
    scaleAboutPoint464 = NXOpen.Point3d(-3.9437929587451106, -14.769891276869521, 0.0)
    viewCenter464 = NXOpen.Point3d(3.9437929587454268, 14.76989127686954, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint464, viewCenter464)
    
    scaleAboutPoint465 = NXOpen.Point3d(-7.6362657779624987, -18.849010464591352, 0.0)
    viewCenter465 = NXOpen.Point3d(7.6362657779628043, 18.849010464591366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint465, viewCenter465)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch20 = theSession.ActiveSketch
    
    markId263 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId264 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section9
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression120 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies110 = [NXOpen.Body.Null] * 1 
    targetBodies110[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies110)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies111 = [NXOpen.Body.Null] * 1 
    targetBodies111[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies111)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId264, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scaleAboutPoint466 = NXOpen.Point3d(-13.424361914473934, -6.1863418960709975, 0.0)
    viewCenter466 = NXOpen.Point3d(13.424361914474256, 6.1863418960710188, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint466, viewCenter466)
    
    scaleAboutPoint467 = NXOpen.Point3d(-10.739489531579114, -4.9490735168567976, 0.0)
    viewCenter467 = NXOpen.Point3d(10.739489531579437, 4.949073516856819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint467, viewCenter467)
    
    scaleAboutPoint468 = NXOpen.Point3d(-8.5915916252632645, -3.9592588134854338, 0.0)
    viewCenter468 = NXOpen.Point3d(8.5915916252635753, 3.9592588134854543, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint468, viewCenter468)
    
    scaleAboutPoint469 = NXOpen.Point3d(-6.8415992297026964, -3.1674070507883441, 0.0)
    viewCenter469 = NXOpen.Point3d(6.8415992297030046, 3.1674070507883658, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint469, viewCenter469)
    
    markId265 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId266 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features8 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature8 = feature18
    features8[0] = sketchFeature8
    curveFeatureRule8 = workPart.ScRuleFactory.CreateRuleCurveFeature(features8)
    
    section9.AllowSelfIntersection(True)
    
    rules8 = [None] * 1 
    rules8[0] = curveFeatureRule8
    helpPoint8 = NXOpen.Point3d(62.754258031418772, -115.90000000000025, 25.00000000000005)
    section9.AddToSection(rules8, line26, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint8, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId266, None)
    
    direction24 = workPart.Directions.CreateDirection(sketch20, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction24
    
    targetBodies112 = [NXOpen.Body.Null] * 1 
    targetBodies112[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies112)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies113 = [NXOpen.Body.Null] * 1 
    targetBodies113[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies113)
    
    expression121 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId265, None)
    
    scaleAboutPoint470 = NXOpen.Point3d(-6.6642244348585464, -3.3447818456324949, 0.0)
    viewCenter470 = NXOpen.Point3d(6.6642244348588617, 3.3447818456325167, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint470, viewCenter470)
    
    scaleAboutPoint471 = NXOpen.Point3d(-8.3302805435732203, -4.1809773070406209, 0.0)
    viewCenter471 = NXOpen.Point3d(8.3302805435735383, 4.1809773070406431, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint471, viewCenter471)
    
    scaleAboutPoint472 = NXOpen.Point3d(-10.412850679466571, -5.2658142219356314, 0.0)
    viewCenter472 = NXOpen.Point3d(10.412850679466874, 5.2658142219356519, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint472, viewCenter472)
    
    scaleAboutPoint473 = NXOpen.Point3d(-13.016063349333251, -6.6317585125881076, 0.0)
    viewCenter473 = NXOpen.Point3d(13.016063349333558, 6.6317585125881289, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint473, viewCenter473)
    
    scaleAboutPoint474 = NXOpen.Point3d(-16.146352348745175, -8.4752883976172697, 0.0)
    viewCenter474 = NXOpen.Point3d(16.146352348745491, 8.475288397617291, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint474, viewCenter474)
    
    scaleAboutPoint475 = NXOpen.Point3d(-16.23914747718624, -14.847220550570414, 0.0)
    viewCenter475 = NXOpen.Point3d(16.239147477186542, 14.847220550570434, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint475, viewCenter475)
    
    scaleAboutPoint476 = NXOpen.Point3d(-20.298934346482838, -19.042333648843552, 0.0)
    viewCenter476 = NXOpen.Point3d(20.298934346483151, 19.042333648843584, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint476, viewCenter476)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = 0.80933828850045608
    rotMatrix24.Xy = 0.58444280143481209
    rotMatrix24.Xz = -0.058293624164081285
    rotMatrix24.Yx = -0.051637614349896201
    rotMatrix24.Yy = 0.16966897967218705
    rotMatrix24.Yz = 0.98414734370481949
    rotMatrix24.Zx = 0.58506845031278709
    rotMatrix24.Zy = -0.79349798310268571
    rotMatrix24.Zz = 0.16749883360957027
    translation24 = NXOpen.Point3d(-31.786225691720567, -18.117672825574701, -143.53861501975123)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 2.1897701249376875)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies114 = [NXOpen.Body.Null] * 1 
    targetBodies114[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies114)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies115 = [NXOpen.Body.Null] * 1 
    targetBodies115[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies115)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies116 = [NXOpen.Body.Null] * 1 
    targetBodies116[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies116)
    
    direction25 = extrudeBuilder9.Direction
    
    success5 = direction25.ReverseDirection()
    
    extrudeBuilder9.Direction = direction25
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies117 = [NXOpen.Body.Null] * 1 
    targetBodies117[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies117)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies118 = [NXOpen.Body.Null] * 1 
    targetBodies118[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies118)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies119 = [NXOpen.Body.Null] * 1 
    targetBodies119[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies119)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies120 = [NXOpen.Body.Null] * 1 
    targetBodies120[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies120)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies121 = [NXOpen.Body.Null] * 1 
    targetBodies121[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies121)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies122 = [NXOpen.Body.Null] * 1 
    targetBodies122[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies122)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies123 = [NXOpen.Body.Null] * 1 
    targetBodies123[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies123)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies124 = [NXOpen.Body.Null] * 1 
    targetBodies124[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies124)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies125 = [NXOpen.Body.Null] * 1 
    targetBodies125[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies125)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies126 = [NXOpen.Body.Null] * 1 
    targetBodies126[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies126)
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("17")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies127 = [NXOpen.Body.Null] * 1 
    targetBodies127[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies127)
    
    markId267 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId267, None)
    
    markId268 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder9.ParentFeatureInternal = False
    
    feature19 = extrudeBuilder9.CommitFeature()
    
    theSession.DeleteUndoMark(markId268, None)
    
    theSession.SetUndoMarkName(markId264, "Extrude")
    
    expression122 = extrudeBuilder9.Limits.StartExtend.Value
    expression123 = extrudeBuilder9.Limits.EndExtend.Value
    extrudeBuilder9.Destroy()
    
    workPart.Expressions.Delete(expression120)
    
    workPart.Expressions.Delete(expression121)
    
    scaleAboutPoint477 = NXOpen.Point3d(5.5580415472514435, -2.4165398031527134, 0.0)
    viewCenter477 = NXOpen.Point3d(-5.5580415472511451, 2.4165398031527441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint477, viewCenter477)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = 0.87014881254523269
    rotMatrix25.Xy = 0.49213952920999871
    rotMatrix25.Xz = -0.025292841182521921
    rotMatrix25.Yx = -0.14108532130534515
    rotMatrix25.Yy = 0.29797233209918639
    rotMatrix25.Yz = 0.94409079087529602
    rotMatrix25.Zx = 0.47216096422543397
    rotMatrix25.Zy = -0.81793103199006689
    rotMatrix25.Zz = 0.3287139345530945
    translation25 = NXOpen.Point3d(-43.157187224246897, -3.267463335037732, -143.46963956841745)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 2.7372126561721095)
    
    scaleAboutPoint478 = NXOpen.Point3d(5.7030339354406054, -3.6731405007921416, 0.0)
    viewCenter478 = NXOpen.Point3d(-5.7030339354402928, 3.6731405007921829, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint478, viewCenter478)
    
    scaleAboutPoint479 = NXOpen.Point3d(3.3831557244139687, -4.2289446555172647, 0.0)
    viewCenter479 = NXOpen.Point3d(-3.3831557244136801, 4.2289446555173065, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint479, viewCenter479)
    
    scaleAboutPoint480 = NXOpen.Point3d(0.30206747539420364, -6.7965181963670451, 0.0)
    viewCenter480 = NXOpen.Point3d(-0.30206747539394607, 6.7965181963670833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint480, viewCenter480)
    
    # ----------------------------------------------
    #   Menu: Tools->Movie->Stop
    # ----------------------------------------------
    theUI.MovieManager.End()
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()