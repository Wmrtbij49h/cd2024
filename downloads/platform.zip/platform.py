﻿# NX 1872
# Journal created by user on Sat Jun  8 02:29:46 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "Z:\\model1.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.66829014546248677
    rotMatrix1.Xy = 0.74369809293301714
    rotMatrix1.Xz = 0.017361683257144763
    rotMatrix1.Yx = -0.17141295398702935
    rotMatrix1.Yy = 0.13123780999362886
    rotMatrix1.Yz = 0.97641908852373305
    rotMatrix1.Zx = 0.72388250475002436
    rotMatrix1.Zy = -0.65550727211516857
    rotMatrix1.Zz = 0.21518442211498917
    translation1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.89692984317447444)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch Dialog")
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(True)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId7)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId9, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(138.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(138.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(138.0, 0.0, 13.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(138.0, 0.0, 13.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 13.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 13.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(69.0, 0.0, -10.03422962062071)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression5 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(148.03422962062072, 0.0, 6.5)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression6 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint1 = NXOpen.Point3d(139.23422693946475, 11.209535219702676, 0.0)
    viewCenter1 = NXOpen.Point3d(-139.23422693946475, -11.209535219702676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(111.38738155157179, 8.9676281757621403, 0.0)
    viewCenter2 = NXOpen.Point3d(-111.38738155157179, -8.9676281757621403, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(89.109905241257437, 7.174102540609713, 0.0)
    viewCenter3 = NXOpen.Point3d(-89.109905241257437, -7.174102540609713, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(71.589991668400017, 5.1351470816995848, 0.0)
    viewCenter4 = NXOpen.Point3d(-71.58999166840006, -5.1351470816995848, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    point3 = NXOpen.Point3d(138.0, 0.0, 10.001265318126306)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(line2, workPart.ModelingViews.WorkView, point3)
    
    point1_1 = NXOpen.Point3d(138.0, 0.0, 13.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, workPart.ModelingViews.WorkView, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(138.0, 0.0, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    dimensionlinearunits21 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point4 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point4
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point5 = NXOpen.Point3d(144.97350897195255, 0.0, 9.2763033771804881)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point5)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject3 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId11, None)
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId10, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId12, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits27 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    expression7 = workPart.Expressions.FindObject("p0")
    expression7.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId12, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.76923076923076927)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId13, None)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId12, "Edit Driving Value")
    
    point6 = NXOpen.Point3d(83.955878942345748, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(line1, workPart.ModelingViews.WorkView, point6)
    
    point1_3 = NXOpen.Point3d(106.15384615384616, 0.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, workPart.ModelingViews.WorkView, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point7 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point7
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point8 = NXOpen.Point3d(81.418512149035379, 0.0, -4.4979735007901578)
    sketchRapidDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject4 = sketchRapidDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId15, None)
    
    theSession.SetUndoMarkName(markId14, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId14, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId16, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    expression8 = workPart.Expressions.FindObject("p1")
    expression8.SetFormula("120")
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId16, "Edit Driving Value")
    
    sketchRapidDimensionBuilder3.Destroy()
    
    theSession.UndoToMark(markId18, None)
    
    theSession.DeleteUndoMark(markId18, None)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId20, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(64.069197450430153, -1.7763568394002505e-14, 10.000000000000009)
    section1.AddToSection(rules1, line3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId22, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId21, None)
    
    extrudeBuilder1.Limits.SymmetricOption = True
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder1.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder1.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("60")
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId23, None)
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId24, None)
    
    theSession.SetUndoMarkName(markId20, "Extrude")
    
    expression11 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    workPart.Expressions.Delete(expression10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId25, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 120 * 140 {(120,60,10)(60,60,10)(0,60,10) EXTRUDE(2)}")
    point9 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 140 * 150 {(0,-60,10)(0,0,10)(0,60,10) EXTRUDE(2)}")
    direction3 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 140 {(60,0,10) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point9, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point10 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId26, None)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject5 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject5
    feature3 = sketch3.Feature
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId28)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId27, None)
    
    theSession.SetUndoMarkName(markId25, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point10)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression12)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    origin7 = NXOpen.Point3d(43.658189803052501, 59.999999999999986, 10.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin7)
    
    origin8 = NXOpen.Point3d(43.658189803052501, 59.999999999999986, 10.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin8)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId30, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(6.0, -54.0, 10.0)
    endPoint5 = NXOpen.Point3d(6.0, 53.0, 10.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(6.0, 53.0, 10.0)
    endPoint6 = NXOpen.Point3d(114.0, 53.0, 10.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(114.0, 53.0, 10.0)
    endPoint7 = NXOpen.Point3d(114.0, -54.0, 10.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(114.0, -54.0, 10.0)
    endPoint8 = NXOpen.Point3d(6.0, -54.0, 10.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line5
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line6
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line6
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line7
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line7
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line8
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line8
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line5
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom6.Geometry = line5
    geom6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom6)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = line5
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line5
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(16.034229620620707, -0.5, 10.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_3, dimObject2_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint3
    dimension3 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression16 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line6
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line6
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(60.0, 42.965770379379293, 10.0)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression17 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    theSession.SetUndoMarkName(markId31, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point11 = NXOpen.Point3d(43.953177571992036, 53.0, 10.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(line6, workPart.ModelingViews.WorkView, point11)
    
    point1_5 = NXOpen.Point3d(6.0, 53.0, 10.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(114.0, 53.0, 10.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point1_7 = NXOpen.Point3d(60.0, 60.0, 10.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(43.953177571992036, 53.0, 10.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(60.0, 60.0, 10.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(43.953177571992036, 53.0, 10.0)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    point1_11 = NXOpen.Point3d(60.0, 60.0, 10.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point12 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point12
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point13 = NXOpen.Point3d(52.50782287123883, 78.289241674251684, 10.0)
    sketchRapidDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point13)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.TextCentered = False
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject6 = sketchRapidDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId32, None)
    
    theSession.SetUndoMarkName(markId31, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId31, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId33, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    expression18 = workPart.Expressions.FindObject("p4")
    expression18.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId33, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId34, None)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId33, "Edit Driving Value")
    
    point14 = NXOpen.Point3d(6.0, 27.846333185589685, 10.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(line5, workPart.ModelingViews.WorkView, point14)
    
    point1_12 = NXOpen.Point3d(6.0, 58.499999999999972, 10.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line5, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    point1_13 = NXOpen.Point3d(6.0, -48.500000000000028, 10.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    point1_14 = NXOpen.Point3d(0.0, 0.0, 10.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(6.0, 27.846333185589685, 10.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(0.0, 0.0, 10.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    point1_17 = NXOpen.Point3d(6.0, 27.846333185589685, 10.0)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    point1_18 = NXOpen.Point3d(0.0, 0.0, 10.0)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point15 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point15
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point16 = NXOpen.Point3d(-21.239119363647191, 15.161859121189281, 10.0)
    sketchRapidDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point16)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId36, None)
    
    theSession.SetUndoMarkName(markId35, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines25 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines28)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId37, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    expression19 = workPart.Expressions.FindObject("p5")
    expression19.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId37, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId38, None)
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId37, "Edit Driving Value")
    
    point17 = NXOpen.Point3d(28.023838049256668, -48.500000000000028, 10.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(line8, workPart.ModelingViews.WorkView, point17)
    
    point1_19 = NXOpen.Point3d(1.5, -48.500000000000028, 10.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line8, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(109.50000000000003, -48.5, 10.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    edge3 = extrude1.FindObject("EDGE * 130 * 140 {(120,-60,10)(60,-60,10)(0,-60,10) EXTRUDE(2)}")
    point1_21 = NXOpen.Point3d(0.0, -60.0, 10.0)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge3, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(28.023838049256668, -48.500000000000028, 10.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line8, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    point1_23 = NXOpen.Point3d(0.0, -60.0, 10.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge3, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    point1_24 = NXOpen.Point3d(28.023838049256668, -48.500000000000028, 10.0)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line8, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(0.0, -60.0, 10.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge3, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point18 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point18
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder6.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point19 = NXOpen.Point3d(32.153666814410286, -55.930193193240797, 10.0)
    sketchRapidDimensionBuilder6.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point19)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.TextCentered = False
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject8 = sketchRapidDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId40, None)
    
    theSession.SetUndoMarkName(markId39, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId39, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId41, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits195 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits197 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits203 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    expression20 = workPart.Expressions.FindObject("p6")
    expression20.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId41, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId42, None)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId41, "Edit Driving Value")
    
    point20 = NXOpen.Point3d(109.50000000000003, -32.331171678077297, 10.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(line7, workPart.ModelingViews.WorkView, point20)
    
    point1_26 = NXOpen.Point3d(109.50000000000003, -58.499999999999972, 10.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(109.5, 58.500000000000028, 10.0)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    dimensionlinearunits207 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    edge4 = extrude1.FindObject("EDGE * 140 * 170 {(120,-60,10)(120,0,10)(120,60,10) EXTRUDE(2)}")
    point1_28 = NXOpen.Point3d(120.0, -60.0, 10.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    point1_29 = NXOpen.Point3d(109.50000000000003, -32.331171678077297, 10.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(120.0, -60.0, 10.0)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    point1_31 = NXOpen.Point3d(109.50000000000003, -32.331171678077297, 10.0)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(120.0, -60.0, 10.0)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    dimensionlinearunits213 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits223 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point21 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point21
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder7.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point22 = NXOpen.Point3d(116.52016873111987, -31.446208371258663, 10.0)
    sketchRapidDimensionBuilder7.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point22)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.TextCentered = False
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject9 = sketchRapidDimensionBuilder7.Commit()
    
    theSession.DeleteUndoMark(markId44, None)
    
    theSession.SetUndoMarkName(markId43, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines33 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines36)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId45, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits225 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits229 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits235 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    expression21 = workPart.Expressions.FindObject("p7")
    expression21.SetFormula("1.")
    
    theSession.SetUndoMarkVisibility(markId45, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId46, None)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId45, "Edit Driving Value")
    
    expression21.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId47, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId48, None)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId47, "Edit Driving Value")
    
    sketchRapidDimensionBuilder8.Destroy()
    
    theSession.UndoToMark(markId49, None)
    
    theSession.DeleteUndoMark(markId49, None)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch4 = theSession.ActiveSketch
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("60")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("60")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId51, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scaleAboutPoint5 = NXOpen.Point3d(2.0649143825767911, 22.419070439405353, 0.0)
    viewCenter5 = NXOpen.Point3d(-2.0649143825767911, -22.419070439405353, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(1.8879217212130548, 9.439608606065395, 0.0)
    viewCenter6 = NXOpen.Point3d(-1.8879217212130548, -9.4396086060654145, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(1.5103373769704438, 5.852557335760542, 0.0)
    viewCenter7 = NXOpen.Point3d(-1.5103373769704438, -5.8525573357605749, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(-27.941241473953607, -4.8330796063054979, 0.0)
    viewCenter8 = NXOpen.Point3d(27.941241473953607, 4.8330796063054722, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(-22.473820169320515, -3.8664636850443981, 0.0)
    viewCenter9 = NXOpen.Point3d(22.473820169320533, 3.866463685044367, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-17.979056135456403, -3.0931709480355272, 0.0)
    viewCenter10 = NXOpen.Point3d(17.979056135456439, 3.0931709480354939, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule2
    helpPoint2 = NXOpen.Point3d(1.5000000000000213, -48.095551949609856, 10.000000000000004)
    section2.AddToSection(rules2, line5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId53, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction4
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies4[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId52, None)
    
    scaleAboutPoint11 = NXOpen.Point3d(-9.7434884863118558, 4.5624271483523708, 0.0)
    viewCenter11 = NXOpen.Point3d(9.74348848631187, -4.5624271483524037, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(-12.179360607889834, 5.7030339354404704, 0.0)
    viewCenter12 = NXOpen.Point3d(12.179360607889834, -5.7030339354404953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-15.22420075986229, 7.1287924193005878, 0.0)
    viewCenter13 = NXOpen.Point3d(15.22420075986229, -7.128792419300618, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-7.8537543602464108, 14.80130629431055, 0.0)
    viewCenter14 = NXOpen.Point3d(7.8537543602464241, -14.801306294310589, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-9.81719295030803, 18.501632867888187, 0.0)
    viewCenter15 = NXOpen.Point3d(9.81719295030803, -18.501632867888219, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-8.7316379606105112, 26.902884527286396, 0.0)
    viewCenter16 = NXOpen.Point3d(8.7316379606105112, -26.902884527286417, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint16, viewCenter16)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies14)
    
    targetBodies15 = []
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies15)
    
    direction5 = extrudeBuilder2.Direction
    
    success1 = direction5.ReverseDirection()
    
    extrudeBuilder2.Direction = direction5
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("2")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies19)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies20)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId54, None)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId55, None)
    
    theSession.SetUndoMarkName(markId51, "Extrude")
    
    expression24 = extrudeBuilder2.Limits.StartExtend.Value
    expression25 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression22)
    
    workPart.Expressions.Delete(expression23)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = -0.047020839066925502
    rotMatrix2.Xy = 0.99845711463706621
    rotMatrix2.Xz = 0.029536941684412999
    rotMatrix2.Yx = 0.59900254397085828
    rotMatrix2.Yy = 0.0045213341251063412
    rotMatrix2.Yz = 0.80073435660908887
    rotMatrix2.Zx = 0.7993653689082888
    rotMatrix2.Zy = 0.055343904527555943
    rotMatrix2.Zz = -0.59829094863766974
    translation2 = NXOpen.Point3d(39.55656285791521, -31.130191348124534, -0.46159499573257534)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.89692984317447455)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin9, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId56, "Create Sketch Dialog")
    
    scalar3 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge5 = extrude1.FindObject("EDGE * 160 * 170 {(120,-60,0)(120,0,0)(120,60,0) EXTRUDE(2)}")
    point23 = workPart.Points.CreatePoint(edge5, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction6 = workPart.Directions.CreateDirection(edge5, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude1.FindObject("FACE 160 {(60,0,0) EXTRUDE(2)}")
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction6, point23, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem3
    
    origin10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin10, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face2
    plane8.SetGeometry(geom7)
    
    plane8.SetFlip(False)
    
    plane8.SetExpression(None)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin11, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane9.SynchronizeToPlane(plane8)
    
    scalar4 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point24 = workPart.Points.CreatePoint(edge5, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom8 = [NXOpen.NXObject.Null] * 1 
    geom8[0] = face2
    plane9.SetGeometry(geom8)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId57, None)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject10 = sketchInPlaceBuilder3.Commit()
    
    sketch5 = nXObject10
    feature5 = sketch5.Feature
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId59)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId58, None)
    
    theSession.SetUndoMarkName(markId56, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression27)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point24)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression26)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression29)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression28)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    scaleAboutPoint17 = NXOpen.Point3d(70.502076776550993, 4.1298287651536079, 0.0)
    viewCenter17 = NXOpen.Point3d(-70.502076776550993, -4.1298287651536336, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(114.67649517524771, -54.20400254264122, 0.0)
    viewCenter18 = NXOpen.Point3d(-114.67649517524771, 54.20400254264122, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(143.34561896905964, -67.755003178301564, 0.0)
    viewCenter19 = NXOpen.Point3d(-143.34561896905964, 67.755003178301479, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(166.50676801470354, -93.91212175223761, 0.0)
    viewCenter20 = NXOpen.Point3d(-166.50676801470354, 93.912121752237567, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(132.74449602279481, -75.590615790758193, 0.0)
    viewCenter21 = NXOpen.Point3d(-132.74449602279481, 75.590615790758108, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(104.72065797353801, -60.841227343780979, 0.0)
    viewCenter22 = NXOpen.Point3d(-104.72065797353814, 60.841227343780915, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(76.401832155341836, -48.672981875024789, 0.0)
    viewCenter23 = NXOpen.Point3d(-76.401832155341978, 48.672981875024732, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(61.121465724273413, -38.938385500019827, 0.0)
    viewCenter24 = NXOpen.Point3d(-61.121465724273598, 38.938385500019784, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    origin12 = NXOpen.Point3d(64.155127992633183, -18.728629982376834, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin12)
    
    origin13 = NXOpen.Point3d(64.155127992633183, -18.728629982376834, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin13)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Redo
    # ----------------------------------------------
    theSession.Redo()
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.75304587154473834
    rotMatrix3.Xy = -0.10326422384049792
    rotMatrix3.Xz = 0.64981413913829944
    rotMatrix3.Yx = -0.39609869253841856
    rotMatrix3.Yy = 0.71745010568784195
    rotMatrix3.Yz = 0.57303679778690009
    rotMatrix3.Zx = -0.52538342295773299
    rotMatrix3.Zy = -0.68891352572229736
    rotMatrix3.Zz = 0.49937001607835041
    translation3 = NXOpen.Point3d(-29.703193005999054, 16.745609570737368, 24.026155297072247)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 1.4014528799601167)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin14, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane10
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression33 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId60, "Create Sketch Dialog")
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    direction9 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane2 = workPart.Datums.FindObject("DATUM_CSYS(0) YZ plane")
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction9, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem4
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin15, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = datumPlane2
    plane11.SetGeometry(geom9)
    
    plane11.SetFlip(False)
    
    plane11.SetExpression(None)
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin16, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane12.SynchronizeToPlane(plane11)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = datumPlane2
    plane12.SetGeometry(geom10)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression33)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression32)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression35)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression34)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane12.DestroyPlane()
    
    theSession.UndoToMark(markId60, None)
    
    theSession.DeleteUndoMark(markId60, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin17, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane13
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId61, "Create Sketch Dialog")
    
    scalar5 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point25 = workPart.Points.CreatePoint(line4, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumAxis3 = workPart.Datums.FindObject("SKETCH(1:1B) X axis")
    direction10 = workPart.Directions.CreateDirection(datumAxis3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane3 = workPart.Datums.FindObject("SKETCH(1:1B) XY plane")
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane3, direction10, point25, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem5
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin18, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom11 = [NXOpen.NXObject.Null] * 1 
    geom11[0] = datumPlane3
    plane14.SetGeometry(geom11)
    
    plane14.SetFlip(False)
    
    plane14.SetExpression(None)
    
    plane14.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane14.Evaluate()
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin19, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane15.SynchronizeToPlane(plane14)
    
    scalar6 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point26 = workPart.Points.CreatePoint(line4, scalar6, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = datumPlane3
    plane15.SetGeometry(geom12)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId62, None)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject11 = sketchInPlaceBuilder5.Commit()
    
    sketch6 = nXObject11
    feature6 = sketch6.Feature
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId64)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId63, None)
    
    theSession.SetUndoMarkName(markId61, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression37)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point26)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression36)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression39)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression38)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    scaleAboutPoint25 = NXOpen.Point3d(12.649075532127537, -9.6284007781867302, 0.0)
    viewCenter25 = NXOpen.Point3d(-12.64907553212773, 9.6284007781866983, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(15.575354200007839, -12.035500972733391, 0.0)
    viewCenter26 = NXOpen.Point3d(-15.57535420000802, 12.035500972733372, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(19.469192750009846, -15.044376215916763, 0.0)
    viewCenter27 = NXOpen.Point3d(-19.469192750009999, 15.044376215916738, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(24.336490937512302, -18.805470269895949, 0.0)
    viewCenter28 = NXOpen.Point3d(-24.336490937512426, 18.805470269895885, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(19.469192750009835, -15.044376215916756, 0.0)
    viewCenter29 = NXOpen.Point3d(-19.469192750009938, 15.044376215916706, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(15.575354200007871, -12.035500972733406, 0.0)
    viewCenter30 = NXOpen.Point3d(-15.575354200007972, 12.035500972733345, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(12.460283360006267, -9.6284007781867267, 0.0)
    viewCenter31 = NXOpen.Point3d(-12.460283360006397, 9.6284007781866787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(6.1923832455788625, -2.2655060654557229, 0.0)
    viewCenter32 = NXOpen.Point3d(-6.1923832455789531, 2.2655060654556713, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(4.95390659646307, -1.8124048523645886, 0.0)
    viewCenter33 = NXOpen.Point3d(-4.9539065964631517, 1.8124048523645269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(8.2162353307192912, -3.5764789086660884, 0.0)
    viewCenter34 = NXOpen.Point3d(-8.2162353307193641, 3.5764789086660307, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(10.270294163399114, -4.4705986358326006, 0.0)
    viewCenter35 = NXOpen.Point3d(-10.270294163399196, 4.4705986358325385, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(12.837867704248891, -5.5882482947907377, 0.0)
    viewCenter36 = NXOpen.Point3d(-12.837867704249009, 5.5882482947906862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(16.047334630311113, -6.4189338521244963, 0.0)
    viewCenter37 = NXOpen.Point3d(-16.047334630311241, 6.4189338521244323, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    origin20 = NXOpen.Point3d(87.463259916016398, 0.0, 2.5082927988037373)
    workPart.ModelingViews.WorkView.SetOrigin(origin20)
    
    origin21 = NXOpen.Point3d(87.463259916016398, 0.0, 2.5082927988037373)
    workPart.ModelingViews.WorkView.SetOrigin(origin21)
    
    scaleAboutPoint38 = NXOpen.Point3d(-61.593446154576803, 24.542982375770034, 0.0)
    viewCenter38 = NXOpen.Point3d(61.593446154576696, -24.542982375770094, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-49.274756923661478, 19.634385900616014, 0.0)
    viewCenter39 = NXOpen.Point3d(49.27475692366135, -19.634385900616078, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-39.419805538929182, 15.707508720492823, 0.0)
    viewCenter40 = NXOpen.Point3d(39.419805538929069, -15.707508720492861, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId66, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(68.642568277243157, 0.0, 0.0)
    endPoint9 = NXOpen.Point3d(77.642568277243157, 0.0, 0.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(77.642568277243157, 0.0, 0.0)
    endPoint10 = NXOpen.Point3d(77.642568277243157, 0.0, -13.0)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(77.642568277243157, 0.0, -13.0)
    endPoint11 = NXOpen.Point3d(68.642568277243157, 0.0, -13.0)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(68.642568277243157, 0.0, -13.0)
    endPoint12 = NXOpen.Point3d(68.642568277243157, 0.0, 0.0)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line9
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line10
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line10
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line11
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line11
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line12
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line12
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line9
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom13.Geometry = line9
    geom13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateHorizontalConstraint(geom13)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line9
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line10
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line11
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line12
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line12
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line9
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line9
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    edge6 = extrude1.FindObject("EDGE * 130 * 160 {(0,-60,0)(60,-60,0)(120,-60,0) EXTRUDE(2)}")
    conGeom2_13.Geometry = edge6
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = 68.642568277243157
    help1.Point.Y = 0.0
    help1.Point.Z = 0.0
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_13, conGeom2_13, help1)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = line9
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line9
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(73.142568277243157, 0.0, -4.11002045260624)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_5, dimObject2_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint5
    dimension5 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression40 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line10
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line10
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(73.532547824636922, 0.0, -6.5)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression41 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId67, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(11.853882903153687, 0.0, 0.0)
    endPoint13 = NXOpen.Point3d(18.853882903153689, 0.0, 0.0)
    line13 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(18.853882903153689, 0.0, 0.0)
    endPoint14 = NXOpen.Point3d(18.853882903153689, 0.0, -13.0)
    line14 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(18.853882903153689, 0.0, -13.0)
    endPoint15 = NXOpen.Point3d(11.853882903153687, 0.0, -13.0)
    line15 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(11.853882903153687, 0.0, -13.0)
    endPoint16 = NXOpen.Point3d(11.853882903153687, 0.0, 0.0)
    line16 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line13
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line14
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line14
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line15
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line15
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line16
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line16
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line13
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom14.Geometry = line13
    geom14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateHorizontalConstraint(geom14)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line13
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line14
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line14
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line15
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line15
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line16
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line16
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line13
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line13
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_18.Geometry = edge6
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = 11.853882903153687
    help2.Point.Y = 0.0
    help2.Point.Z = 0.0
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_18, conGeom2_18, help2)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line13
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line13
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(15.353882903153689, 0.0, -4.11002045260624)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    expression42 = sketchHelpedDimensionalConstraint7.AssociatedExpression
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line14
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line14
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(14.74386245054745, 0.0, -6.5)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression43 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line13
    geoms7[1] = line14
    geoms7[2] = line15
    geoms7[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line13
    geoms8[1] = line14
    geoms8[2] = line15
    geoms8[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines37 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines40)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines41 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines44)
    
    theSession.SetUndoMarkName(markId68, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits251 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits253 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits255 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits257 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits261 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    point27 = NXOpen.Point3d(77.642568277243157, 0.0, -8.3510329416139051)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(line10, workPart.ModelingViews.WorkView, point27)
    
    point1_33 = NXOpen.Point3d(77.642568277243157, 0.0, -13.0)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line10, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(77.642568277243157, 0.0, 0.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    dimensionlinearunits265 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point28 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point28
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point29 = NXOpen.Point3d(81.812710204425599, 0.0, -8.4718599317715295)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point29)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject12 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId69, None)
    
    theSession.SetUndoMarkName(markId68, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId68, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId70, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression44 = workPart.Expressions.FindObject("p10")
    expression44.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId71, None)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId70, "Edit Driving Value")
    
    point30 = NXOpen.Point3d(71.17993507055354, 0.0, -10.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(line11, workPart.ModelingViews.WorkView, point30)
    
    point1_35 = NXOpen.Point3d(68.642568277243157, 0.0, -10.000000000000002)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(77.642568277243157, 0.0, -9.9999999999999982)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point31 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point31
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder10.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point32 = NXOpen.Point3d(72.750685942602814, 0.0, -17.533884193594314)
    sketchRapidDimensionBuilder10.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point32)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.TextCentered = True
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject13 = sketchRapidDimensionBuilder10.Commit()
    
    theSession.DeleteUndoMark(markId73, None)
    
    theSession.SetUndoMarkName(markId72, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId72, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId74, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    expression45 = workPart.Expressions.FindObject("p11")
    expression45.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId75, None)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId74, "Edit Driving Value")
    
    point33 = NXOpen.Point3d(18.853882903153689, 0.0, -3.3971263451507703)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(line14, workPart.ModelingViews.WorkView, point33)
    
    point1_37 = NXOpen.Point3d(18.853882903153689, 0.0, 0.0)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line14, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(18.853882903153689, 0.0, -13.0)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line14, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point34 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point34
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder11.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point35 = NXOpen.Point3d(22.124177066552853, 0.0, -4.0012612959389635)
    sketchRapidDimensionBuilder11.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point35)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.TextCentered = False
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject14 = sketchRapidDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.SetUndoMarkName(markId76, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId76, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId78, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    expression46 = workPart.Expressions.FindObject("p12")
    expression46.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId78, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId79, None)
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId78, "Edit Driving Value")
    
    point36 = NXOpen.Point3d(14.028768725991156, 0.0, -10.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(line15, workPart.ModelingViews.WorkView, point36)
    
    point1_39 = NXOpen.Point3d(11.853882903153689, 0.0, -10.000000000000002)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(18.853882903153696, 0.0, -9.9999999999999964)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point37 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point37
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder12.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point38 = NXOpen.Point3d(14.149595716148795, 0.0, -12.821631577446468)
    sketchRapidDimensionBuilder12.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point38)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.TextCentered = False
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject15 = sketchRapidDimensionBuilder12.Commit()
    
    theSession.DeleteUndoMark(markId81, None)
    
    theSession.SetUndoMarkName(markId80, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines57 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines60)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId82, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    expression47 = workPart.Expressions.FindObject("p13")
    expression47.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId82, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId83, None)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId82, "Edit Driving Value")
    
    point1_41 = NXOpen.Point3d(74.642568277243157, 0.0, 0.0)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    point1_42 = NXOpen.Point3d(120.0, -60.0, 0.0)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge5, workPart.ModelingViews.WorkView, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(74.642568277243157, 0.0, 0.0)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(120.0, -60.0, 0.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge5, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    point1_45 = NXOpen.Point3d(74.642568277243157, 0.0, 0.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    point1_46 = NXOpen.Point3d(120.0, -60.0, 0.0)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge5, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point39 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point39
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder13.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point40 = NXOpen.Point3d(113.10690065525361, 0.0, -6.6594550794069747)
    sketchRapidDimensionBuilder13.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point40)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.TextCentered = False
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject16 = sketchRapidDimensionBuilder13.Commit()
    
    theSession.DeleteUndoMark(markId85, None)
    
    theSession.SetUndoMarkName(markId84, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId84, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines61 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines64)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId86, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    expression48 = workPart.Expressions.FindObject("p14")
    expression48.SetFormula("57")
    
    theSession.SetUndoMarkVisibility(markId86, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId87, None)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId86, "Edit Driving Value")
    
    point1_47 = NXOpen.Point3d(11.853882903153687, 0.0, 0.0)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line16, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    edge7 = extrude1.FindObject("EDGE * 150 * 160 {(0,-60,0)(0,0,0)(0,60,0) EXTRUDE(2)}")
    point1_48 = NXOpen.Point3d(0.0, -60.0, 0.0)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge7, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    point1_49 = NXOpen.Point3d(11.853882903153687, 0.0, 0.0)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line16, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(0.0, -60.0, 0.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge7, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    point1_51 = NXOpen.Point3d(11.853882903153687, 0.0, 0.0)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line16, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(0.0, -60.0, 0.0)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge7, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point41 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point41
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder14.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point42 = NXOpen.Point3d(4.4834365035378312, 0.0, -4.9678772172000585)
    sketchRapidDimensionBuilder14.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point42)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.TextCentered = False
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject17 = sketchRapidDimensionBuilder14.Commit()
    
    theSession.DeleteUndoMark(markId89, None)
    
    theSession.SetUndoMarkName(markId88, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId90, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    expression49 = workPart.Expressions.FindObject("p15")
    expression49.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId90, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId91, None)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId90, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    sketchRapidDimensionBuilder15.Destroy()
    
    theSession.UndoToMark(markId92, None)
    
    theSession.DeleteUndoMark(markId92, None)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin22, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane16
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId93, "Create Sketch Dialog")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId94, None)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject18 = sketchInPlaceBuilder6.Commit()
    
    sketch7 = nXObject18
    feature7 = sketch7.Feature
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId97)
    
    sketch7.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId95, None)
    
    theSession.SetUndoMarkName(markId93, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression51)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression50)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    sketch8 = theSession.ActiveSketch
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section4
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId99, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature6
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section4.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule3
    helpPoint4 = NXOpen.Point3d(10.0, 0.0, -7.2635900301951679)
    section4.AddToSection(rules3, line14, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId101, None)
    
    direction11 = workPart.Directions.CreateDirection(sketch6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction11
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies24)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId100, None)
    
    extrudeBuilder3.Limits.SymmetricOption = True
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("4")
    
    extrudeBuilder3.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder3.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder3.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies26)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.99987897417099036
    rotMatrix4.Xy = 0.015273939779729698
    rotMatrix4.Xz = -0.0029569873819671193
    rotMatrix4.Yx = 0.0040442518993003412
    rotMatrix4.Yy = -0.071651424867296726
    rotMatrix4.Yz = 0.99742153442817882
    rotMatrix4.Zx = 0.015022684092627825
    rotMatrix4.Zy = -0.99731277946193764
    rotMatrix4.Zz = -0.071704524854166632
    translation4 = NXOpen.Point3d(-57.413822696313282, -14.73341922685043, -1.2410043731364757)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 2.1897701249376835)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature8 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId103, None)
    
    theSession.SetUndoMarkName(markId99, "Extrude")
    
    expression55 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression52)
    
    workPart.Expressions.Delete(expression53)
    
    workPart.Expressions.Delete(expression54)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin23, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane17
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId104, "Create Sketch Dialog")
    
    scalar7 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature8
    edge8 = extrude2.FindObject("EDGE * 150 * 210 {(63,-5,-10)(63,-5,-5)(63,-5,0) EXTRUDE(2)}")
    point43 = workPart.Points.CreatePoint(edge8, scalar7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge9 = extrude2.FindObject("EDGE * 150 * 200 {(57,-5,-10)(60,-5,-10)(63,-5,-10) EXTRUDE(2)}")
    direction12 = workPart.Directions.CreateDirection(edge9, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude2.FindObject("FACE 150 {(60,-5,-5) EXTRUDE(2)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction12, point43, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.Csystem = cartesianCoordinateSystem6
    
    origin24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal18 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane18 = workPart.Planes.CreatePlane(origin24, normal18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane18.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom15 = [NXOpen.NXObject.Null] * 1 
    geom15[0] = face3
    plane18.SetGeometry(geom15)
    
    plane18.SetFlip(False)
    
    plane18.SetExpression(None)
    
    plane18.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane18.Evaluate()
    
    origin25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal19 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin25, normal19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane19.SynchronizeToPlane(plane18)
    
    scalar8 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point44 = workPart.Points.CreatePoint(edge8, scalar8, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane19.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom16 = [NXOpen.NXObject.Null] * 1 
    geom16[0] = face3
    plane19.SetGeometry(geom16)
    
    plane19.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane19.Evaluate()
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId105, None)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject19 = sketchInPlaceBuilder7.Commit()
    
    sketch9 = nXObject19
    feature9 = sketch9.Feature
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId107)
    
    sketch9.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.SetUndoMarkName(markId104, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression57)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point44)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression56)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression59)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression58)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane19.DestroyPlane()
    
    scaleAboutPoint41 = NXOpen.Point3d(-0.96661592126116569, -7.128792419300618, 0.0)
    viewCenter41 = NXOpen.Point3d(0.96661592126104212, 7.1287924193005567, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-0.77329273700894896, -5.7030339354404944, 0.0)
    viewCenter42 = NXOpen.Point3d(0.77329273700881718, 5.7030339354404447, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-0.6959634633080557, -4.5624271483524081, 0.0)
    viewCenter43 = NXOpen.Point3d(0.6959634633079238, 4.5624271483523486, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId109, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(59.0, -5.0, -4.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 1.2459675993547195, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = arc1
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(59.0, -5.0, -3.2985565094218687)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_9, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension9 = sketchDimensionalConstraint9.AssociatedDimension
    
    expression60 = sketchDimensionalConstraint9.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    origin26 = NXOpen.Point3d(36.901370125952603, -5.0, -3.4788507006187164)
    workPart.ModelingViews.WorkView.SetOrigin(origin26)
    
    origin27 = NXOpen.Point3d(36.901370125952603, -5.0, -3.4788507006187164)
    workPart.ModelingViews.WorkView.SetOrigin(origin27)
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId110, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(6.5882948352046, -5.0, -4.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.6433643433514857, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = arc2
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(6.5882948352046, -5.0, -3.2985565094218687)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_10, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension10 = sketchDimensionalConstraint10.AssociatedDimension
    
    expression61 = sketchDimensionalConstraint10.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines69 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines72)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines73 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines76)
    
    theSession.SetUndoMarkName(markId111, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    point1_53 = NXOpen.Point3d(59.0, -5.0, -4.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    point1_54 = NXOpen.Point3d(59.0, -5.0, -4.0)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    point1_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    dimensionlinearunits441 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits443 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    point45 = NXOpen.Point3d(60.718786425826025, -5.0, -10.000000000000004)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(edge9, workPart.ModelingViews.WorkView, point45)
    
    point1_56 = NXOpen.Point3d(60.718786425826025, -5.0, -10.000000000000004)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge9, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(59.0, -5.0, -4.0)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    point1_58 = NXOpen.Point3d(60.718786425826025, -5.0, -10.000000000000004)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge9, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(59.0, -5.0, -4.0)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    dimensionlinearunits447 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits451 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits453 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point46 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point46
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder16.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point47 = NXOpen.Point3d(66.905128321897038, -5.0, -8.4279242174755336)
    sketchRapidDimensionBuilder16.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point47)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.TextCentered = False
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject20 = sketchRapidDimensionBuilder16.Commit()
    
    theSession.DeleteUndoMark(markId112, None)
    
    theSession.SetUndoMarkName(markId111, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId111, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder16.Destroy()
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines77 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines80)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId113, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits459 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits461 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits463 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits467 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits469 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits471 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits473 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits477 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    expression62 = workPart.Expressions.FindObject("p24")
    expression62.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId113, "Edit Driving Value")
    
    point1_60 = NXOpen.Point3d(59.0, -5.0, -6.0000000000000036)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    point1_61 = NXOpen.Point3d(59.0, -5.0, -6.0000000000000036)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    dimensionlinearunits479 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits481 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    point1_63 = NXOpen.Point3d(63.0, -4.9999999999999982, -5.0000000000000018)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge8, workPart.ModelingViews.WorkView, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    point1_64 = NXOpen.Point3d(59.0, -5.0, -6.0000000000000036)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    point1_65 = NXOpen.Point3d(63.0, -4.9999999999999982, -5.0000000000000018)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge8, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    point1_66 = NXOpen.Point3d(59.0, -5.0, -6.0000000000000036)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    point1_67 = NXOpen.Point3d(63.0, -4.9999999999999982, -5.0000000000000018)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge8, workPart.ModelingViews.WorkView, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    dimensionlinearunits485 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits487 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    point1_68 = NXOpen.Point3d(59.0, -5.0, -6.0000000000000036)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    point1_69 = NXOpen.Point3d(63.0, -4.9999999999999982, -5.0000000000000018)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge8, workPart.ModelingViews.WorkView, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point48 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point48
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder17.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point49 = NXOpen.Point3d(61.708601129197383, -5.0, -4.3449385660686586)
    sketchRapidDimensionBuilder17.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point49)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.TextCentered = False
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject21 = sketchRapidDimensionBuilder17.Commit()
    
    theSession.DeleteUndoMark(markId116, None)
    
    theSession.SetUndoMarkName(markId115, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId115, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder17.Destroy()
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines81 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines84)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId117, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    expression63 = workPart.Expressions.FindObject("p25")
    expression63.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId117, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId118, None)
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId117, "Edit Driving Value")
    
    point1_70 = NXOpen.Point3d(61.181211655227031, -5.0, -6.3964521209397081)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc1, workPart.ModelingViews.WorkView, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    point1_71 = NXOpen.Point3d(61.181211655227031, -5.0, -6.3964521209397081)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point50 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point50
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point51 = NXOpen.Point3d(61.832327967118808, -5.0, -7.4999729330648801)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point51)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = False
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject22 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId120, None)
    
    theSession.SetUndoMarkName(markId119, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId119, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId121, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression64 = workPart.Expressions.FindObject("p26")
    expression64.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId122, None)
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId121, "Edit Driving Value")
    
    point1_73 = NXOpen.Point3d(7.5882948352046071, -5.0, -3.9999999999999991)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    point1_74 = NXOpen.Point3d(7.5882948352046071, -5.0, -3.9999999999999991)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    point1_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    edge10 = extrude2.FindObject("EDGE * 130 * 160 {(10,-5,-10)(10,-5,-5)(10,-5,0) EXTRUDE(2)}")
    point52 = NXOpen.Point3d(9.9999999999999982, -5.0, -2.6127628351687702)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(edge10, workPart.ModelingViews.WorkView, point52)
    
    point1_76 = NXOpen.Point3d(9.9999999999999982, -5.0, -2.6127628351687702)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge10, workPart.ModelingViews.WorkView, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    point1_77 = NXOpen.Point3d(7.5882948352046071, -5.0, -3.9999999999999991)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    point1_78 = NXOpen.Point3d(9.9999999999999982, -5.0, -2.6127628351687702)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge10, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    point1_79 = NXOpen.Point3d(7.5882948352046071, -5.0, -3.9999999999999991)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin16 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin16.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin16.View = NXOpen.View.Null
    assocOrigin16.ViewOfGeometry = workPart.ModelingViews.WorkView
    point53 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin16.PointOnGeometry = point53
    assocOrigin16.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.DimensionLine = 0
    assocOrigin16.AssociatedView = NXOpen.View.Null
    assocOrigin16.AssociatedPoint = NXOpen.Point.Null
    assocOrigin16.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.XOffsetFactor = 0.0
    assocOrigin16.YOffsetFactor = 0.0
    assocOrigin16.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder19.Origin.SetAssociativeOrigin(assocOrigin16)
    
    point54 = NXOpen.Point3d(11.661095189982838, -5.0, -5.7677972021649921)
    sketchRapidDimensionBuilder19.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point54)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.TextCentered = False
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject23 = sketchRapidDimensionBuilder19.Commit()
    
    theSession.DeleteUndoMark(markId124, None)
    
    theSession.SetUndoMarkName(markId123, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId123, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines89 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines92)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId125, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    expression65 = workPart.Expressions.FindObject("p27")
    expression65.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId125, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId126, None)
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId125, "Edit Driving Value")
    
    point1_80 = NXOpen.Point3d(7.0, -5.0, -3.9999999999999996)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    point1_81 = NXOpen.Point3d(7.0, -5.0, -3.9999999999999996)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    point1_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits585 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    edge11 = extrude2.FindObject("EDGE * 130 * 190 {(4,-5,-10)(7,-5,-10)(10,-5,-10) EXTRUDE(2)}")
    point55 = NXOpen.Point3d(8.0730168902616448, -5.0, -10.000000000000002)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(edge11, workPart.ModelingViews.WorkView, point55)
    
    point1_83 = NXOpen.Point3d(8.0730168902616448, -5.0, -10.000000000000002)
    point2_83 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge11, workPart.ModelingViews.WorkView, point1_83, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_83)
    
    point1_84 = NXOpen.Point3d(7.0, -5.0, -3.9999999999999996)
    point2_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_84, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_84)
    
    point1_85 = NXOpen.Point3d(8.0730168902616448, -5.0, -10.000000000000002)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge11, workPart.ModelingViews.WorkView, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    point1_86 = NXOpen.Point3d(7.0, -5.0, -3.9999999999999996)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    dimensionlinearunits587 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits589 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits591 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits595 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits597 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin17 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin17.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin17.View = NXOpen.View.Null
    assocOrigin17.ViewOfGeometry = workPart.ModelingViews.WorkView
    point56 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin17.PointOnGeometry = point56
    assocOrigin17.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.DimensionLine = 0
    assocOrigin17.AssociatedView = NXOpen.View.Null
    assocOrigin17.AssociatedPoint = NXOpen.Point.Null
    assocOrigin17.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.XOffsetFactor = 0.0
    assocOrigin17.YOffsetFactor = 0.0
    assocOrigin17.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder20.Origin.SetAssociativeOrigin(assocOrigin17)
    
    point57 = NXOpen.Point3d(15.063583232821895, -5.0, -11.149914651746782)
    sketchRapidDimensionBuilder20.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point57)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.TextCentered = False
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject24 = sketchRapidDimensionBuilder20.Commit()
    
    theSession.DeleteUndoMark(markId128, None)
    
    theSession.SetUndoMarkName(markId127, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId127, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder21 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines93 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines96)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder21.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId129, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder21.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits599 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits603 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits607 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder21.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits609 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits613 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits615 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits617 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    expression66 = workPart.Expressions.FindObject("p28")
    expression66.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId129, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId130, None)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId129, "Edit Driving Value")
    
    expression66.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId131, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId132, None)
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId131, "Edit Driving Value")
    
    point1_87 = NXOpen.Point3d(7.0, -5.0, -6.0000000000000036)
    point2_87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_87, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_87)
    
    point1_88 = NXOpen.Point3d(7.0, -5.0, -6.0000000000000036)
    point2_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_88, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_88)
    
    point1_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    dimensionlinearunits619 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits621 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits623 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin18 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin18.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin18.View = NXOpen.View.Null
    assocOrigin18.ViewOfGeometry = workPart.ModelingViews.WorkView
    point58 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin18.PointOnGeometry = point58
    assocOrigin18.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.DimensionLine = 0
    assocOrigin18.AssociatedView = NXOpen.View.Null
    assocOrigin18.AssociatedPoint = NXOpen.Point.Null
    assocOrigin18.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.XOffsetFactor = 0.0
    assocOrigin18.YOffsetFactor = 0.0
    assocOrigin18.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder21.Origin.SetAssociativeOrigin(assocOrigin18)
    
    point59 = NXOpen.Point3d(8.506060822986619, -5.0, -3.5407141195794241)
    sketchRapidDimensionBuilder21.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point59)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.TextCentered = False
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject25 = sketchRapidDimensionBuilder21.Commit()
    
    theSession.DeleteUndoMark(markId134, None)
    
    theSession.SetUndoMarkName(markId133, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId133, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder21.Destroy()
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder22 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines97 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines97)
    
    lines98 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines98)
    
    lines99 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines99)
    
    lines100 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines100)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder22.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId135, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder22.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits625 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits627 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits629 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits633 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder22.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits635 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits639 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits641 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits643 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    expression67 = workPart.Expressions.FindObject("p29")
    expression67.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId135, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId136, None)
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId135, "Edit Driving Value")
    
    sketchRapidDimensionBuilder22.Destroy()
    
    theSession.UndoToMark(markId137, None)
    
    theSession.DeleteUndoMark(markId137, None)
    
    sketchRapidDimensionBuilder22.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch10 = theSession.ActiveSketch
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section5
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression68 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId139, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature9
    features4[0] = sketchFeature4
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section5.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule4
    helpPoint5 = NXOpen.Point3d(7.116301313149564, -5.0, -4.5114520739730484)
    section5.AddToSection(rules4, arc2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId141, None)
    
    direction13 = workPart.Directions.CreateDirection(sketch10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction13
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies30)
    
    expression69 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression70 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId140, None)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies32)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.99987897417099036
    rotMatrix5.Xy = 0.015273939779729698
    rotMatrix5.Xz = -0.0029569873819671193
    rotMatrix5.Yx = 0.015134720405144407
    rotMatrix5.Yy = -0.91096231077787071
    rotMatrix5.Yz = 0.41221184915102055
    rotMatrix5.Zx = 0.0036023949020052154
    rotMatrix5.Zy = -0.41220671404751708
    rotMatrix5.Zz = -0.91108322761706095
    translation5 = NXOpen.Point3d(-57.413822696313282, -16.456211114952225, -2.0723863850485111)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 2.1897701249376835)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies33)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies34)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies35)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies36 = [NXOpen.Body.Null] * 1 
    targetBodies36[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies36)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies37)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies38)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies39)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("-14")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies40)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies41)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies42)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies43)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies44)
    
    targetBodies45 = []
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies45)
    
    direction14 = extrudeBuilder4.Direction
    
    success2 = direction14.ReverseDirection()
    
    extrudeBuilder4.Direction = direction14
    
    targetBodies46 = [NXOpen.Body.Null] * 1 
    targetBodies46[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies46)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies47)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies48 = [NXOpen.Body.Null] * 1 
    targetBodies48[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies50)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies51)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies52)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("14")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies53 = [NXOpen.Body.Null] * 1 
    targetBodies53[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies53)
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId142, None)
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    feature10 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId143, None)
    
    theSession.SetUndoMarkName(markId139, "Extrude")
    
    expression71 = extrudeBuilder4.Limits.StartExtend.Value
    expression72 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression68)
    
    workPart.Expressions.Delete(expression69)
    
    workPart.Expressions.Delete(expression70)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.18005353331161345
    rotMatrix6.Xy = -0.98127246923331624
    rotMatrix6.Xz = -0.068447543905971159
    rotMatrix6.Yx = -0.014718974282993642
    rotMatrix6.Yy = -0.072264695326129447
    rotMatrix6.Yz = 0.99727687509812435
    rotMatrix6.Zx = -0.98354668264300926
    rotMatrix6.Zy = -0.17855574741289529
    rotMatrix6.Zz = -0.027454837966411887
    translation6 = NXOpen.Point3d(-8.2242962447506649, -14.664989433663932, 57.156558267652358)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 2.1897701249376835)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal20 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane20 = workPart.Planes.CreatePlane(origin28, normal20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane20
    
    expression73 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder8 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder8.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId144, "Create Sketch Dialog")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId145, None)
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject26 = sketchInPlaceBuilder8.Commit()
    
    sketch11 = nXObject26
    feature11 = sketch11.Feature
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId147)
    
    sketch11.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId146, None)
    
    theSession.SetUndoMarkName(markId144, "Create Sketch")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder8.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression74)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression73)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane20.DestroyPlane()
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder9 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal21 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane21 = workPart.Planes.CreatePlane(origin29, normal21, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder9.PlaneReference = plane21
    
    expression75 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression76 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder9 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder9.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId148, "Create Sketch Dialog")
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchInPlaceBuilder9.Destroy()
    
    sketchAlongPathBuilder9.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression76)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression75)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane21.DestroyPlane()
    
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.14959558217496727
    rotMatrix7.Xy = -0.91805070779173215
    rotMatrix7.Xz = -0.36715672364377694
    rotMatrix7.Yx = 0.023220677044267644
    rotMatrix7.Yy = -0.36797079839765207
    rotMatrix7.Yz = 0.92954735849455283
    rotMatrix7.Zx = -0.98847456312812565
    rotMatrix7.Zy = -0.14758180595755954
    rotMatrix7.Zz = -0.033729046813791165
    translation7 = NXOpen.Point3d(51.024265069501965, -1.3932406226560561, 59.308473787687532)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 2.1897701249376835)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder10 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal22 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane22 = workPart.Planes.CreatePlane(origin30, normal22, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.PlaneReference = plane22
    
    expression77 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder10 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder10.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId149, "Create Sketch Dialog")
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge12 = extrude2.FindObject("EDGE * 180 * 190 {(4,-5,-10)(4,0,-10)(4,5,-10) EXTRUDE(2)}")
    point60 = workPart.Points.CreatePoint(edge12, scalar9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction15 = workPart.Directions.CreateDirection(edge12, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face4 = extrude2.FindObject("FACE 180 {(4,0,-5) EXTRUDE(2)}")
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction15, point60, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem7
    
    origin31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal23 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane23 = workPart.Planes.CreatePlane(origin31, normal23, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane23.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom17 = [NXOpen.NXObject.Null] * 1 
    geom17[0] = face4
    plane23.SetGeometry(geom17)
    
    plane23.SetFlip(False)
    
    plane23.SetExpression(None)
    
    plane23.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane23.Evaluate()
    
    origin32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal24 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane24 = workPart.Planes.CreatePlane(origin32, normal24, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression79 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression80 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane24.SynchronizeToPlane(plane23)
    
    scalar10 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point61 = workPart.Points.CreatePoint(edge12, scalar10, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane24.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom18 = [NXOpen.NXObject.Null] * 1 
    geom18[0] = face4
    plane24.SetGeometry(geom18)
    
    plane24.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane24.Evaluate()
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId150, None)
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject27 = sketchInPlaceBuilder10.Commit()
    
    sketch12 = nXObject27
    feature12 = sketch12.Feature
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId153)
    
    sketch12.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId151, None)
    
    theSession.SetUndoMarkName(markId149, "Create Sketch")
    
    sketchInPlaceBuilder10.Destroy()
    
    sketchAlongPathBuilder10.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression78)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point61)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression77)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane22.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression80)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression79)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane24.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint44 = NXOpen.Point3d(-4.2289446555173686, 5.6788685374089161, 0.0)
    viewCenter44 = NXOpen.Point3d(4.2289446555172443, -5.6788685374089773, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-5.4130491590622141, 7.1529578173320942, 0.0)
    viewCenter45 = NXOpen.Point3d(5.4130491590620995, -7.152957817332144, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(-5.722366253865764, 6.9596346330798715, 0.0)
    viewCenter46 = NXOpen.Point3d(5.7223662538656317, -6.9596346330799239, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId155, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(4.0000000000000018, 3.6405797201530206, 0.0)
    endPoint17 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, 0.0)
    line17 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, 0.0)
    endPoint18 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, -9.9999999999999911)
    line18 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, -9.9999999999999911)
    endPoint19 = NXOpen.Point3d(4.0000000000000018, 3.6405797201530206, -9.9999999999999911)
    line19 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(4.0000000000000018, 3.6405797201530206, -9.9999999999999911)
    endPoint20 = NXOpen.Point3d(4.0000000000000018, 3.6405797201530206, 0.0)
    line20 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line17
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line18
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line18
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line19
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line19
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line20
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line20
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line17
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint41 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    geom19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom19.Geometry = line17
    geom19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint42 = theSession.ActiveSketch.CreateHorizontalConstraint(geom19)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line17
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line18
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint43 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line18
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = line19
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint44 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_20, conGeom2_20)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line19
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_21.Geometry = line20
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint45 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_21, conGeom2_21)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line20
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_22.SplineDefiningPointIndex = 0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_22.Geometry = line17
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint46 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_22, conGeom2_22)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = line17
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_23.Geometry = edge7
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_23.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = 4.0000000000000018
    help3.Point.Y = 3.6405797201530206
    help3.Point.Z = 0.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_23, conGeom2_23, help3)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line19
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = edge12
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help4.Point.X = 4.0000000000000018
    help4.Point.Y = -3.3499866224072212
    help4.Point.Z = -10.000000000000004
    help4.Parameter = 0.0
    sketchHelpedGeometricConstraint4 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_24, conGeom2_24, help4)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = line18
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line18
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(4.0000000000000018, -1.2456561506728256, -4.9999999999999956)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_11, dimObject2_9, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint11
    dimension11 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression81 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = line17
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line17
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(4.0000000000000018, 0.14529654887290011, -2.1043304717343947)
    sketchDimensionalConstraint12 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_12, dimObject2_10, dimOrigin12, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint12
    dimension12 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression82 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line17
    geoms9[1] = line18
    geoms9[2] = line19
    geoms9[3] = line20
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line17
    geoms10[1] = line18
    geoms10[2] = line19
    geoms10[3] = line20
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder23 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines101 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines101)
    
    lines102 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines102)
    
    lines103 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines103)
    
    lines104 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines104)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder23.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines105 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines105)
    
    lines106 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines106)
    
    lines107 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines107)
    
    lines108 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines108)
    
    theSession.SetUndoMarkName(markId156, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder23.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits645 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits647 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits649 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits651 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits653 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder23.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits655 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits657 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits659 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits661 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits663 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    point62 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, -3.9383515577716732)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(line18, workPart.ModelingViews.WorkView, point62)
    
    point1_90 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, 0.0)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line18, workPart.ModelingViews.WorkView, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    point1_91 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, -9.9999999999999911)
    point2_91 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line18, workPart.ModelingViews.WorkView, point1_91, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_91)
    
    dimensionlinearunits665 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits667 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits669 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    edge13 = extrude2.FindObject("EDGE * 130 * 180 {(4,-5,-0)(4,-5,-5)(4,-5,-10) EXTRUDE(2)}")
    point1_92 = NXOpen.Point3d(4.0000000000000009, -5.0, -5.0000000000000018)
    point2_92 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge13, workPart.ModelingViews.WorkView, point1_92, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_92)
    
    point1_93 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, -3.9383515577716732)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line18, workPart.ModelingViews.WorkView, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    point1_94 = NXOpen.Point3d(4.0000000000000009, -5.0, -5.0000000000000018)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge13, workPart.ModelingViews.WorkView, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    point1_95 = NXOpen.Point3d(4.0000000000000018, -3.3499866224072203, -3.9383515577716732)
    point2_95 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line18, workPart.ModelingViews.WorkView, point1_95, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_95)
    
    point1_96 = NXOpen.Point3d(4.0000000000000009, -5.0, -5.0000000000000018)
    point2_96 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge13, workPart.ModelingViews.WorkView, point1_96, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_96)
    
    dimensionlinearunits671 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits673 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits675 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits679 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits681 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin19 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin19.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin19.View = NXOpen.View.Null
    assocOrigin19.ViewOfGeometry = workPart.ModelingViews.WorkView
    point63 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin19.PointOnGeometry = point63
    assocOrigin19.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.DimensionLine = 0
    assocOrigin19.AssociatedView = NXOpen.View.Null
    assocOrigin19.AssociatedPoint = NXOpen.Point.Null
    assocOrigin19.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.XOffsetFactor = 0.0
    assocOrigin19.YOffsetFactor = 0.0
    assocOrigin19.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder23.Origin.SetAssociativeOrigin(assocOrigin19)
    
    point64 = NXOpen.Point3d(4.0000000000000018, -7.9278796254997808, -6.4747517351607913)
    sketchRapidDimensionBuilder23.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point64)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.TextCentered = False
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject28 = sketchRapidDimensionBuilder23.Commit()
    
    theSession.DeleteUndoMark(markId157, None)
    
    theSession.SetUndoMarkName(markId156, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder24 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines109 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines109)
    
    lines110 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines110)
    
    lines111 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines111)
    
    lines112 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines112)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder24.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId158, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder24.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits683 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits685 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits687 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits689 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder24.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits693 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits694 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits695 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits696 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits697 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits698 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits699 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits700 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits701 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits702 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    expression83 = workPart.Expressions.FindObject("p38")
    expression83.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId158, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId159, None)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId158, "Edit Driving Value")
    
    point65 = NXOpen.Point3d(4.0000000000000018, 3.9905663425602382, -6.1654346403572413)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(line20, workPart.ModelingViews.WorkView, point65)
    
    point1_97 = NXOpen.Point3d(4.0000000000000018, 3.9905663425602373, -10.000000000000007)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line20, workPart.ModelingViews.WorkView, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(4.0000000000000018, 3.9905663425602391, 0.0)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line20, workPart.ModelingViews.WorkView, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    dimensionlinearunits703 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits704 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits705 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits706 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits707 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits708 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    edge14 = extrude2.FindObject("EDGE * 120 * 180 {(4,5,-0)(4,5,-5)(4,5,-10) EXTRUDE(2)}")
    point1_99 = NXOpen.Point3d(4.0000000000000009, 5.0, -5.0000000000000018)
    point2_99 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_99, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_99)
    
    point1_100 = NXOpen.Point3d(4.0000000000000018, 3.9905663425602382, -6.1654346403572413)
    point2_100 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line20, workPart.ModelingViews.WorkView, point1_100, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_100)
    
    point1_101 = NXOpen.Point3d(4.0000000000000009, 5.0, -5.0000000000000018)
    point2_101 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_101, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_101)
    
    point1_102 = NXOpen.Point3d(4.0000000000000018, 3.9905663425602382, -6.1654346403572413)
    point2_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line20, workPart.ModelingViews.WorkView, point1_102, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_102)
    
    point1_103 = NXOpen.Point3d(4.0000000000000009, 5.0, -5.0000000000000018)
    point2_103 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_103, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_103)
    
    dimensionlinearunits709 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits710 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits711 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits712 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits713 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits714 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits715 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits716 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits717 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits718 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits719 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits720 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin20 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin20.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin20.View = NXOpen.View.Null
    assocOrigin20.ViewOfGeometry = workPart.ModelingViews.WorkView
    point66 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin20.PointOnGeometry = point66
    assocOrigin20.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.DimensionLine = 0
    assocOrigin20.AssociatedView = NXOpen.View.Null
    assocOrigin20.AssociatedPoint = NXOpen.Point.Null
    assocOrigin20.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.XOffsetFactor = 0.0
    assocOrigin20.YOffsetFactor = 0.0
    assocOrigin20.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder24.Origin.SetAssociativeOrigin(assocOrigin20)
    
    point67 = NXOpen.Point3d(4.0000000000000018, 6.3007067354635655, -8.9492884935892008)
    sketchRapidDimensionBuilder24.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point67)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.TextCentered = False
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject29 = sketchRapidDimensionBuilder24.Commit()
    
    theSession.DeleteUndoMark(markId161, None)
    
    theSession.SetUndoMarkName(markId160, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId160, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder24.Destroy()
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder25 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines113 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBelow(lines116)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder25.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId162, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder25.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits721 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits722 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits723 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits724 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits725 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits726 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits727 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits728 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits729 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits730 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder25.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits731 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits732 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits733 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits734 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits735 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits736 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits737 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits738 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits739 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits740 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    expression84 = workPart.Expressions.FindObject("p39")
    expression84.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId162, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId163, None)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId162, "Edit Driving Value")
    
    sketchRapidDimensionBuilder25.Destroy()
    
    theSession.UndoToMark(markId164, None)
    
    theSession.DeleteUndoMark(markId164, None)
    
    sketchRapidDimensionBuilder25.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch13 = theSession.ActiveSketch
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section6
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression85 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies54 = [NXOpen.Body.Null] * 1 
    targetBodies54[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies54)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("14")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies55 = [NXOpen.Body.Null] * 1 
    targetBodies55[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies55)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId166, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features5 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature5 = feature12
    features5[0] = sketchFeature5
    curveFeatureRule5 = workPart.ScRuleFactory.CreateRuleCurveFeature(features5)
    
    section6.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule5
    helpPoint6 = NXOpen.Point3d(3.9999999999999982, -3.0000000000000062, -3.7897307949061956)
    section6.AddToSection(rules5, line18, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId168, None)
    
    direction16 = workPart.Directions.CreateDirection(sketch13, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction16
    
    targetBodies56 = [NXOpen.Body.Null] * 1 
    targetBodies56[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies56)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies57 = [NXOpen.Body.Null] * 1 
    targetBodies57[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies57)
    
    expression86 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId167, None)
    
    direction17 = extrudeBuilder5.Direction
    
    success3 = direction17.ReverseDirection()
    
    extrudeBuilder5.Direction = direction17
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies58 = [NXOpen.Body.Null] * 1 
    targetBodies58[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies58)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies59 = [NXOpen.Body.Null] * 1 
    targetBodies59[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies59)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies60 = [NXOpen.Body.Null] * 1 
    targetBodies60[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies60)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies61 = [NXOpen.Body.Null] * 1 
    targetBodies61[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies61)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies62 = [NXOpen.Body.Null] * 1 
    targetBodies62[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies62)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies63 = [NXOpen.Body.Null] * 1 
    targetBodies63[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies63)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies64 = [NXOpen.Body.Null] * 1 
    targetBodies64[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies64)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies65 = [NXOpen.Body.Null] * 1 
    targetBodies65[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies65)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies66 = [NXOpen.Body.Null] * 1 
    targetBodies66[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies66)
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("125")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies67 = [NXOpen.Body.Null] * 1 
    targetBodies67[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies67)
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId169, None)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature13 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId170, None)
    
    theSession.SetUndoMarkName(markId166, "Extrude")
    
    expression87 = extrudeBuilder5.Limits.StartExtend.Value
    expression88 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression85)
    
    workPart.Expressions.Delete(expression86)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.19949315280247076
    rotMatrix8.Xy = -0.97958512751414384
    rotMatrix8.Xz = -0.024808465047915357
    rotMatrix8.Yx = -0.97651911369196387
    rotMatrix8.Yy = -0.20084232264114843
    rotMatrix8.Yz = 0.077928056759921246
    rotMatrix8.Zx = -0.081319755159481297
    rotMatrix8.Zy = 0.008679826565841136
    rotMatrix8.Zz = -0.99665026866579365
    translation8 = NXOpen.Point3d(48.030410831851796, 58.591146821517832, 4.8791853095688689)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 2.1897701249376835)
    
    scaleAboutPoint47 = NXOpen.Point3d(36.489751027606339, -9.303678242138087, 0.0)
    viewCenter47 = NXOpen.Point3d(-36.489751027606459, 9.3036782421380249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(45.612188784507943, -11.629597802672594, 0.0)
    viewCenter48 = NXOpen.Point3d(-45.612188784508049, 11.62959780267253, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(57.015235980634934, -14.536997253340743, 0.0)
    viewCenter49 = NXOpen.Point3d(-57.015235980635062, 14.536997253340664, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(73.628947127310099, -20.295158503040629, 0.0)
    viewCenter50 = NXOpen.Point3d(-73.628947127310198, 20.295158503040568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(188.20219658342887, -1.1799510757582088, 0.0)
    viewCenter51 = NXOpen.Point3d(-188.20219658342896, 1.1799510757581082, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.11045183896486642
    rotMatrix9.Xy = -0.99306412352871165
    rotMatrix9.Xz = 0.040299352717259894
    rotMatrix9.Yx = -0.99380817200278848
    rotMatrix9.Yy = -0.11084532553688668
    rotMatrix9.Yz = -0.0076570926011278366
    rotMatrix9.Zx = 0.012070978823587934
    rotMatrix9.Zy = -0.039204086097917139
    rotMatrix9.Zz = -0.99915831133182842
    translation9 = NXOpen.Point3d(153.60996953798013, 45.392144600929804, -0.7242587294152858)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 0.71754387453958024)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar11 = workPart.Scalars.CreateScalar(0.5, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge15 = extrude1.FindObject("EDGE * 120 * 160 {(0,60,0)(60,60,0)(120,60,0) EXTRUDE(2)}")
    point68 = workPart.Points.CreatePoint(edge15, scalar11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge16 = extrude2.FindObject("EDGE * 180 EXTRUDE(2) 160 {(4,-5,-0)(4,-4,-0)(4,-3,-0) EXTRUDE(2)}")
    direction18 = workPart.Directions.CreateDirection(edge16, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform8 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction18, point68, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem8 = workPart.CoordinateSystems.CreateCoordinateSystem(xform8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder1 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder1.Csys = cartesianCoordinateSystem8
    
    datumCsysBuilder1.DisplayScaleFactor = 1.25
    
    feature14 = datumCsysBuilder1.CommitFeature()
    
    datumCsysBuilder1.Destroy()
    
    sketchInPlaceBuilder11 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder11.Csystem = cartesianCoordinateSystem8
    
    sketchInPlaceBuilder11.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject30 = sketchInPlaceBuilder11.Commit()
    
    sketchInPlaceBuilder11.Destroy()
    
    sketch14 = nXObject30
    sketch14.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    theSession.SetUndoMarkVisibility(markId172, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint21 = NXOpen.Point3d(60.0, 60.0, 0.0)
    endPoint21 = NXOpen.Point3d(60.0, -60.0, 0.0)
    line21 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    theSession.ActiveSketch.AddGeometry(line21, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line21
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_22.SplineDefiningPointIndex = 0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = edge15
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint47 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_22, geom2_22)
    
    geom20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom20.Geometry = line21
    geom20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint48 = theSession.ActiveSketch.CreateHorizontalConstraint(geom20)
    
    geom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_23.Geometry = line21
    geom1_23.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_23.SplineDefiningPointIndex = 0
    geom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_23.Geometry = edge6
    geom2_23.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint49 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_23, geom2_23)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.11091094500209095
    rotMatrix10.Xy = -0.98243776881759159
    rotMatrix10.Xz = 0.15004930082961029
    rotMatrix10.Yx = -0.99138867443238454
    rotMatrix10.Yy = -0.11994705259969723
    rotMatrix10.Yz = -0.052547129130438353
    rotMatrix10.Zx = 0.069622255679834946
    rotMatrix10.Zy = -0.1429291256999696
    rotMatrix10.Zz = -0.98728111829442944
    translation10 = NXOpen.Point3d(153.58242317574664, 45.246974746705568, -4.1773353407901066)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 0.71754387453958024)
    
    origin33 = NXOpen.Point3d(40.29640124429276, 54.371314868972888, -9.2608410293086898)
    workPart.ModelingViews.WorkView.SetOrigin(origin33)
    
    origin34 = NXOpen.Point3d(40.29640124429276, 54.371314868972888, -9.2608410293086898)
    workPart.ModelingViews.WorkView.SetOrigin(origin34)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = -0.10580414286364956
    rotMatrix11.Xy = -0.93070213080191433
    rotMatrix11.Xz = -0.35014143866966824
    rotMatrix11.Yx = -0.11014940855000693
    rotMatrix11.Yy = -0.33898147923875105
    rotMatrix11.Yz = 0.93432256984897488
    rotMatrix11.Zx = -0.9882674694377902
    rotMatrix11.Zy = 0.13742307103934562
    rotMatrix11.Zz = -0.066650644386553909
    translation11 = NXOpen.Point3d(63.33960931885089, -6.8899117838882953, 59.296048166267404)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 0.71754387453958024)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder12 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal25 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane25 = workPart.Planes.CreatePlane(origin35, normal25, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder12.PlaneReference = plane25
    
    expression89 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression90 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder11 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder11.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId173, "Create Sketch Dialog")
    
    scaleAboutPoint52 = NXOpen.Point3d(1.1062041335232891, -32.448654583349821, 0.0)
    viewCenter52 = NXOpen.Point3d(-1.1062041335232891, 32.448654583349757, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(0.88496330681863122, -25.958923666679858, 0.0)
    viewCenter53 = NXOpen.Point3d(-0.88496330681863122, 25.958923666679784, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(0.70797064545490485, -20.767138933343883, 0.0)
    viewCenter54 = NXOpen.Point3d(-0.70797064545490485, 20.767138933343823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(0.56637651636392394, -16.613711146675122, 0.0)
    viewCenter55 = NXOpen.Point3d(-0.56637651636392394, 16.613711146675058, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = -0.53775060778101047
    rotMatrix12.Xy = -0.60081057782757208
    rotMatrix12.Xz = -0.59148198062295554
    rotMatrix12.Yx = -0.30541500482788103
    rotMatrix12.Yy = -0.51508560579906049
    rotMatrix12.Yz = 0.80087982464574714
    rotMatrix12.Zx = -0.78584092452425913
    rotMatrix12.Zy = 0.61132108443036348
    rotMatrix12.Zz = 0.093491032049844408
    translation12 = NXOpen.Point3d(88.603294293460408, 23.983709658793881, 47.150455471455544)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 1.7518160999501473)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.51518555045457193
    rotMatrix13.Xy = -0.81786197173309183
    rotMatrix13.Xz = -0.25629210638582151
    rotMatrix13.Yx = -0.75565838809959285
    rotMatrix13.Yy = -0.57454242066950478
    rotMatrix13.Yz = 0.31445414188074378
    rotMatrix13.Zx = -0.40443077169961872
    rotMatrix13.Zy = 0.031667049816609269
    rotMatrix13.Zz = -0.91402021249990228
    translation13 = NXOpen.Point3d(25.427124799325469, 50.998312655096576, 24.265846301977113)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 1.7518160999501473)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.56399626632569089
    rotMatrix14.Xy = -0.78395955912841442
    rotMatrix14.Xz = -0.25945254136713586
    rotMatrix14.Yx = 0.18689283019823544
    rotMatrix14.Yy = -0.18485771714809182
    rotMatrix14.Yz = 0.96483091494380158
    rotMatrix14.Zx = -0.80435022321820682
    rotMatrix14.Zy = -0.59265085342213164
    rotMatrix14.Zz = 0.042257358493456042
    translation14 = NXOpen.Point3d(22.498481847058336, -5.5547604427731194, 48.261013393092405)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 1.7518160999501473)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.98406314858319144
    rotMatrix15.Xy = -0.1123686170062739
    rotMatrix15.Xz = -0.13781514253752306
    rotMatrix15.Yx = 0.095969243184112318
    rotMatrix15.Yy = -0.31684794238926489
    rotMatrix15.Yz = 0.94360865074794753
    rotMatrix15.Zx = -0.14969844342280061
    rotMatrix15.Zy = -0.94179651481399618
    rotMatrix15.Zz = -0.30101445267794641
    translation15 = NXOpen.Point3d(-2.7055310883917016, -0.099345221925730698, 8.9819066053680299)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 1.7518160999501473)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.91889487492910893
    rotMatrix16.Xy = -0.33022184272684063
    rotMatrix16.Xz = -0.21583730774616045
    rotMatrix16.Yx = 0.39213874888147493
    rotMatrix16.Yy = 0.70475872502632142
    rotMatrix16.Yz = 0.59122105943965653
    rotMatrix16.Zx = -0.043120881886780288
    rotMatrix16.Zy = -0.62790817329078374
    rotMatrix16.Zz = 0.77709196074849762
    translation16 = NXOpen.Point3d(1.2045653308532493, -17.869515563767489, 2.5872529132068123)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 1.7518160999501473)
    
    scaleAboutPoint56 = NXOpen.Point3d(34.888793408017705, 48.78389727614595, 0.0)
    viewCenter56 = NXOpen.Point3d(-34.888793408017683, -48.783897276146, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(27.911034726414183, 38.422982870128557, 0.0)
    viewCenter57 = NXOpen.Point3d(-27.911034726414162, -38.422982870128621, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(22.328827781131352, 29.868431966967865, 0.0)
    viewCenter58 = NXOpen.Point3d(-22.32882778113132, -29.868431966967922, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(18.249708593409512, 22.038843004752984, 0.0)
    viewCenter59 = NXOpen.Point3d(-18.249708593409487, -22.038843004753033, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(22.812135741761889, 27.065245795310695, 0.0)
    viewCenter60 = NXOpen.Point3d(-22.812135741761857, -27.065245795310744, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(28.515169677202355, 33.710730253980721, 0.0)
    viewCenter61 = NXOpen.Point3d(-28.515169677202334, -33.710730253980785, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(35.643962096502953, 42.138412817475903, 0.0)
    viewCenter62 = NXOpen.Point3d(-35.643962096502932, -42.138412817475967, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(44.554952620628661, 52.48422384972357, 0.0)
    viewCenter63 = NXOpen.Point3d(-44.554952620628626, -52.484223849723634, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(55.693690775785846, 65.133299381851202, 0.0)
    viewCenter64 = NXOpen.Point3d(-55.693690775785761, -65.133299381851245, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint64, viewCenter64)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.48788924467411715
    rotMatrix17.Xy = -0.83056531114761267
    rotMatrix17.Xz = 0.26856162951842016
    rotMatrix17.Yx = 0.73867139439324081
    rotMatrix17.Yy = 0.55676951983087819
    rotMatrix17.Yz = 0.37996351521223837
    rotMatrix17.Zx = -0.46511144474896199
    rotMatrix17.Zy = 0.012998680916270532
    rotMatrix17.Zz = 0.88515669700792066
    translation17 = NXOpen.Point3d(61.406576839362842, -1.4338479413481124, 27.906686684937714)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 0.89692984317447566)
    
    scaleAboutPoint65 = NXOpen.Point3d(138.64425140158554, 6.4897309166699433, 0.0)
    viewCenter65 = NXOpen.Point3d(-138.64425140158551, -6.4897309166699682, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(110.91540112126843, 5.1917847333359539, 0.0)
    viewCenter66 = NXOpen.Point3d(-110.9154011212683, -5.1917847333359939, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(88.921113069136069, 4.1534277866687628, 0.0)
    viewCenter67 = NXOpen.Point3d(-88.921113069135941, -4.1534277866687948, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(72.194126619188197, 3.0206747539409218, 0.0)
    viewCenter68 = NXOpen.Point3d(-72.194126619188069, -3.0206747539409475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(59.930187118188023, 4.3497716456749238, 0.0)
    viewCenter69 = NXOpen.Point3d(-59.930187118187924, -4.3497716456749549, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(47.654164918172121, 3.5764789086660436, 0.0)
    viewCenter70 = NXOpen.Point3d(-47.654164918171972, -3.5764789086660764, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.15163192846216841
    rotMatrix18.Xy = -0.98292455876593232
    rotMatrix18.Xz = 0.10424523991838465
    rotMatrix18.Yx = -0.82104980988972254
    rotMatrix18.Yy = -0.066529835487212363
    rotMatrix18.Yz = 0.56696648108164016
    rotMatrix18.Zx = -0.55034985959014959
    rotMatrix18.Zy = -0.17156075531671716
    rotMatrix18.Zz = -0.81711806936590559
    translation18 = NXOpen.Point3d(-35.968659140020449, 24.952219014733178, 24.899060845615523)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 3.4215158202151326)
    
    scaleAboutPoint71 = NXOpen.Point3d(25.364001773891236, -20.105611162230819, 0.0)
    viewCenter71 = NXOpen.Point3d(-25.364001773891115, 20.105611162230794, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(31.705002217364001, -25.132013952788515, 0.0)
    viewCenter72 = NXOpen.Point3d(-31.705002217363901, 25.13201395278849, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(39.631252771704979, -31.415017440985626, 0.0)
    viewCenter73 = NXOpen.Point3d(-39.631252771704879, 31.415017440985597, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(48.481829800751925, -39.268771801232042, 0.0)
    viewCenter74 = NXOpen.Point3d(-48.481829800751832, 39.268771801232035, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint74, viewCenter74)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = -0.022460374331870807
    rotMatrix19.Xy = -0.9993737879343535
    rotMatrix19.Xz = -0.027341608851997032
    rotMatrix19.Yx = -0.93666427209483194
    rotMatrix19.Yy = 0.011474343974545434
    rotMatrix19.Yz = 0.35004054166826903
    rotMatrix19.Zx = -0.34950761503282529
    rotMatrix19.Zy = 0.033471949750456739
    rotMatrix19.Zz = -0.93633543968706767
    translation19 = NXOpen.Point3d(10.772400668549919, 2.9087331577304951, 12.848526172176058)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 1.4014528799601189)
    
    scalar12 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge17 = extrude2.FindObject("EDGE * 230 EXTRUDE(2) 160 {(57,-5,0)(57,-4,0)(57,-3,0) EXTRUDE(2)}")
    point69 = workPart.Points.CreatePoint(edge17, scalar12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction19 = workPart.Directions.CreateDirection(edge16, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform9 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction19, point69, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem9 = workPart.CoordinateSystems.CreateCoordinateSystem(xform9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder12.Csystem = cartesianCoordinateSystem9
    
    origin36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal26 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane26 = workPart.Planes.CreatePlane(origin36, normal26, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane26.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom21 = [NXOpen.NXObject.Null] * 1 
    geom21[0] = face2
    plane26.SetGeometry(geom21)
    
    plane26.SetFlip(False)
    
    plane26.SetExpression(None)
    
    plane26.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane26.Evaluate()
    
    origin37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal27 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane27 = workPart.Planes.CreatePlane(origin37, normal27, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression91 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression92 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane27.SynchronizeToPlane(plane26)
    
    scalar13 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point70 = workPart.Points.CreatePoint(edge17, scalar13, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane27.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom22 = [NXOpen.NXObject.Null] * 1 
    geom22[0] = face2
    plane27.SetGeometry(geom22)
    
    plane27.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane27.Evaluate()
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId174, None)
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject31 = sketchInPlaceBuilder12.Commit()
    
    sketch15 = nXObject31
    feature15 = sketch15.Feature
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId177)
    
    sketch15.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId175, None)
    
    theSession.SetUndoMarkName(markId173, "Create Sketch")
    
    sketchInPlaceBuilder12.Destroy()
    
    sketchAlongPathBuilder11.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression90)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point70)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression89)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane25.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression92)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression91)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane27.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId179, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint22 = NXOpen.Point3d(53.790533073937752, 60.0, 0.0)
    endPoint22 = NXOpen.Point3d(53.790533073937752, 42.0, 0.0)
    line22 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    startPoint23 = NXOpen.Point3d(53.790533073937752, 42.0, 0.0)
    endPoint23 = NXOpen.Point3d(65.790533073937752, 42.0, 0.0)
    line23 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    startPoint24 = NXOpen.Point3d(65.790533073937752, 42.0, 0.0)
    endPoint24 = NXOpen.Point3d(65.790533073937752, 60.0, 0.0)
    line24 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    startPoint25 = NXOpen.Point3d(65.790533073937752, 60.0, 0.0)
    endPoint25 = NXOpen.Point3d(53.790533073937752, 60.0, 0.0)
    line25 = workPart.Curves.CreateLine(startPoint25, endPoint25)
    
    theSession.ActiveSketch.AddGeometry(line22, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line23, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_24.Geometry = line22
    geom1_24.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_24.SplineDefiningPointIndex = 0
    geom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_24.Geometry = line23
    geom2_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint50 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_24, geom2_24)
    
    geom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_25.Geometry = line23
    geom1_25.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_25.SplineDefiningPointIndex = 0
    geom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_25.Geometry = line24
    geom2_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint51 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_25, geom2_25)
    
    geom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_26.Geometry = line24
    geom1_26.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_26.SplineDefiningPointIndex = 0
    geom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_26.Geometry = line25
    geom2_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint52 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_26, geom2_26)
    
    geom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_27.Geometry = line25
    geom1_27.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_27.SplineDefiningPointIndex = 0
    geom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_27.Geometry = line22
    geom2_27.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint53 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_27, geom2_27)
    
    geom23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom23.Geometry = line22
    geom23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint54 = theSession.ActiveSketch.CreateHorizontalConstraint(geom23)
    
    conGeom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_25.Geometry = line22
    conGeom1_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_25.SplineDefiningPointIndex = 0
    conGeom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_25.Geometry = line23
    conGeom2_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint55 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_25, conGeom2_25)
    
    conGeom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_26.Geometry = line23
    conGeom1_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_26.SplineDefiningPointIndex = 0
    conGeom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_26.Geometry = line24
    conGeom2_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint56 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_26, conGeom2_26)
    
    conGeom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_27.Geometry = line24
    conGeom1_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_27.SplineDefiningPointIndex = 0
    conGeom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_27.Geometry = line25
    conGeom2_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint57 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_27, conGeom2_27)
    
    conGeom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_28.Geometry = line25
    conGeom1_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_28.SplineDefiningPointIndex = 0
    conGeom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_28.Geometry = line22
    conGeom2_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint58 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_28, conGeom2_28)
    
    conGeom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_29.Geometry = line22
    conGeom1_29.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_29.SplineDefiningPointIndex = 0
    conGeom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_29.Geometry = edge15
    conGeom2_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_29.SplineDefiningPointIndex = 0
    help5 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help5.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help5.Point.X = 53.790533073937752
    help5.Point.Y = 60.0
    help5.Point.Z = 0.0
    help5.Parameter = 0.0
    sketchHelpedGeometricConstraint5 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_29, conGeom2_29, help5)
    
    dimObject1_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_13.Geometry = line22
    dimObject1_13.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_13.AssocValue = 0
    dimObject1_13.HelpPoint.X = 0.0
    dimObject1_13.HelpPoint.Y = 0.0
    dimObject1_13.HelpPoint.Z = 0.0
    dimObject1_13.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line22
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin13 = NXOpen.Point3d(60.212440031134996, 51.0, 0.0)
    sketchDimensionalConstraint13 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_13, dimObject2_11, dimOrigin13, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint13
    dimension13 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression93 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    dimObject1_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_14.Geometry = line23
    dimObject1_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_14.AssocValue = 0
    dimObject1_14.HelpPoint.X = 0.0
    dimObject1_14.HelpPoint.Y = 0.0
    dimObject1_14.HelpPoint.Z = 0.0
    dimObject1_14.View = NXOpen.NXObject.Null
    dimObject2_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_12.Geometry = line23
    dimObject2_12.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_12.AssocValue = 0
    dimObject2_12.HelpPoint.X = 0.0
    dimObject2_12.HelpPoint.Y = 0.0
    dimObject2_12.HelpPoint.Z = 0.0
    dimObject2_12.View = NXOpen.NXObject.Null
    dimOrigin14 = NXOpen.Point3d(59.790533073937752, 48.421906957197244, 0.0)
    sketchDimensionalConstraint14 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_14, dimObject2_12, dimOrigin14, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint12 = sketchDimensionalConstraint14
    dimension14 = sketchHelpedDimensionalConstraint12.AssociatedDimension
    
    expression94 = sketchHelpedDimensionalConstraint12.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line22
    geoms11[1] = line23
    geoms11[2] = line24
    geoms11[3] = line25
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 4 
    geoms12[0] = line22
    geoms12[1] = line23
    geoms12[2] = line24
    geoms12[3] = line25
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms12)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder26 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder26.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines121 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines124)
    
    theSession.SetUndoMarkName(markId180, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder26.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits741 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits742 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits743 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits744 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits745 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits746 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits747 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits748 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits749 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits750 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder26.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits751 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits752 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits753 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits754 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits755 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits756 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits757 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits758 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits759 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits760 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    point71 = NXOpen.Point3d(53.790533073937752, 56.735040283667608, -0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(line22, workPart.ModelingViews.WorkView, point71)
    
    point1_104 = NXOpen.Point3d(53.790533073937752, 60.0, 0.0)
    point2_104 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line22, workPart.ModelingViews.WorkView, point1_104, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_104)
    
    point1_105 = NXOpen.Point3d(53.790533073937752, 42.0, 0.0)
    point2_105 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line22, workPart.ModelingViews.WorkView, point1_105, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_105)
    
    dimensionlinearunits761 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits762 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits763 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits764 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits765 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits766 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin21 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin21.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin21.View = NXOpen.View.Null
    assocOrigin21.ViewOfGeometry = workPart.ModelingViews.WorkView
    point72 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin21.PointOnGeometry = point72
    assocOrigin21.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.DimensionLine = 0
    assocOrigin21.AssociatedView = NXOpen.View.Null
    assocOrigin21.AssociatedPoint = NXOpen.Point.Null
    assocOrigin21.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.XOffsetFactor = 0.0
    assocOrigin21.YOffsetFactor = 0.0
    assocOrigin21.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder26.Origin.SetAssociativeOrigin(assocOrigin21)
    
    point73 = NXOpen.Point3d(44.728508812114988, 53.903157701847995, -0.0)
    sketchRapidDimensionBuilder26.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point73)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.TextCentered = False
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject32 = sketchRapidDimensionBuilder26.Commit()
    
    theSession.DeleteUndoMark(markId181, None)
    
    theSession.SetUndoMarkName(markId180, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId180, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder26.Destroy()
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder27 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines125 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBelow(lines128)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder27.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId182, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder27.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits767 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits768 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits769 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits770 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits771 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits772 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits773 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits774 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits775 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits776 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder27.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits777 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits778 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits779 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits780 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits781 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits782 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits783 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits784 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits785 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits786 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    expression95 = workPart.Expressions.FindObject("p42")
    expression95.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId182, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId183, None)
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId182, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder27.Destroy()
    
    theSession.DeleteUndoMark(markId184, None)
    
    marksRecycled4, undoUnavailable4 = theSession.UndoLastNVisibleMarks(1)
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder28 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines129 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines129)
    
    lines130 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines130)
    
    lines131 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines131)
    
    lines132 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines132)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder28.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId185, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder28.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits787 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits788 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits789 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits790 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits791 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits792 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits793 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits794 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits795 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits796 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder28.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits797 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits798 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits799 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits800 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits801 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits802 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits803 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits804 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits805 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits806 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder28.Destroy()
    
    marksRecycled5, undoUnavailable5 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled6, undoUnavailable6 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId187, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint26 = NXOpen.Point3d(56.0, 44.0, 0.0)
    endPoint26 = NXOpen.Point3d(56.0, 30.000000000000004, 0.0)
    line26 = workPart.Curves.CreateLine(startPoint26, endPoint26)
    
    startPoint27 = NXOpen.Point3d(56.0, 30.000000000000004, 0.0)
    endPoint27 = NXOpen.Point3d(65.0, 30.000000000000004, 0.0)
    line27 = workPart.Curves.CreateLine(startPoint27, endPoint27)
    
    startPoint28 = NXOpen.Point3d(65.0, 30.000000000000004, 0.0)
    endPoint28 = NXOpen.Point3d(65.0, 44.0, 0.0)
    line28 = workPart.Curves.CreateLine(startPoint28, endPoint28)
    
    startPoint29 = NXOpen.Point3d(65.0, 44.0, 0.0)
    endPoint29 = NXOpen.Point3d(56.0, 44.0, 0.0)
    line29 = workPart.Curves.CreateLine(startPoint29, endPoint29)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line27, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line28, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line29, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_28.Geometry = line26
    geom1_28.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_28.SplineDefiningPointIndex = 0
    geom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_28.Geometry = line27
    geom2_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint59 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_28, geom2_28)
    
    geom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_29.Geometry = line27
    geom1_29.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_29.SplineDefiningPointIndex = 0
    geom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_29.Geometry = line28
    geom2_29.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint60 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_29, geom2_29)
    
    geom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_30.Geometry = line28
    geom1_30.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_30.SplineDefiningPointIndex = 0
    geom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_30.Geometry = line29
    geom2_30.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint61 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_30, geom2_30)
    
    geom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_31.Geometry = line29
    geom1_31.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_31.SplineDefiningPointIndex = 0
    geom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_31.Geometry = line26
    geom2_31.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint62 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_31, geom2_31)
    
    geom24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom24.Geometry = line26
    geom24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint63 = theSession.ActiveSketch.CreateHorizontalConstraint(geom24)
    
    conGeom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_30.Geometry = line26
    conGeom1_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_30.SplineDefiningPointIndex = 0
    conGeom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_30.Geometry = line27
    conGeom2_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint64 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_30, conGeom2_30)
    
    conGeom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_31.Geometry = line27
    conGeom1_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_31.SplineDefiningPointIndex = 0
    conGeom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_31.Geometry = line28
    conGeom2_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint65 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_31, conGeom2_31)
    
    conGeom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_32.Geometry = line28
    conGeom1_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_32.SplineDefiningPointIndex = 0
    conGeom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_32.Geometry = line29
    conGeom2_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint66 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_32, conGeom2_32)
    
    conGeom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_33.Geometry = line29
    conGeom1_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_33.SplineDefiningPointIndex = 0
    conGeom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_33.Geometry = line26
    conGeom2_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint67 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_33, conGeom2_33)
    
    dimObject1_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_15.Geometry = line26
    dimObject1_15.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_15.AssocValue = 0
    dimObject1_15.HelpPoint.X = 0.0
    dimObject1_15.HelpPoint.Y = 0.0
    dimObject1_15.HelpPoint.Z = 0.0
    dimObject1_15.View = NXOpen.NXObject.Null
    dimObject2_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_13.Geometry = line26
    dimObject2_13.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_13.AssocValue = 0
    dimObject2_13.HelpPoint.X = 0.0
    dimObject2_13.HelpPoint.Y = 0.0
    dimObject2_13.HelpPoint.Z = 0.0
    dimObject2_13.View = NXOpen.NXObject.Null
    dimOrigin15 = NXOpen.Point3d(62.421906957197244, 37.0, 0.0)
    sketchDimensionalConstraint15 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_15, dimObject2_13, dimOrigin15, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint13 = sketchDimensionalConstraint15
    dimension15 = sketchHelpedDimensionalConstraint13.AssociatedDimension
    
    expression96 = sketchHelpedDimensionalConstraint13.AssociatedExpression
    
    dimObject1_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_16.Geometry = line27
    dimObject1_16.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_16.AssocValue = 0
    dimObject1_16.HelpPoint.X = 0.0
    dimObject1_16.HelpPoint.Y = 0.0
    dimObject1_16.HelpPoint.Z = 0.0
    dimObject1_16.View = NXOpen.NXObject.Null
    dimObject2_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_14.Geometry = line27
    dimObject2_14.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_14.AssocValue = 0
    dimObject2_14.HelpPoint.X = 0.0
    dimObject2_14.HelpPoint.Y = 0.0
    dimObject2_14.HelpPoint.Z = 0.0
    dimObject2_14.View = NXOpen.NXObject.Null
    dimOrigin16 = NXOpen.Point3d(60.5, 36.421906957197244, 0.0)
    sketchDimensionalConstraint16 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_16, dimObject2_14, dimOrigin16, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint14 = sketchDimensionalConstraint16
    dimension16 = sketchHelpedDimensionalConstraint14.AssociatedDimension
    
    expression97 = sketchHelpedDimensionalConstraint14.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms13 = [NXOpen.SmartObject.Null] * 4 
    geoms13[0] = line26
    geoms13[1] = line27
    geoms13[2] = line28
    geoms13[3] = line29
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms13)
    
    geoms14 = [NXOpen.SmartObject.Null] * 4 
    geoms14[0] = line26
    geoms14[1] = line27
    geoms14[2] = line28
    geoms14[3] = line29
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms14)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder29 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines133 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBefore(lines133)
    
    lines134 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAfter(lines134)
    
    lines135 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAbove(lines135)
    
    lines136 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBelow(lines136)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder29.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines137 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBefore(lines137)
    
    lines138 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAfter(lines138)
    
    lines139 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAbove(lines139)
    
    lines140 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBelow(lines140)
    
    theSession.SetUndoMarkName(markId188, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder29.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits807 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits808 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits809 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits810 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits811 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits812 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits813 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits814 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits815 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits816 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder29.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits817 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits818 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits819 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits820 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits821 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits822 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits823 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits824 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits825 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits826 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    point74 = NXOpen.Point3d(56.0, 33.51360311274675, -0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(line26, workPart.ModelingViews.WorkView, point74)
    
    point1_106 = NXOpen.Point3d(56.0, 30.000000000000004, 0.0)
    point2_106 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line26, workPart.ModelingViews.WorkView, point1_106, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_106)
    
    point1_107 = NXOpen.Point3d(56.0, 44.0, 0.0)
    point2_107 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line26, workPart.ModelingViews.WorkView, point1_107, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_107)
    
    dimensionlinearunits827 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits828 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits829 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits830 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits831 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits832 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin22 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin22.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin22.View = NXOpen.View.Null
    assocOrigin22.ViewOfGeometry = workPart.ModelingViews.WorkView
    point75 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin22.PointOnGeometry = point75
    assocOrigin22.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.DimensionLine = 0
    assocOrigin22.AssociatedView = NXOpen.View.Null
    assocOrigin22.AssociatedPoint = NXOpen.Point.Null
    assocOrigin22.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.XOffsetFactor = 0.0
    assocOrigin22.YOffsetFactor = 0.0
    assocOrigin22.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder29.Origin.SetAssociativeOrigin(assocOrigin22)
    
    point76 = NXOpen.Point3d(48.881936598783753, 33.891187456989371, -0.0)
    sketchRapidDimensionBuilder29.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point76)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.TextCentered = False
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject33 = sketchRapidDimensionBuilder29.Commit()
    
    theSession.DeleteUndoMark(markId189, None)
    
    theSession.SetUndoMarkName(markId188, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId188, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder29.Destroy()
    
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder30 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines141 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBefore(lines141)
    
    lines142 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAfter(lines142)
    
    lines143 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAbove(lines143)
    
    lines144 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBelow(lines144)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder30.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId190, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder30.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits833 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits834 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits835 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits836 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits837 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits838 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits839 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits840 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits841 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits842 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder30.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits843 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits844 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits845 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits846 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits847 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits848 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits849 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits850 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits851 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits852 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    expression98 = workPart.Expressions.FindObject("p42")
    expression98.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId190, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.42857142857142855)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId191, None)
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId190, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder30.Destroy()
    
    theSession.DeleteUndoMark(markId192, None)
    
    marksRecycled7, undoUnavailable7 = theSession.UndoLastNVisibleMarks(1)
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder31 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines145 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBefore(lines145)
    
    lines146 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAfter(lines146)
    
    lines147 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAbove(lines147)
    
    lines148 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBelow(lines148)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder31.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId193, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder31.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits853 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits854 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits855 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits856 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits857 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits858 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits859 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits860 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits861 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits862 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder31.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits863 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits864 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits865 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits866 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits867 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits868 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits869 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits870 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits871 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits872 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint75 = NXOpen.Point3d(-37.192057907897606, 0.94396086060654993, 0.0)
    viewCenter75 = NXOpen.Point3d(37.192057907897706, -0.94396086060654993, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-29.753646326318062, 0.75516868848525254, 0.0)
    viewCenter76 = NXOpen.Point3d(29.75364632631819, -0.75516868848523966, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    sketchRapidDimensionBuilder31.Destroy()
    
    theSession.UndoToMark(markId193, None)
    
    theSession.DeleteUndoMark(markId193, None)
    
    scaleAboutPoint77 = NXOpen.Point3d(-33.469076273665372, -2.658193783467997, 0.0)
    viewCenter77 = NXOpen.Point3d(33.469076273665515, 2.6581937834680174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-26.775261018932287, -2.126555026774406, 0.0)
    viewCenter78 = NXOpen.Point3d(26.775261018932429, 2.126555026774406, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-21.420208815145823, -1.7012440214195246, 0.0)
    viewCenter79 = NXOpen.Point3d(21.420208815145969, 1.7012440214195179, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-17.136167052116644, -1.360995217135625, 0.0)
    viewCenter80 = NXOpen.Point3d(17.136167052116779, 1.3609952171356143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint80, viewCenter80)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder32 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines149 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBefore(lines149)
    
    lines150 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAfter(lines150)
    
    lines151 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAbove(lines151)
    
    lines152 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBelow(lines152)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder32.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines153 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBefore(lines153)
    
    lines154 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAfter(lines154)
    
    lines155 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAbove(lines155)
    
    lines156 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBelow(lines156)
    
    theSession.SetUndoMarkName(markId194, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder32.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits873 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits874 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits875 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits876 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits877 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits878 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits879 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits880 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits881 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits882 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder32.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits883 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits884 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits885 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits886 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits887 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits888 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits889 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits890 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits891 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits892 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    point77 = NXOpen.Point3d(56.0, 41.016874622642888, -0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(line26, workPart.ModelingViews.WorkView, point77)
    
    point1_108 = NXOpen.Point3d(56.0, 44.0, 0.0)
    point2_108 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line26, workPart.ModelingViews.WorkView, point1_108, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_108)
    
    point1_109 = NXOpen.Point3d(56.0, 30.000000000000004, 0.0)
    point2_109 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line26, workPart.ModelingViews.WorkView, point1_109, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_109)
    
    dimensionlinearunits893 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits894 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits895 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits896 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits897 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits898 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    point1_110 = NXOpen.Point3d(60.0, 60.0, 0.0)
    point2_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, workPart.ModelingViews.WorkView, point1_110, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_110)
    
    point1_111 = NXOpen.Point3d(56.0, 41.016874622642888, -0.0)
    point2_111 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line26, workPart.ModelingViews.WorkView, point1_111, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_111)
    
    point1_112 = NXOpen.Point3d(60.0, 60.0, 0.0)
    point2_112 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, workPart.ModelingViews.WorkView, point1_112, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_112)
    
    point1_113 = NXOpen.Point3d(56.0, 41.016874622642888, -0.0)
    point2_113 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line26, workPart.ModelingViews.WorkView, point1_113, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_113)
    
    point1_114 = NXOpen.Point3d(60.0, 60.0, 0.0)
    point2_114 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, workPart.ModelingViews.WorkView, point1_114, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_114)
    
    dimensionlinearunits899 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits900 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits901 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits902 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits903 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits904 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits905 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits906 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits907 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits908 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits909 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits910 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin23 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin23.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin23.View = NXOpen.View.Null
    assocOrigin23.ViewOfGeometry = workPart.ModelingViews.WorkView
    point78 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin23.PointOnGeometry = point78
    assocOrigin23.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.DimensionLine = 0
    assocOrigin23.AssociatedView = NXOpen.View.Null
    assocOrigin23.AssociatedPoint = NXOpen.Point.Null
    assocOrigin23.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.XOffsetFactor = 0.0
    assocOrigin23.YOffsetFactor = 0.0
    assocOrigin23.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder32.Origin.SetAssociativeOrigin(assocOrigin23)
    
    point79 = NXOpen.Point3d(58.971932727469671, 40.769420946800047, -0.0)
    sketchRapidDimensionBuilder32.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point79)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.TextCentered = False
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject34 = sketchRapidDimensionBuilder32.Commit()
    
    theSession.DeleteUndoMark(markId195, None)
    
    theSession.SetUndoMarkName(markId194, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder32.Destroy()
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder33 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines157 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBefore(lines157)
    
    lines158 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAfter(lines158)
    
    lines159 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAbove(lines159)
    
    lines160 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBelow(lines160)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder33.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId196, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder33.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits911 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits912 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits913 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits914 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits915 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits916 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits917 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits918 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits919 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits920 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder33.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits921 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits922 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits923 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits924 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits925 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits926 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits927 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits928 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits929 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits930 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    expression99 = workPart.Expressions.FindObject("p43")
    expression99.SetFormula("5")
    
    theSession.SetUndoMarkVisibility(markId196, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId197, None)
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId196, "Edit Driving Value")
    
    point80 = NXOpen.Point3d(56.992303320726947, 44.0, -0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(line29, workPart.ModelingViews.WorkView, point80)
    
    point1_115 = NXOpen.Point3d(55.0, 44.0, 0.0)
    point2_115 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line29, workPart.ModelingViews.WorkView, point1_115, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_115)
    
    point1_116 = NXOpen.Point3d(64.0, 44.0, 0.0)
    point2_116 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line29, workPart.ModelingViews.WorkView, point1_116, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_116)
    
    dimensionlinearunits931 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits932 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits933 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits934 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits935 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits936 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin24 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin24.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin24.View = NXOpen.View.Null
    assocOrigin24.ViewOfGeometry = workPart.ModelingViews.WorkView
    point81 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin24.PointOnGeometry = point81
    assocOrigin24.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.DimensionLine = 0
    assocOrigin24.AssociatedView = NXOpen.View.Null
    assocOrigin24.AssociatedPoint = NXOpen.Point.Null
    assocOrigin24.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.XOffsetFactor = 0.0
    assocOrigin24.YOffsetFactor = 0.0
    assocOrigin24.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder33.Origin.SetAssociativeOrigin(assocOrigin24)
    
    point82 = NXOpen.Point3d(56.794340380052674, 46.856781372533924, -0.0)
    sketchRapidDimensionBuilder33.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point82)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.TextCentered = False
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject35 = sketchRapidDimensionBuilder33.Commit()
    
    theSession.DeleteUndoMark(markId199, None)
    
    theSession.SetUndoMarkName(markId198, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId198, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder33.Destroy()
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder34 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines161 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBefore(lines161)
    
    lines162 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAfter(lines162)
    
    lines163 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAbove(lines163)
    
    lines164 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBelow(lines164)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder34.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId200, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder34.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits937 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits938 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits939 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits940 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits941 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits942 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits943 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits944 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits945 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits946 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder34.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits947 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits948 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits949 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits950 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits951 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits952 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits953 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits954 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits955 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits956 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    expression100 = workPart.Expressions.FindObject("p44")
    expression100.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId200, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId201, None)
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId200, "Edit Driving Value")
    
    horizontalDimension1 = nXObject33
    point83 = NXOpen.Point3d(47.935498784878988, 33.24682920117769, -0.0)
    sketchRapidDimensionBuilder34.FirstAssociativity.SetValue(horizontalDimension1, workPart.ModelingViews.WorkView, point83)
    
    point1_117 = NXOpen.Point3d(55.0, 30.000000000000004, 0.0)
    point2_117 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder34.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line26, NXOpen.View.Null, point1_117, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_117)
    
    point1_118 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_118 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder34.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_118, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_118)
    
    sketchRapidDimensionBuilder34.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    expression98.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId202, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId203, None)
    
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId202, "Edit Driving Value")
    
    point1_119 = NXOpen.Point3d(60.0, 36.0, 0.0)
    point2_119 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder34.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line29, workPart.ModelingViews.WorkView, point1_119, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_119)
    
    point1_120 = NXOpen.Point3d(60.0, 60.0, 0.0)
    point2_120 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder34.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, workPart.ModelingViews.WorkView, point1_120, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_120)
    
    point1_121 = NXOpen.Point3d(60.0, 36.0, 0.0)
    point2_121 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder34.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line29, workPart.ModelingViews.WorkView, point1_121, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_121)
    
    point1_122 = NXOpen.Point3d(60.0, 60.0, 0.0)
    point2_122 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder34.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, workPart.ModelingViews.WorkView, point1_122, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_122)
    
    dimensionlinearunits957 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits958 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits959 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits960 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits961 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits962 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin25 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin25.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin25.View = NXOpen.View.Null
    assocOrigin25.ViewOfGeometry = workPart.ModelingViews.WorkView
    point84 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin25.PointOnGeometry = point84
    assocOrigin25.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.DimensionLine = 0
    assocOrigin25.AssociatedView = NXOpen.View.Null
    assocOrigin25.AssociatedPoint = NXOpen.Point.Null
    assocOrigin25.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.XOffsetFactor = 0.0
    assocOrigin25.YOffsetFactor = 0.0
    assocOrigin25.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder34.Origin.SetAssociativeOrigin(assocOrigin25)
    
    point85 = NXOpen.Point3d(56.497395969041264, 52.795669592762096, -0.0)
    sketchRapidDimensionBuilder34.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point85)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.TextCentered = False
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject36 = sketchRapidDimensionBuilder34.Commit()
    
    theSession.DeleteUndoMark(markId205, None)
    
    theSession.SetUndoMarkName(markId204, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId204, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder34.Destroy()
    
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder35 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines165 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBefore(lines165)
    
    lines166 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAfter(lines166)
    
    lines167 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAbove(lines167)
    
    lines168 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBelow(lines168)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder35.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder35.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder35.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId206, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder35.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits963 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits964 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits965 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits966 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits967 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits968 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits969 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits970 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits971 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits972 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder35.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder35.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits973 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits974 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits975 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits976 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits977 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits978 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits979 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits980 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits981 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits982 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    expression101 = workPart.Expressions.FindObject("p45")
    expression101.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId206, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId207, None)
    
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId206, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder35.Destroy()
    
    theSession.UndoToMark(markId208, None)
    
    theSession.DeleteUndoMark(markId208, None)
    
    sketchRapidDimensionBuilder35.Destroy()
    
    sketch16 = theSession.ActiveSketch
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section7
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression102 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies68 = [NXOpen.Body.Null] * 1 
    targetBodies68[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies68)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("125")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies69 = [NXOpen.Body.Null] * 1 
    targetBodies69[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies69)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId210, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features6 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature6 = feature15
    features6[0] = sketchFeature6
    curveFeatureRule6 = workPart.ScRuleFactory.CreateRuleCurveFeature(features6)
    
    section7.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = curveFeatureRule6
    helpPoint7 = NXOpen.Point3d(55.000000000000213, 53.372938597826113, 3.5527136788005009e-14)
    section7.AddToSection(rules6, line26, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId212, None)
    
    direction20 = workPart.Directions.CreateDirection(sketch16, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction20
    
    targetBodies70 = [NXOpen.Body.Null] * 1 
    targetBodies70[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies70)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies71 = [NXOpen.Body.Null] * 1 
    targetBodies71[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies71)
    
    expression103 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId211, None)
    
    scaleAboutPoint81 = NXOpen.Point3d(-31.905877088500979, -48.519588235176109, 0.0)
    viewCenter81 = NXOpen.Point3d(31.905877088501079, 48.519588235176109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-40.826307221232767, -60.413495078818464, 0.0)
    viewCenter82 = NXOpen.Point3d(40.826307221232867, 60.413495078818507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-51.622859564420068, -75.516868848523089, 0.0)
    viewCenter83 = NXOpen.Point3d(51.622859564420168, 75.516868848523146, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(-64.528574455525103, -94.396086060653857, 0.0)
    viewCenter84 = NXOpen.Point3d(64.528574455525174, 94.396086060653914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-114.76867885304104, -80.660718069406343, 0.0)
    viewCenter85 = NXOpen.Point3d(114.76867885304119, 80.660718069406414, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(-95.133555483002681, -61.209962054955199, 0.0)
    viewCenter86 = NXOpen.Point3d(95.133555483002809, 61.209962054955263, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint86, viewCenter86)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies72 = [NXOpen.Body.Null] * 1 
    targetBodies72[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies72)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = -0.81922052448460392
    rotMatrix20.Xy = -0.44577829289024207
    rotMatrix20.Xz = -0.36077617140137958
    rotMatrix20.Yx = -0.45351436269580819
    rotMatrix20.Yy = 0.11854270441847509
    rotMatrix20.Yz = 0.88333026103365098
    rotMatrix20.Zx = -0.35100207277420759
    rotMatrix20.Zy = 0.88725945518603599
    rotMatrix20.Zz = -0.29927947489126921
    translation20 = NXOpen.Point3d(47.849304717670996, -68.479091613487313, 4.4738962095179327)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 0.89692984317447633)
    
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId213, None)
    
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    feature16 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId214, None)
    
    theSession.SetUndoMarkName(markId210, "Extrude")
    
    expression104 = extrudeBuilder6.Limits.StartExtend.Value
    expression105 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression102)
    
    workPart.Expressions.Delete(expression103)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = -0.90598481867494407
    rotMatrix21.Xy = 0.21580046827074734
    rotMatrix21.Xz = -0.36417257752974169
    rotMatrix21.Yx = -0.18737195867900461
    rotMatrix21.Yy = 0.56699262972122233
    rotMatrix21.Yz = 0.80212910864935338
    rotMatrix21.Zx = 0.37958300466607159
    rotMatrix21.Zy = 0.79495252420250906
    rotMatrix21.Zz = -0.47325175840427519
    translation21 = NXOpen.Point3d(53.055162369091406, -84.447635854495559, -39.361208436898849)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 0.89692984317447633)
    
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = -0.91485798468886648
    rotMatrix22.Xy = 0.32927989293236243
    rotMatrix22.Xz = 0.23368701282159543
    rotMatrix22.Yx = -0.37403521527548511
    rotMatrix22.Yy = -0.47311133678293965
    rotMatrix22.Yz = -0.79766115659550929
    rotMatrix22.Zx = -0.15209380521523716
    rotMatrix22.Zy = -0.81715385033536792
    rotMatrix22.Zz = 0.55599195974153903
    translation22 = NXOpen.Point3d(53.587552329926751, -73.247840458706861, -7.4605998440203214)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 0.89692984317447633)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = 0.001514344207243713
    rotMatrix23.Xy = -0.99658414123193784
    rotMatrix23.Xz = -0.082569705138299254
    rotMatrix23.Yx = -0.99389433490028445
    rotMatrix23.Yy = 0.0076096201949597932
    rotMatrix23.Yz = -0.11007336069009613
    rotMatrix23.Zx = 0.11032568973156609
    rotMatrix23.Zy = 0.08223225112747494
    rotMatrix23.Zz = -0.99048780863762509
    translation23 = NXOpen.Point3d(-1.3947874038398584, -36.056293281218828, -23.205769540828506)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 0.89692984317447633)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = -0.0080363266423271965
    rotMatrix24.Xy = -0.99996181375433146
    rotMatrix24.Xz = 0.0034334366527472605
    rotMatrix24.Yx = -0.99389433490028445
    rotMatrix24.Yy = 0.0076096201949597932
    rotMatrix24.Yz = -0.11007336069009613
    rotMatrix24.Zx = 0.11004303025281348
    rotMatrix24.Zy = -0.0042970587195292152
    rotMatrix24.Zz = -0.9939175352005527
    translation24 = NXOpen.Point3d(-0.82174715286560374, -36.056293281218828, -23.18880997210335)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 0.89692984317447633)
    
    scaleAboutPoint87 = NXOpen.Point3d(23.894009284103035, -74.631905541704398, 0.0)
    viewCenter87 = NXOpen.Point3d(-23.894009284102985, 74.631905541704469, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(28.761307471605477, -93.658616638304963, 0.0)
    viewCenter88 = NXOpen.Point3d(-28.761307471605477, 93.658616638305034, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(29.037858504986218, -123.06520985446569, 0.0)
    viewCenter89 = NXOpen.Point3d(-29.037858504986374, 123.06520985446578, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint89, viewCenter89)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled8, undoUnavailable8 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled9, undoUnavailable9 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder34.Destroy()
    
    marksRecycled10, undoUnavailable10 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder34.Destroy()
    
    marksRecycled11, undoUnavailable11 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled12, undoUnavailable12 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    sketchRapidDimensionBuilder33.Destroy()
    
    marksRecycled13, undoUnavailable13 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled14, undoUnavailable14 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled15, undoUnavailable15 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled16, undoUnavailable16 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled17, undoUnavailable17 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId216, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint30 = NXOpen.Point3d(53.0, -28.999999999999996, 0.0)
    endPoint30 = NXOpen.Point3d(53.0, -45.0, 0.0)
    line30 = workPart.Curves.CreateLine(startPoint30, endPoint30)
    
    startPoint31 = NXOpen.Point3d(53.0, -45.0, 0.0)
    endPoint31 = NXOpen.Point3d(68.0, -45.0, 0.0)
    line31 = workPart.Curves.CreateLine(startPoint31, endPoint31)
    
    startPoint32 = NXOpen.Point3d(68.0, -45.0, 0.0)
    endPoint32 = NXOpen.Point3d(68.0, -28.999999999999996, 0.0)
    line32 = workPart.Curves.CreateLine(startPoint32, endPoint32)
    
    startPoint33 = NXOpen.Point3d(68.0, -28.999999999999996, 0.0)
    endPoint33 = NXOpen.Point3d(53.0, -28.999999999999996, 0.0)
    line33 = workPart.Curves.CreateLine(startPoint33, endPoint33)
    
    theSession.ActiveSketch.AddGeometry(line30, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line31, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line32, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line33, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_32.Geometry = line30
    geom1_32.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_32.SplineDefiningPointIndex = 0
    geom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_32.Geometry = line31
    geom2_32.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint68 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_32, geom2_32)
    
    geom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_33.Geometry = line31
    geom1_33.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_33.SplineDefiningPointIndex = 0
    geom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_33.Geometry = line32
    geom2_33.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint69 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_33, geom2_33)
    
    geom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_34.Geometry = line32
    geom1_34.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_34.SplineDefiningPointIndex = 0
    geom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_34.Geometry = line33
    geom2_34.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint70 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_34, geom2_34)
    
    geom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_35.Geometry = line33
    geom1_35.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_35.SplineDefiningPointIndex = 0
    geom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_35.Geometry = line30
    geom2_35.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint71 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_35, geom2_35)
    
    geom25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom25.Geometry = line30
    geom25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint72 = theSession.ActiveSketch.CreateHorizontalConstraint(geom25)
    
    conGeom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_34.Geometry = line30
    conGeom1_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_34.SplineDefiningPointIndex = 0
    conGeom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_34.Geometry = line31
    conGeom2_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint73 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_34, conGeom2_34)
    
    conGeom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_35.Geometry = line31
    conGeom1_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_35.SplineDefiningPointIndex = 0
    conGeom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_35.Geometry = line32
    conGeom2_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint74 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_35, conGeom2_35)
    
    conGeom1_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_36.Geometry = line32
    conGeom1_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_36.SplineDefiningPointIndex = 0
    conGeom2_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_36.Geometry = line33
    conGeom2_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_36.SplineDefiningPointIndex = 0
    sketchGeometricConstraint75 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_36, conGeom2_36)
    
    conGeom1_37 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_37.Geometry = line33
    conGeom1_37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_37.SplineDefiningPointIndex = 0
    conGeom2_37 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_37.Geometry = line30
    conGeom2_37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_37.SplineDefiningPointIndex = 0
    sketchGeometricConstraint76 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_37, conGeom2_37)
    
    dimObject1_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_17.Geometry = line30
    dimObject1_17.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_17.AssocValue = 0
    dimObject1_17.HelpPoint.X = 0.0
    dimObject1_17.HelpPoint.Y = 0.0
    dimObject1_17.HelpPoint.Z = 0.0
    dimObject1_17.View = NXOpen.NXObject.Null
    dimObject2_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_15.Geometry = line30
    dimObject2_15.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_15.AssocValue = 0
    dimObject2_15.HelpPoint.X = 0.0
    dimObject2_15.HelpPoint.Y = 0.0
    dimObject2_15.HelpPoint.Z = 0.0
    dimObject2_15.View = NXOpen.NXObject.Null
    dimOrigin17 = NXOpen.Point3d(65.542787025775851, -37.0, 0.0)
    sketchDimensionalConstraint17 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_17, dimObject2_15, dimOrigin17, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint15 = sketchDimensionalConstraint17
    dimension17 = sketchHelpedDimensionalConstraint15.AssociatedDimension
    
    expression106 = sketchHelpedDimensionalConstraint15.AssociatedExpression
    
    dimObject1_18 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_18.Geometry = line31
    dimObject1_18.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_18.AssocValue = 0
    dimObject1_18.HelpPoint.X = 0.0
    dimObject1_18.HelpPoint.Y = 0.0
    dimObject1_18.HelpPoint.Z = 0.0
    dimObject1_18.View = NXOpen.NXObject.Null
    dimObject2_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_16.Geometry = line31
    dimObject2_16.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_16.AssocValue = 0
    dimObject2_16.HelpPoint.X = 0.0
    dimObject2_16.HelpPoint.Y = 0.0
    dimObject2_16.HelpPoint.Z = 0.0
    dimObject2_16.View = NXOpen.NXObject.Null
    dimOrigin18 = NXOpen.Point3d(60.5, -32.457212974224149, 0.0)
    sketchDimensionalConstraint18 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_18, dimObject2_16, dimOrigin18, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint16 = sketchDimensionalConstraint18
    dimension18 = sketchHelpedDimensionalConstraint16.AssociatedDimension
    
    expression107 = sketchHelpedDimensionalConstraint16.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms15 = [NXOpen.SmartObject.Null] * 4 
    geoms15[0] = line30
    geoms15[1] = line31
    geoms15[2] = line32
    geoms15[3] = line33
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms15)
    
    geoms16 = [NXOpen.SmartObject.Null] * 4 
    geoms16[0] = line30
    geoms16[1] = line31
    geoms16[2] = line32
    geoms16[3] = line33
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms16)
    
    scaleAboutPoint90 = NXOpen.Point3d(84.808983570118571, -76.328085213106775, 0.0)
    viewCenter90 = NXOpen.Point3d(-84.808983570118698, 76.328085213106831, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(67.552199087155287, -63.71735809094131, 0.0)
    viewCenter91 = NXOpen.Point3d(-67.552199087155429, 63.71735809094136, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint91, viewCenter91)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder36 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines169 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBefore(lines169)
    
    lines170 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAfter(lines170)
    
    lines171 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAbove(lines171)
    
    lines172 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBelow(lines172)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder36.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines173 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBefore(lines173)
    
    lines174 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAfter(lines174)
    
    lines175 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAbove(lines175)
    
    lines176 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBelow(lines176)
    
    theSession.SetUndoMarkName(markId217, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder36.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits983 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits984 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits985 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits986 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits987 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits988 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits989 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits990 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits991 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits992 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder36.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits993 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits994 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits995 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits996 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits997 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits998 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits999 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1000 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1001 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1002 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint92 = NXOpen.Point3d(20.295158503040508, -76.932810139432831, 0.0)
    viewCenter92 = NXOpen.Point3d(-20.295158503040586, 76.932810139432888, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(16.047334630311109, -61.735040283667594, 0.0)
    viewCenter93 = NXOpen.Point3d(-16.047334630311173, 61.735040283667644, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(8.9109905241256815, -48.934931013842942, 0.0)
    viewCenter94 = NXOpen.Point3d(-8.910990524125733, 48.934931013842984, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(11.1387381551571, -61.168663767303677, 0.0)
    viewCenter95 = NXOpen.Point3d(-11.138738155157164, 61.16866376730372, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    origin38 = NXOpen.Point3d(45.563642234269068, -41.727088813938266, -18.105672073518445)
    workPart.ModelingViews.WorkView.SetOrigin(origin38)
    
    origin39 = NXOpen.Point3d(45.563642234269068, -41.727088813938266, -18.105672073518445)
    workPart.ModelingViews.WorkView.SetOrigin(origin39)
    
    point86 = NXOpen.Point3d(53.000000000000171, -41.492715163701305, -7.9047879353311146e-14)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(line30, workPart.ModelingViews.WorkView, point86)
    
    point1_123 = NXOpen.Point3d(53.0, -45.0, 0.0)
    point2_123 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line30, workPart.ModelingViews.WorkView, point1_123, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_123)
    
    point1_124 = NXOpen.Point3d(53.0, -28.999999999999996, 0.0)
    point2_124 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line30, workPart.ModelingViews.WorkView, point1_124, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_124)
    
    dimensionlinearunits1003 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1004 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1005 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1006 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1007 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1008 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    point1_125 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_125 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line21, workPart.ModelingViews.WorkView, point1_125, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_125)
    
    point1_126 = NXOpen.Point3d(53.000000000000171, -41.492715163701305, -7.9047879353311146e-14)
    point2_126 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line30, workPart.ModelingViews.WorkView, point1_126, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_126)
    
    point1_127 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_127 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line21, workPart.ModelingViews.WorkView, point1_127, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_127)
    
    point1_128 = NXOpen.Point3d(53.000000000000171, -41.492715163701305, -7.9047879353311146e-14)
    point2_128 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line30, workPart.ModelingViews.WorkView, point1_128, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_128)
    
    point1_129 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_129 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line21, workPart.ModelingViews.WorkView, point1_129, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_129)
    
    dimensionlinearunits1009 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1010 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1011 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1012 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1013 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1014 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1015 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1016 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1017 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1018 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1019 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1020 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin26 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin26.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin26.View = NXOpen.View.Null
    assocOrigin26.ViewOfGeometry = workPart.ModelingViews.WorkView
    point87 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin26.PointOnGeometry = point87
    assocOrigin26.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.DimensionLine = 0
    assocOrigin26.AssociatedView = NXOpen.View.Null
    assocOrigin26.AssociatedPoint = NXOpen.Point.Null
    assocOrigin26.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.XOffsetFactor = 0.0
    assocOrigin26.YOffsetFactor = 0.0
    assocOrigin26.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder36.Origin.SetAssociativeOrigin(assocOrigin26)
    
    point88 = NXOpen.Point3d(53.587657165769429, -65.329330536955169, 0.0)
    sketchRapidDimensionBuilder36.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point88)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.TextCentered = False
    
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject37 = sketchRapidDimensionBuilder36.Commit()
    
    theSession.DeleteUndoMark(markId218, None)
    
    theSession.SetUndoMarkName(markId217, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId217, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder36.Destroy()
    
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder37 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines177 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBefore(lines177)
    
    lines178 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAfter(lines178)
    
    lines179 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAbove(lines179)
    
    lines180 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBelow(lines180)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder37.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId219, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder37.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1021 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1022 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1023 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1024 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1025 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1026 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1027 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1028 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1029 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1030 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder37.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1031 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1032 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1033 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1034 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1035 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1036 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1037 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1038 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1039 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1040 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    expression108 = workPart.Expressions.FindObject("p42")
    expression108.SetFormula("5")
    
    theSession.SetUndoMarkVisibility(markId219, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId220, None)
    
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId219, "Edit Driving Value")
    
    scaleAboutPoint96 = NXOpen.Point3d(11.563520542430043, -7.5516868848522609, 0.0)
    viewCenter96 = NXOpen.Point3d(-11.563520542430123, 7.5516868848523213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(9.2508164339440331, -6.0413495078818249, 0.0)
    viewCenter97 = NXOpen.Point3d(-9.2508164339440988, 6.0413495078818729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(7.4006531471552277, -4.8330796063054473, 0.0)
    viewCenter98 = NXOpen.Point3d(-7.4006531471552792, 4.8330796063054988, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(3.020674753940896, -6.5246574685123742, 0.0)
    viewCenter99 = NXOpen.Point3d(-3.0206747539409475, 6.5246574685124159, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    point89 = NXOpen.Point3d(57.788630094268953, -45.000000000000185, -8.3488771451811772e-14)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(line31, workPart.ModelingViews.WorkView, point89)
    
    point1_130 = NXOpen.Point3d(55.0, -45.0, 0.0)
    point2_130 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line31, workPart.ModelingViews.WorkView, point1_130, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_130)
    
    point1_131 = NXOpen.Point3d(70.0, -45.0, 0.0)
    point2_131 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line31, workPart.ModelingViews.WorkView, point1_131, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_131)
    
    dimensionlinearunits1041 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1042 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1043 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1044 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1045 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1046 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    assocOrigin27 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin27.OriginType = NXOpen.Annotations.AssociativeOriginType.Drag
    assocOrigin27.View = NXOpen.View.Null
    assocOrigin27.ViewOfGeometry = NXOpen.View.Null
    assocOrigin27.PointOnGeometry = NXOpen.Point.Null
    assocOrigin27.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.DimensionLine = 0
    assocOrigin27.AssociatedView = NXOpen.View.Null
    assocOrigin27.AssociatedPoint = NXOpen.Point.Null
    assocOrigin27.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.XOffsetFactor = 0.0
    assocOrigin27.YOffsetFactor = 0.0
    assocOrigin27.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder37.Origin.SetAssociativeOrigin(assocOrigin27)
    
    point90 = NXOpen.Point3d(57.961951486438885, -48.398595102558076, 0.0)
    sketchRapidDimensionBuilder37.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point90)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.TextCentered = False
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject38 = sketchRapidDimensionBuilder37.Commit()
    
    theSession.DeleteUndoMark(markId222, None)
    
    theSession.SetUndoMarkName(markId221, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId221, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder37.Destroy()
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder38 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines181 = []
    sketchRapidDimensionBuilder38.AppendedText.SetBefore(lines181)
    
    lines182 = []
    sketchRapidDimensionBuilder38.AppendedText.SetAfter(lines182)
    
    lines183 = []
    sketchRapidDimensionBuilder38.AppendedText.SetAbove(lines183)
    
    lines184 = []
    sketchRapidDimensionBuilder38.AppendedText.SetBelow(lines184)
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder38.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId223, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder38.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1047 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1048 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1049 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1050 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1051 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1052 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1053 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1054 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1055 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1056 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder38.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1057 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1058 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1059 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1060 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1061 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1062 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1063 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1064 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1065 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1066 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    expression109 = workPart.Expressions.FindObject("p43")
    expression109.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId223, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId224, None)
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId223, "Edit Driving Value")
    
    point91 = NXOpen.Point3d(55.000000000000171, -41.510082931842035, -7.9936057773011271e-14)
    sketchRapidDimensionBuilder38.FirstAssociativity.SetValue(line30, workPart.ModelingViews.WorkView, point91)
    
    point1_132 = NXOpen.Point3d(55.0, -45.0, 0.0)
    point2_132 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder38.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line30, workPart.ModelingViews.WorkView, point1_132, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_132)
    
    point1_133 = NXOpen.Point3d(55.0, -28.999999999999996, 0.0)
    point2_133 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder38.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line30, workPart.ModelingViews.WorkView, point1_133, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_133)
    
    dimensionlinearunits1067 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1068 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1069 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1070 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1071 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1072 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin28 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin28.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin28.View = NXOpen.View.Null
    assocOrigin28.ViewOfGeometry = workPart.ModelingViews.WorkView
    point92 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin28.PointOnGeometry = point92
    assocOrigin28.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.DimensionLine = 0
    assocOrigin28.AssociatedView = NXOpen.View.Null
    assocOrigin28.AssociatedPoint = NXOpen.Point.Null
    assocOrigin28.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.XOffsetFactor = 0.0
    assocOrigin28.YOffsetFactor = 0.0
    assocOrigin28.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder38.Origin.SetAssociativeOrigin(assocOrigin28)
    
    point93 = NXOpen.Point3d(48.394944059519425, -40.395155330227439, 0.0)
    sketchRapidDimensionBuilder38.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point93)
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.TextCentered = False
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject39 = sketchRapidDimensionBuilder38.Commit()
    
    theSession.DeleteUndoMark(markId226, None)
    
    theSession.SetUndoMarkName(markId225, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId225, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder38.Destroy()
    
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder39 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines185 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBefore(lines185)
    
    lines186 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAfter(lines186)
    
    lines187 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAbove(lines187)
    
    lines188 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBelow(lines188)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder39.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId227, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder39.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1073 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1074 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1075 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1076 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1077 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1078 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1079 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1080 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1081 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1082 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder39.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1083 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1084 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1085 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1086 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1087 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1088 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1089 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1090 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1091 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1092 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    expression110 = workPart.Expressions.FindObject("p44")
    expression110.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId227, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId228, None)
    
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId227, "Edit Driving Value")
    
    point94 = NXOpen.Point3d(58.548723713812656, -35.000000000000156, -8.0824236192711396e-14)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(line31, workPart.ModelingViews.WorkView, point94)
    
    point1_134 = NXOpen.Point3d(55.0, -35.0, 0.0)
    point2_134 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line31, workPart.ModelingViews.WorkView, point1_134, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_134)
    
    point1_135 = NXOpen.Point3d(65.0, -35.0, 0.0)
    point2_135 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line31, workPart.ModelingViews.WorkView, point1_135, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_135)
    
    dimensionlinearunits1093 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1094 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1095 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1096 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1097 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1098 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    point1_136 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_136 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line21, workPart.ModelingViews.WorkView, point1_136, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_136)
    
    point1_137 = NXOpen.Point3d(58.548723713812656, -35.000000000000156, -8.0824236192711396e-14)
    point2_137 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line31, workPart.ModelingViews.WorkView, point1_137, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_137)
    
    point1_138 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_138 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line21, workPart.ModelingViews.WorkView, point1_138, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_138)
    
    point1_139 = NXOpen.Point3d(58.548723713812656, -35.000000000000156, -8.0824236192711396e-14)
    point2_139 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line31, workPart.ModelingViews.WorkView, point1_139, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_139)
    
    point1_140 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_140 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line21, workPart.ModelingViews.WorkView, point1_140, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_140)
    
    dimensionlinearunits1099 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1100 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1101 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1102 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1103 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1104 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1105 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1106 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1107 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1108 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1109 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1110 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin29 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin29.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin29.View = NXOpen.View.Null
    assocOrigin29.ViewOfGeometry = workPart.ModelingViews.WorkView
    point95 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin29.PointOnGeometry = point95
    assocOrigin29.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.DimensionLine = 0
    assocOrigin29.AssociatedView = NXOpen.View.Null
    assocOrigin29.AssociatedPoint = NXOpen.Point.Null
    assocOrigin29.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.XOffsetFactor = 0.0
    assocOrigin29.YOffsetFactor = 0.0
    assocOrigin29.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder39.Origin.SetAssociativeOrigin(assocOrigin29)
    
    point96 = NXOpen.Point3d(63.75547318903098, -53.858411384317513, 0.0)
    sketchRapidDimensionBuilder39.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point96)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.TextCentered = False
    
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject40 = sketchRapidDimensionBuilder39.Commit()
    
    theSession.DeleteUndoMark(markId230, None)
    
    theSession.SetUndoMarkName(markId229, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId229, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder39.Destroy()
    
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder40 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines189 = []
    sketchRapidDimensionBuilder40.AppendedText.SetBefore(lines189)
    
    lines190 = []
    sketchRapidDimensionBuilder40.AppendedText.SetAfter(lines190)
    
    lines191 = []
    sketchRapidDimensionBuilder40.AppendedText.SetAbove(lines191)
    
    lines192 = []
    sketchRapidDimensionBuilder40.AppendedText.SetBelow(lines192)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder40.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId231, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder40.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1111 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1112 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1113 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1114 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1115 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1116 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1117 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1118 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1119 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1120 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder40.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1121 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1122 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1123 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1124 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1125 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1126 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1127 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1128 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1129 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1130 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    expression111 = workPart.Expressions.FindObject("p45")
    expression111.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId231, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId232, None)
    
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId231, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder40.Destroy()
    
    theSession.UndoToMark(markId233, None)
    
    theSession.DeleteUndoMark(markId233, None)
    
    sketchRapidDimensionBuilder40.Destroy()
    
    sketch17 = theSession.ActiveSketch
    
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section8
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression112 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies73 = [NXOpen.Body.Null] * 1 
    targetBodies73[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies73)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies74 = [NXOpen.Body.Null] * 1 
    targetBodies74[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies74)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId235, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features7 = [NXOpen.Features.Feature.Null] * 1 
    features7[0] = sketchFeature6
    curveFeatureRule7 = workPart.ScRuleFactory.CreateRuleCurveFeature(features7)
    
    section8.AllowSelfIntersection(True)
    
    rules7 = [None] * 1 
    rules7[0] = curveFeatureRule7
    helpPoint8 = NXOpen.Point3d(55.000000000000078, -52.61355323367615, 7.1054273576010019e-15)
    section8.AddToSection(rules7, line30, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint8, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId237, None)
    
    direction21 = workPart.Directions.CreateDirection(sketch17, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction21
    
    targetBodies75 = [NXOpen.Body.Null] * 1 
    targetBodies75[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies75)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies76 = [NXOpen.Body.Null] * 1 
    targetBodies76[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies76)
    
    expression113 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId236, None)
    
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId238, None)
    
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    feature17 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId239, None)
    
    theSession.SetUndoMarkName(markId235, "Extrude")
    
    expression114 = extrudeBuilder7.Limits.StartExtend.Value
    expression115 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression112)
    
    workPart.Expressions.Delete(expression113)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = -0.036962115530911575
    rotMatrix25.Xy = -0.99729557365834676
    rotMatrix25.Xz = -0.06352433216453196
    rotMatrix25.Yx = -0.82764000382624259
    rotMatrix25.Yy = -0.0050745644946529203
    rotMatrix25.Yz = 0.56123637877608146
    rotMatrix25.Zx = -0.56004091464997363
    rotMatrix25.Zy = 0.073319762388185161
    rotMatrix25.Zz = -0.82521414575936847
    translation25 = NXOpen.Point3d(11.642505140492373, -3.6327229383848625, 25.48052414920496)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 1.4014528799601189)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = -0.025568525800601923
    rotMatrix26.Xy = -0.99753127461377944
    rotMatrix26.Xz = -0.06540341471050054
    rotMatrix26.Yx = 0.17234331595229879
    rotMatrix26.Yy = -0.068843765135054691
    rotMatrix26.Yz = 0.98262827022664001
    rotMatrix26.Zx = -0.98470504819207327
    rotMatrix26.Zy = 0.013852514913879907
    rotMatrix26.Zz = 0.17367808121812783
    translation26 = NXOpen.Point3d(10.958889756673793, -63.63172212509734, 50.960372161730945)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation26, 1.4014528799601189)
    
    rotMatrix27 = NXOpen.Matrix3x3()
    
    rotMatrix27.Xx = 0.071717543434398665
    rotMatrix27.Xy = -0.9946433266904996
    rotMatrix27.Xz = -0.07443955019874901
    rotMatrix27.Yx = -0.069063185850354813
    rotMatrix27.Yy = -0.0794045870180662
    rotMatrix27.Yz = 0.99444717703892793
    rotMatrix27.Zx = -0.99503109012931745
    rotMatrix27.Zy = -0.066178276122510885
    rotMatrix27.Zz = -0.074387938844399953
    translation27 = NXOpen.Point3d(5.1217256025737559, -49.147332016938122, 51.579934677965589)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix27, translation27, 1.4014528799601189)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder13 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal28 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane28 = workPart.Planes.CreatePlane(origin40, normal28, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder13.PlaneReference = plane28
    
    expression116 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression117 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder12 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder12.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId240, "Create Sketch Dialog")
    
    scalar14 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude3 = feature17
    edge18 = extrude3.FindObject("EDGE * 130 * 140 {(55,-50,-10)(55,-53,-10)(55,-56,-10) EXTRUDE(2)}")
    point97 = workPart.Points.CreatePoint(edge18, scalar14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge19 = extrude1.FindObject("EDGE * 160 EXTRUDE(15) 140 {(55,-50,0)(55,-53,0)(55,-56,0) EXTRUDE(2)}")
    direction22 = workPart.Directions.CreateDirection(edge19, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face5 = extrude3.FindObject("FACE 140 {(55,-53,-5) EXTRUDE(2)}")
    xform10 = workPart.Xforms.CreateXformByPlaneXDirPoint(face5, direction22, point97, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem10 = workPart.CoordinateSystems.CreateCoordinateSystem(xform10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder13.Csystem = cartesianCoordinateSystem10
    
    origin41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal29 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane29 = workPart.Planes.CreatePlane(origin41, normal29, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane29.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom26 = [NXOpen.NXObject.Null] * 1 
    geom26[0] = face5
    plane29.SetGeometry(geom26)
    
    plane29.SetFlip(False)
    
    plane29.SetExpression(None)
    
    plane29.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane29.Evaluate()
    
    origin42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal30 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane30 = workPart.Planes.CreatePlane(origin42, normal30, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression118 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression119 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane30.SynchronizeToPlane(plane29)
    
    scalar15 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point98 = workPart.Points.CreatePoint(edge18, scalar15, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane30.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom27 = [NXOpen.NXObject.Null] * 1 
    geom27[0] = face5
    plane30.SetGeometry(geom27)
    
    plane30.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane30.Evaluate()
    
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId241, None)
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject41 = sketchInPlaceBuilder13.Commit()
    
    sketch18 = nXObject41
    feature18 = sketch18.Feature
    
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId243)
    
    sketch18.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId242, None)
    
    theSession.SetUndoMarkName(markId240, "Create Sketch")
    
    sketchInPlaceBuilder13.Destroy()
    
    sketchAlongPathBuilder12.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression117)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point98)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression116)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane28.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression119)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression118)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane30.DestroyPlane()
    
    scaleAboutPoint100 = NXOpen.Point3d(-5.0973886472752632, -3.2094669260622277, 0.0)
    viewCenter100 = NXOpen.Point3d(5.09738864727536, 3.2094669260622277, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-4.0779109178201978, -2.5675735408497822, 0.0)
    viewCenter101 = NXOpen.Point3d(4.0779109178203008, 2.5675735408497822, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-3.2623287342561165, -2.0540588326798357, 0.0)
    viewCenter102 = NXOpen.Point3d(3.2623287342562608, 2.0540588326798153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-1.6432470661437946, -0.48330796063055353, 0.0)
    viewCenter103 = NXOpen.Point3d(1.6432470661439347, 0.48330796063053705, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint103, viewCenter103)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId245 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId245, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(55.0, -52.0, -3.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 0.73251380590054704, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_19 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_19.Geometry = arc3
    dimObject1_19.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_19.AssocValue = 0
    dimObject1_19.HelpPoint.X = 0.0
    dimObject1_19.HelpPoint.Y = 0.0
    dimObject1_19.HelpPoint.Z = 0.0
    dimObject1_19.View = NXOpen.NXObject.Null
    dimOrigin19 = NXOpen.Point3d(55.0, -52.0, -2.1231956367773366)
    sketchDimensionalConstraint19 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_19, dimOrigin19, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension19 = sketchDimensionalConstraint19.AssociatedDimension
    
    expression120 = sketchDimensionalConstraint19.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    scaleAboutPoint104 = NXOpen.Point3d(-1.6239147477185754, 9.5115006652091783, 0.0)
    viewCenter104 = NXOpen.Point3d(1.6239147477187204, -9.5115006652091907, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-1.2991317981748445, 7.6092005321673426, 0.0)
    viewCenter105 = NXOpen.Point3d(1.2991317981749817, -7.6092005321673586, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-1.0393054385398586, 6.0873604257338689, 0.0)
    viewCenter106 = NXOpen.Point3d(1.0393054385399978, -6.0873604257338858, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(0.1187777644046242, 5.3449993982053474, 0.0)
    viewCenter107 = NXOpen.Point3d(-0.11877776440449592, -5.3449993982053616, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint107, viewCenter107)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId246 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder41 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines193 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBefore(lines193)
    
    lines194 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAfter(lines194)
    
    lines195 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAbove(lines195)
    
    lines196 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBelow(lines196)
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder41.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines197 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBefore(lines197)
    
    lines198 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAfter(lines198)
    
    lines199 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAbove(lines199)
    
    lines200 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBelow(lines200)
    
    theSession.SetUndoMarkName(markId246, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder41.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1131 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1132 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1133 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1134 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1135 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1136 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1137 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1138 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1139 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1140 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder41.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1141 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1142 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1143 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1144 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1145 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1146 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1147 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1148 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1149 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1150 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    point1_141 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_141 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_141, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_141)
    
    point1_142 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_142 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_142, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_142)
    
    point1_143 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_143 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_143, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_143)
    
    dimensionlinearunits1151 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1152 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1153 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1154 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1155 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1156 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    point99 = NXOpen.Point3d(55.0, -52.09836937781629, -10.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(edge18, workPart.ModelingViews.WorkView, point99)
    
    point1_144 = NXOpen.Point3d(55.0, -52.09836937781629, -10.0)
    point2_144 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge18, workPart.ModelingViews.WorkView, point1_144, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_144)
    
    point1_145 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_145 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_145, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_145)
    
    point1_146 = NXOpen.Point3d(55.0, -52.09836937781629, -10.0)
    point2_146 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge18, workPart.ModelingViews.WorkView, point1_146, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_146)
    
    point1_147 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_147 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_147, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_147)
    
    dimensionlinearunits1157 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1158 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1159 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1160 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1161 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1162 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1163 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1164 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1165 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1166 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1167 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1168 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    dimensionlinearunits1169 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1170 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1171 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1172 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1173 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1174 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder41.Destroy()
    
    marksRecycled18, undoUnavailable18 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId247 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder42 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines201 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBefore(lines201)
    
    lines202 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAfter(lines202)
    
    lines203 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAbove(lines203)
    
    lines204 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBelow(lines204)
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder42.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines205 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBefore(lines205)
    
    lines206 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAfter(lines206)
    
    lines207 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAbove(lines207)
    
    lines208 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBelow(lines208)
    
    theSession.SetUndoMarkName(markId247, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder42.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1175 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1176 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1177 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1178 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1179 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1180 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1181 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1182 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1183 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1184 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder42.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder42.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1185 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1186 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1187 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1188 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1189 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1190 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1191 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1192 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1193 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1194 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    point1_148 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_148 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_148, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_148)
    
    point1_149 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_149 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_149, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_149)
    
    point1_150 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_150 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_150, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_150)
    
    dimensionlinearunits1195 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1196 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1197 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1198 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1199 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1200 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    edge20 = extrude3.FindObject("EDGE * 140 * 150 {(55,-56,-10)(55,-56,-5)(55,-56,0) EXTRUDE(2)}")
    point100 = NXOpen.Point3d(55.0, -56.0, -2.468121491914133)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(edge20, workPart.ModelingViews.WorkView, point100)
    
    point1_151 = NXOpen.Point3d(55.0, -56.0, -2.468121491914133)
    point2_151 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge20, workPart.ModelingViews.WorkView, point1_151, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_151)
    
    point1_152 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_152 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_152, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_152)
    
    point1_153 = NXOpen.Point3d(55.0, -56.0, -2.468121491914133)
    point2_153 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge20, workPart.ModelingViews.WorkView, point1_153, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_153)
    
    point1_154 = NXOpen.Point3d(55.0, -52.0, -3.0)
    point2_154 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder42.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_154, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_154)
    
    dimensionlinearunits1201 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1202 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1203 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1204 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1205 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1206 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1207 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1208 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1209 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1210 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1211 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1212 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin30 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin30.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin30.View = NXOpen.View.Null
    assocOrigin30.ViewOfGeometry = workPart.ModelingViews.WorkView
    point101 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin30.PointOnGeometry = point101
    assocOrigin30.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin30.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin30.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.DimensionLine = 0
    assocOrigin30.AssociatedView = NXOpen.View.Null
    assocOrigin30.AssociatedPoint = NXOpen.Point.Null
    assocOrigin30.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin30.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin30.XOffsetFactor = 0.0
    assocOrigin30.YOffsetFactor = 0.0
    assocOrigin30.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder42.Origin.SetAssociativeOrigin(assocOrigin30)
    
    point102 = NXOpen.Point3d(55.0, -54.315554313368146, -2.8798844085166189)
    sketchRapidDimensionBuilder42.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point102)
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder42.Style.DimensionStyle.TextCentered = True
    
    markId248 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject42 = sketchRapidDimensionBuilder42.Commit()
    
    theSession.DeleteUndoMark(markId248, None)
    
    theSession.SetUndoMarkName(markId247, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId247, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder42.Destroy()
    
    markId249 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder43 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines209 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBefore(lines209)
    
    lines210 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAfter(lines210)
    
    lines211 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAbove(lines211)
    
    lines212 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBelow(lines212)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder43.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId249, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder43.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1213 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1214 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1215 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1216 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1217 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1218 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1219 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1220 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1221 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1222 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder43.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1223 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1224 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1225 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1226 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1227 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1228 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1229 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1230 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1231 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1232 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    expression121 = workPart.Expressions.FindObject("p48")
    expression121.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId249, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId250 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId250, None)
    
    markId251 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId249, "Edit Driving Value")
    
    point1_155 = NXOpen.Point3d(55.0, -53.0, -3.0)
    point2_155 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_155, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_155)
    
    point1_156 = NXOpen.Point3d(55.0, -53.0, -3.0)
    point2_156 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_156, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_156)
    
    point1_157 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_157 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_157, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_157)
    
    dimensionlinearunits1233 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1234 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1235 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1236 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1237 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1238 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    point103 = NXOpen.Point3d(55.0, -52.478458223910899, -10.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(edge18, workPart.ModelingViews.WorkView, point103)
    
    point1_158 = NXOpen.Point3d(55.0, -52.478458223910899, -10.0)
    point2_158 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge18, workPart.ModelingViews.WorkView, point1_158, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_158)
    
    point1_159 = NXOpen.Point3d(55.0, -53.0, -3.0)
    point2_159 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_159, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_159)
    
    point1_160 = NXOpen.Point3d(55.0, -52.478458223910899, -10.0)
    point2_160 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge18, workPart.ModelingViews.WorkView, point1_160, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_160)
    
    point1_161 = NXOpen.Point3d(55.0, -53.0, -3.0)
    point2_161 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_161, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_161)
    
    dimensionlinearunits1239 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1240 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1241 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1242 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1243 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1244 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1245 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1246 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1247 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1248 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1249 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1250 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin31 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin31.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin31.View = NXOpen.View.Null
    assocOrigin31.ViewOfGeometry = workPart.ModelingViews.WorkView
    point104 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin31.PointOnGeometry = point104
    assocOrigin31.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin31.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin31.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.DimensionLine = 0
    assocOrigin31.AssociatedView = NXOpen.View.Null
    assocOrigin31.AssociatedPoint = NXOpen.Point.Null
    assocOrigin31.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin31.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin31.XOffsetFactor = 0.0
    assocOrigin31.YOffsetFactor = 0.0
    assocOrigin31.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder43.Origin.SetAssociativeOrigin(assocOrigin31)
    
    point105 = NXOpen.Point3d(55.0, -51.718280531721689, -7.5993209141912716)
    sketchRapidDimensionBuilder43.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point105)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.TextCentered = False
    
    markId252 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject43 = sketchRapidDimensionBuilder43.Commit()
    
    theSession.DeleteUndoMark(markId252, None)
    
    theSession.SetUndoMarkName(markId251, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId251, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder43.Destroy()
    
    markId253 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder44 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines213 = []
    sketchRapidDimensionBuilder44.AppendedText.SetBefore(lines213)
    
    lines214 = []
    sketchRapidDimensionBuilder44.AppendedText.SetAfter(lines214)
    
    lines215 = []
    sketchRapidDimensionBuilder44.AppendedText.SetAbove(lines215)
    
    lines216 = []
    sketchRapidDimensionBuilder44.AppendedText.SetBelow(lines216)
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder44.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId253, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder44.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1251 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1252 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1253 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1254 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1255 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1256 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1257 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1258 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1259 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1260 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder44.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1261 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1262 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1263 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1264 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1265 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1266 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1267 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1268 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1269 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1270 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    expression122 = workPart.Expressions.FindObject("p49")
    expression122.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId253, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId254 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId254, None)
    
    markId255 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId253, "Edit Driving Value")
    
    point1_162 = NXOpen.Point3d(55.0, -53.0, -6.0)
    point2_162 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder44.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_162, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_162)
    
    point1_163 = NXOpen.Point3d(55.0, -53.0, -6.0)
    point2_163 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder44.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_163, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_163)
    
    point1_164 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_164 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder44.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_164, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_164)
    
    dimensionlinearunits1271 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1272 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1273 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1274 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1275 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1276 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin32 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin32.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin32.View = NXOpen.View.Null
    assocOrigin32.ViewOfGeometry = workPart.ModelingViews.WorkView
    point106 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin32.PointOnGeometry = point106
    assocOrigin32.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin32.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin32.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin32.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin32.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin32.DimensionLine = 0
    assocOrigin32.AssociatedView = NXOpen.View.Null
    assocOrigin32.AssociatedPoint = NXOpen.Point.Null
    assocOrigin32.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin32.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin32.XOffsetFactor = 0.0
    assocOrigin32.YOffsetFactor = 0.0
    assocOrigin32.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder44.Origin.SetAssociativeOrigin(assocOrigin32)
    
    point107 = NXOpen.Point3d(55.0, -54.252206172352373, -4.4002397928950305)
    sketchRapidDimensionBuilder44.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point107)
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.TextCentered = False
    
    markId256 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject44 = sketchRapidDimensionBuilder44.Commit()
    
    theSession.DeleteUndoMark(markId256, None)
    
    theSession.SetUndoMarkName(markId255, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId255, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder44.Destroy()
    
    markId257 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder45 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines217 = []
    sketchRapidDimensionBuilder45.AppendedText.SetBefore(lines217)
    
    lines218 = []
    sketchRapidDimensionBuilder45.AppendedText.SetAfter(lines218)
    
    lines219 = []
    sketchRapidDimensionBuilder45.AppendedText.SetAbove(lines219)
    
    lines220 = []
    sketchRapidDimensionBuilder45.AppendedText.SetBelow(lines220)
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder45.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder45.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder45.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder45.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId257, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder45.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1277 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1278 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1279 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1280 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1281 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1282 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1283 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1284 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1285 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1286 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder45.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder45.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder45.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder45.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1287 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1288 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1289 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1290 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1291 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1292 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1293 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1294 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1295 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1296 = sketchRapidDimensionBuilder45.Style.UnitsStyle.DimensionLinearUnits
    
    expression123 = workPart.Expressions.FindObject("p50")
    expression123.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId257, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId258 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId258, None)
    
    markId259 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId257, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder45.Destroy()
    
    theSession.UndoToMark(markId259, None)
    
    theSession.DeleteUndoMark(markId259, None)
    
    sketchRapidDimensionBuilder45.Destroy()
    
    sketch19 = theSession.ActiveSketch
    
    markId260 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    scaleAboutPoint108 = NXOpen.Point3d(72.11860975033963, -57.392820324877569, 0.0)
    viewCenter108 = NXOpen.Point3d(-72.11860975033953, 57.392820324877569, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(19.351197642434144, -8.4956477454588537, 0.0)
    viewCenter109 = NXOpen.Point3d(-19.351197642433963, 8.4956477454588537, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(15.292165941826019, -6.7965181963670833, 0.0)
    viewCenter110 = NXOpen.Point3d(-15.292165941825857, 6.7965181963670833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(37.305333211170513, -19.785419638313048, 0.0)
    viewCenter111 = NXOpen.Point3d(-37.305333211170336, 19.785419638313058, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(57.015235980635069, -32.661045776986242, 0.0)
    viewCenter112 = NXOpen.Point3d(-57.015235980634856, 32.661045776986271, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(88.024350251559923, -68.201172178822432, 0.0)
    viewCenter113 = NXOpen.Point3d(-88.024350251559653, 68.201172178822475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint113, viewCenter113)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId261 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section9
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression124 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies77 = [NXOpen.Body.Null] * 1 
    targetBodies77[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies77)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies78 = [NXOpen.Body.Null] * 1 
    targetBodies78[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies78)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId261, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId262 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId263 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features8 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature7 = feature18
    features8[0] = sketchFeature7
    curveFeatureRule8 = workPart.ScRuleFactory.CreateRuleCurveFeature(features8)
    
    section9.AllowSelfIntersection(True)
    
    rules8 = [None] * 1 
    rules8[0] = curveFeatureRule8
    helpPoint9 = NXOpen.Point3d(55.0, -51.523624950389738, -5.8636230592518341)
    section9.AddToSection(rules8, arc3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint9, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId263, None)
    
    direction23 = workPart.Directions.CreateDirection(sketch19, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction23
    
    targetBodies79 = [NXOpen.Body.Null] * 1 
    targetBodies79[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies79)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies80 = [NXOpen.Body.Null] * 1 
    targetBodies80[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies80)
    
    expression125 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId262, None)
    
    scaleAboutPoint114 = NXOpen.Point3d(129.49963056445975, -96.75598821217028, 0.0)
    viewCenter114 = NXOpen.Point3d(-129.49963056445949, 96.755988212170308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(103.59970445156779, -77.404790569736178, 0.0)
    viewCenter115 = NXOpen.Point3d(-103.59970445156755, 77.404790569736221, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(82.879763561254251, -61.92383245578894, 0.0)
    viewCenter116 = NXOpen.Point3d(-82.879763561253966, 61.923832455788975, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(59.507292652636387, -49.841133440025267, 0.0)
    viewCenter117 = NXOpen.Point3d(-59.507292652636075, 49.841133440025274, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(47.485007131951477, -39.872906752020199, 0.0)
    viewCenter118 = NXOpen.Point3d(-47.485007131951164, 39.872906752020221, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(37.988005705561221, -31.898325401616166, 0.0)
    viewCenter119 = NXOpen.Point3d(-37.988005705560944, 31.898325401616184, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(24.745367584284178, -23.585428478770734, 0.0)
    viewCenter120 = NXOpen.Point3d(-24.745367584283901, 23.585428478770741, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(19.672567229505979, -18.868342783016594, 0.0)
    viewCenter121 = NXOpen.Point3d(-19.672567229505685, 18.868342783016598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint121, viewCenter121)
    
    direction24 = extrudeBuilder8.Direction
    
    success4 = direction24.ReverseDirection()
    
    extrudeBuilder8.Direction = direction24
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies81 = [NXOpen.Body.Null] * 1 
    targetBodies81[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies81)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies82 = [NXOpen.Body.Null] * 1 
    targetBodies82[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies82)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies83 = [NXOpen.Body.Null] * 1 
    targetBodies83[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies83)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies84 = [NXOpen.Body.Null] * 1 
    targetBodies84[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies84)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies85 = [NXOpen.Body.Null] * 1 
    targetBodies85[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies85)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies86 = [NXOpen.Body.Null] * 1 
    targetBodies86[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies86)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies87 = [NXOpen.Body.Null] * 1 
    targetBodies87[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies87)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies88 = [NXOpen.Body.Null] * 1 
    targetBodies88[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies88)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies89 = [NXOpen.Body.Null] * 1 
    targetBodies89[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies89)
    
    markId264 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId264, None)
    
    markId265 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    feature19 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId265, None)
    
    theSession.SetUndoMarkName(markId261, "Extrude")
    
    expression126 = extrudeBuilder8.Limits.StartExtend.Value
    expression127 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression124)
    
    workPart.Expressions.Delete(expression125)
    
    scaleAboutPoint122 = NXOpen.Point3d(20.786108770798766, -12.966572614164843, 0.0)
    viewCenter122 = NXOpen.Point3d(-20.786108770798471, 12.966572614164852, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(25.982635963498392, -16.455669443548892, 0.0)
    viewCenter123 = NXOpen.Point3d(-25.982635963498108, 16.455669443548896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(34.25686824949338, -23.972074847275177, 0.0)
    viewCenter124 = NXOpen.Point3d(-34.256868249493088, 23.972074847275184, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint124, viewCenter124)
    
    rotMatrix28 = NXOpen.Matrix3x3()
    
    rotMatrix28.Xx = 0.93296689483244333
    rotMatrix28.Xy = 0.00064085844892093971
    rotMatrix28.Xz = 0.3599616124632794
    rotMatrix28.Yx = -0.35143116207509456
    rotMatrix28.Yy = -0.21479857934196486
    rotMatrix28.Yz = 0.91123965488516323
    rotMatrix28.Zx = 0.077903218606579019
    rotMatrix28.Zy = -0.97665815903678765
    rotMatrix28.Zz = -0.2001747459536623
    translation28 = NXOpen.Point3d(-70.685090430031167, -6.9753643424567624, -12.796123846188198)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix28, translation28, 2.7372126561721077)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId266 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId267 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    theSession.UndoToMark(markId267, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId267, "Create Rectangle")
    
    markId268 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder14 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal31 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane31 = workPart.Planes.CreatePlane(origin43, normal31, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder14.PlaneReference = plane31
    
    expression128 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression129 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder13 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder13.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId268, "Create Sketch Dialog")
    
    scalar16 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge21 = extrude1.FindObject("EDGE * 160 EXTRUDE(15) 150 {(55,-56,0)(60,-56,0)(65,-56,0) EXTRUDE(2)}")
    point108 = workPart.Points.CreatePoint(edge21, scalar16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction25 = workPart.Directions.CreateDirection(edge21, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face6 = extrude3.FindObject("FACE 150 {(60,-56,-5) EXTRUDE(2)}")
    xform11 = workPart.Xforms.CreateXformByPlaneXDirPoint(face6, direction25, point108, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem11 = workPart.CoordinateSystems.CreateCoordinateSystem(xform11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder14.Csystem = cartesianCoordinateSystem11
    
    origin44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal32 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane32 = workPart.Planes.CreatePlane(origin44, normal32, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane32.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom28 = [NXOpen.NXObject.Null] * 1 
    geom28[0] = face6
    plane32.SetGeometry(geom28)
    
    plane32.SetFlip(False)
    
    plane32.SetExpression(None)
    
    plane32.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane32.Evaluate()
    
    origin45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal33 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane33 = workPart.Planes.CreatePlane(origin45, normal33, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression130 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression131 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane33.SynchronizeToPlane(plane32)
    
    scalar17 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point109 = workPart.Points.CreatePoint(edge21, scalar17, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane33.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom29 = [NXOpen.NXObject.Null] * 1 
    geom29[0] = face6
    plane33.SetGeometry(geom29)
    
    plane33.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane33.Evaluate()
    
    markId269 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId269, None)
    
    markId270 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject45 = sketchInPlaceBuilder14.Commit()
    
    sketch20 = nXObject45
    feature20 = sketch20.Feature
    
    markId271 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs11 = theSession.UpdateManager.DoUpdate(markId271)
    
    sketch20.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId270, None)
    
    theSession.SetUndoMarkName(markId268, "Create Sketch")
    
    sketchInPlaceBuilder14.Destroy()
    
    sketchAlongPathBuilder13.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression129)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point109)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression128)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane31.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression131)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression130)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane33.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId272 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId273 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId273, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint34 = NXOpen.Point3d(57.706524579531184, -56.0, 0.0)
    endPoint34 = NXOpen.Point3d(63.022912146467206, -56.0, 0.0)
    line34 = workPart.Curves.CreateLine(startPoint34, endPoint34)
    
    startPoint35 = NXOpen.Point3d(63.022912146467206, -56.0, 0.0)
    endPoint35 = NXOpen.Point3d(63.022912146467206, -56.0, -10.0)
    line35 = workPart.Curves.CreateLine(startPoint35, endPoint35)
    
    startPoint36 = NXOpen.Point3d(63.022912146467206, -56.0, -10.0)
    endPoint36 = NXOpen.Point3d(57.706524579531184, -56.0, -10.0)
    line36 = workPart.Curves.CreateLine(startPoint36, endPoint36)
    
    startPoint37 = NXOpen.Point3d(57.706524579531184, -56.0, -10.0)
    endPoint37 = NXOpen.Point3d(57.706524579531184, -56.0, 0.0)
    line37 = workPart.Curves.CreateLine(startPoint37, endPoint37)
    
    theSession.ActiveSketch.AddGeometry(line34, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line35, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line36, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line37, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_36 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_36.Geometry = line34
    geom1_36.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_36.SplineDefiningPointIndex = 0
    geom2_36 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_36.Geometry = line35
    geom2_36.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_36.SplineDefiningPointIndex = 0
    sketchGeometricConstraint77 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_36, geom2_36)
    
    geom1_37 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_37.Geometry = line35
    geom1_37.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_37.SplineDefiningPointIndex = 0
    geom2_37 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_37.Geometry = line36
    geom2_37.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_37.SplineDefiningPointIndex = 0
    sketchGeometricConstraint78 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_37, geom2_37)
    
    geom1_38 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_38.Geometry = line36
    geom1_38.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_38.SplineDefiningPointIndex = 0
    geom2_38 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_38.Geometry = line37
    geom2_38.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_38.SplineDefiningPointIndex = 0
    sketchGeometricConstraint79 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_38, geom2_38)
    
    geom1_39 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_39.Geometry = line37
    geom1_39.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_39.SplineDefiningPointIndex = 0
    geom2_39 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_39.Geometry = line34
    geom2_39.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_39.SplineDefiningPointIndex = 0
    sketchGeometricConstraint80 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_39, geom2_39)
    
    geom30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom30.Geometry = line34
    geom30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint81 = theSession.ActiveSketch.CreateHorizontalConstraint(geom30)
    
    conGeom1_38 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_38.Geometry = line34
    conGeom1_38.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_38.SplineDefiningPointIndex = 0
    conGeom2_38 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_38.Geometry = line35
    conGeom2_38.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_38.SplineDefiningPointIndex = 0
    sketchGeometricConstraint82 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_38, conGeom2_38)
    
    conGeom1_39 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_39.Geometry = line35
    conGeom1_39.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_39.SplineDefiningPointIndex = 0
    conGeom2_39 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_39.Geometry = line36
    conGeom2_39.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_39.SplineDefiningPointIndex = 0
    sketchGeometricConstraint83 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_39, conGeom2_39)
    
    conGeom1_40 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_40.Geometry = line36
    conGeom1_40.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_40.SplineDefiningPointIndex = 0
    conGeom2_40 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_40.Geometry = line37
    conGeom2_40.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_40.SplineDefiningPointIndex = 0
    sketchGeometricConstraint84 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_40, conGeom2_40)
    
    conGeom1_41 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_41.Geometry = line37
    conGeom1_41.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_41.SplineDefiningPointIndex = 0
    conGeom2_41 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_41.Geometry = line34
    conGeom2_41.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_41.SplineDefiningPointIndex = 0
    sketchGeometricConstraint85 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_41, conGeom2_41)
    
    conGeom1_42 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_42.Geometry = line34
    conGeom1_42.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_42.SplineDefiningPointIndex = 0
    conGeom2_42 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_42.Geometry = edge6
    conGeom2_42.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_42.SplineDefiningPointIndex = 0
    help6 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help6.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help6.Point.X = 57.706524579531184
    help6.Point.Y = -56.0
    help6.Point.Z = 0.0
    help6.Parameter = 0.0
    sketchHelpedGeometricConstraint6 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_42, conGeom2_42, help6)
    
    conGeom1_43 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_43.Geometry = line36
    conGeom1_43.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_43.SplineDefiningPointIndex = 0
    conGeom2_43 = NXOpen.Sketch.ConstraintGeometry()
    
    edge22 = extrude3.FindObject("EDGE * 130 * 150 {(55,-56,-10)(60,-56,-10)(65,-56,-10) EXTRUDE(2)}")
    conGeom2_43.Geometry = edge22
    conGeom2_43.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_43.SplineDefiningPointIndex = 0
    help7 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help7.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help7.Point.X = 63.022912146467206
    help7.Point.Y = -56.0
    help7.Point.Z = -10.0
    help7.Parameter = 0.0
    sketchHelpedGeometricConstraint7 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_43, conGeom2_43, help7)
    
    dimObject1_20 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_20.Geometry = line35
    dimObject1_20.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_20.AssocValue = 0
    dimObject1_20.HelpPoint.X = 0.0
    dimObject1_20.HelpPoint.Y = 0.0
    dimObject1_20.HelpPoint.Z = 0.0
    dimObject1_20.View = NXOpen.NXObject.Null
    dimObject2_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_17.Geometry = line35
    dimObject2_17.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_17.AssocValue = 0
    dimObject2_17.HelpPoint.X = 0.0
    dimObject2_17.HelpPoint.Y = 0.0
    dimObject2_17.HelpPoint.Z = 0.0
    dimObject2_17.View = NXOpen.NXObject.Null
    dimOrigin20 = NXOpen.Point3d(59.734895784382218, -56.0, -5.0)
    sketchDimensionalConstraint20 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_20, dimObject2_17, dimOrigin20, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint17 = sketchDimensionalConstraint20
    dimension20 = sketchHelpedDimensionalConstraint17.AssociatedDimension
    
    expression132 = sketchHelpedDimensionalConstraint17.AssociatedExpression
    
    dimObject1_21 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_21.Geometry = line34
    dimObject1_21.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_21.AssocValue = 0
    dimObject1_21.HelpPoint.X = 0.0
    dimObject1_21.HelpPoint.Y = 0.0
    dimObject1_21.HelpPoint.Z = 0.0
    dimObject1_21.View = NXOpen.NXObject.Null
    dimObject2_18 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_18.Geometry = line34
    dimObject2_18.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_18.AssocValue = 0
    dimObject2_18.HelpPoint.X = 0.0
    dimObject2_18.HelpPoint.Y = 0.0
    dimObject2_18.HelpPoint.Z = 0.0
    dimObject2_18.View = NXOpen.NXObject.Null
    dimOrigin21 = NXOpen.Point3d(60.364718362999199, -56.0, -3.2880163620849876)
    sketchDimensionalConstraint21 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_21, dimObject2_18, dimOrigin21, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint18 = sketchDimensionalConstraint21
    dimension21 = sketchHelpedDimensionalConstraint18.AssociatedDimension
    
    expression133 = sketchHelpedDimensionalConstraint18.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms17 = [NXOpen.SmartObject.Null] * 4 
    geoms17[0] = line34
    geoms17[1] = line35
    geoms17[2] = line36
    geoms17[3] = line37
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms17)
    
    geoms18 = [NXOpen.SmartObject.Null] * 4 
    geoms18[0] = line34
    geoms18[1] = line35
    geoms18[2] = line36
    geoms18[3] = line37
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms18)
    
    markId274 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId274, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId275 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder46 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines221 = []
    sketchRapidDimensionBuilder46.AppendedText.SetBefore(lines221)
    
    lines222 = []
    sketchRapidDimensionBuilder46.AppendedText.SetAfter(lines222)
    
    lines223 = []
    sketchRapidDimensionBuilder46.AppendedText.SetAbove(lines223)
    
    lines224 = []
    sketchRapidDimensionBuilder46.AppendedText.SetBelow(lines224)
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder46.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines225 = []
    sketchRapidDimensionBuilder46.AppendedText.SetBefore(lines225)
    
    lines226 = []
    sketchRapidDimensionBuilder46.AppendedText.SetAfter(lines226)
    
    lines227 = []
    sketchRapidDimensionBuilder46.AppendedText.SetAbove(lines227)
    
    lines228 = []
    sketchRapidDimensionBuilder46.AppendedText.SetBelow(lines228)
    
    theSession.SetUndoMarkName(markId275, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder46.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1297 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1298 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1299 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1300 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1301 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1302 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1303 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1304 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1305 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1306 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder46.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder46.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1307 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1308 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1309 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1310 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1311 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1312 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1313 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1314 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1315 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1316 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint125 = NXOpen.Point3d(9.0861896598544352, -4.9297411984315893, 0.0)
    viewCenter125 = NXOpen.Point3d(-9.0861896598541563, 4.9297411984315893, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(7.2689517278835822, -4.0211222324461477, 0.0)
    viewCenter126 = NXOpen.Point3d(-7.2689517278832918, 4.0211222324461549, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(5.8151613823068962, -3.2168977859569177, 0.0)
    viewCenter127 = NXOpen.Point3d(-5.8151613823066111, 3.2168977859569283, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    point110 = NXOpen.Point3d(63.022912146467206, -56.0, -2.1366078323555109)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(line35, workPart.ModelingViews.WorkView, point110)
    
    point1_165 = NXOpen.Point3d(63.022912146467206, -56.0, 0.0)
    point2_165 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line35, workPart.ModelingViews.WorkView, point1_165, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_165)
    
    point1_166 = NXOpen.Point3d(63.022912146467206, -56.0, -10.0)
    point2_166 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line35, workPart.ModelingViews.WorkView, point1_166, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_166)
    
    dimensionlinearunits1317 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1318 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1319 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1320 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1321 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1322 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    edge23 = extrude3.FindObject("EDGE * 150 * 160 {(65,-56,-10)(65,-56,-5)(65,-56,0) EXTRUDE(2)}")
    point1_167 = NXOpen.Point3d(64.999999999999986, -56.0, 0.0)
    point2_167 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge23, workPart.ModelingViews.WorkView, point1_167, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_167)
    
    point1_168 = NXOpen.Point3d(63.022912146467206, -56.0, -2.1366078323555109)
    point2_168 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line35, workPart.ModelingViews.WorkView, point1_168, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_168)
    
    point1_169 = NXOpen.Point3d(64.999999999999986, -56.0, 0.0)
    point2_169 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge23, workPart.ModelingViews.WorkView, point1_169, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_169)
    
    point1_170 = NXOpen.Point3d(63.022912146467206, -56.0, -2.1366078323555109)
    point2_170 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line35, workPart.ModelingViews.WorkView, point1_170, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_170)
    
    point1_171 = NXOpen.Point3d(64.999999999999986, -56.0, 0.0)
    point2_171 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder46.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge23, workPart.ModelingViews.WorkView, point1_171, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_171)
    
    dimensionlinearunits1323 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1324 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1325 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1326 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1327 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1328 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1329 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1330 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1331 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1332 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1333 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1334 = sketchRapidDimensionBuilder46.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin33 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin33.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin33.View = NXOpen.View.Null
    assocOrigin33.ViewOfGeometry = workPart.ModelingViews.WorkView
    point111 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin33.PointOnGeometry = point111
    assocOrigin33.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin33.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin33.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin33.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin33.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin33.DimensionLine = 0
    assocOrigin33.AssociatedView = NXOpen.View.Null
    assocOrigin33.AssociatedPoint = NXOpen.Point.Null
    assocOrigin33.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin33.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin33.XOffsetFactor = 0.0
    assocOrigin33.YOffsetFactor = 0.0
    assocOrigin33.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder46.Origin.SetAssociativeOrigin(assocOrigin33)
    
    point112 = NXOpen.Point3d(64.432624806034426, -56.0, -13.024569569440493)
    sketchRapidDimensionBuilder46.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point112)
    
    sketchRapidDimensionBuilder46.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder46.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder46.Style.DimensionStyle.TextCentered = False
    
    markId276 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject46 = sketchRapidDimensionBuilder46.Commit()
    
    theSession.DeleteUndoMark(markId276, None)
    
    theSession.SetUndoMarkName(markId275, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId275, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder46.Destroy()
    
    markId277 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder47 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines229 = []
    sketchRapidDimensionBuilder47.AppendedText.SetBefore(lines229)
    
    lines230 = []
    sketchRapidDimensionBuilder47.AppendedText.SetAfter(lines230)
    
    lines231 = []
    sketchRapidDimensionBuilder47.AppendedText.SetAbove(lines231)
    
    lines232 = []
    sketchRapidDimensionBuilder47.AppendedText.SetBelow(lines232)
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder47.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId277, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder47.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1335 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1336 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1337 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1338 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1339 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1340 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1341 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1342 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1343 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1344 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder47.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1345 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1346 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1347 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1348 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1349 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1350 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1351 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1352 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1353 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1354 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    expression134 = workPart.Expressions.FindObject("p53")
    expression134.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId277, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId278 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId278, None)
    
    markId279 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId277, "Edit Driving Value")
    
    point113 = NXOpen.Point3d(57.683612433063963, -56.0, -6.1948481161780933)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(line37, workPart.ModelingViews.WorkView, point113)
    
    point1_172 = NXOpen.Point3d(57.683612433063963, -56.0, -10.0)
    point2_172 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line37, workPart.ModelingViews.WorkView, point1_172, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_172)
    
    point1_173 = NXOpen.Point3d(57.683612433063963, -56.0, 0.0)
    point2_173 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line37, workPart.ModelingViews.WorkView, point1_173, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_173)
    
    dimensionlinearunits1355 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1356 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1357 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1358 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1359 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1360 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    point1_174 = NXOpen.Point3d(55.0, -56.0, -5.0)
    point2_174 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge20, workPart.ModelingViews.WorkView, point1_174, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_174)
    
    point1_175 = NXOpen.Point3d(57.683612433063963, -56.0, -6.1948481161780933)
    point2_175 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line37, workPart.ModelingViews.WorkView, point1_175, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_175)
    
    point1_176 = NXOpen.Point3d(55.0, -56.0, -5.0)
    point2_176 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge20, workPart.ModelingViews.WorkView, point1_176, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_176)
    
    point1_177 = NXOpen.Point3d(57.683612433063963, -56.0, -6.1948481161780933)
    point2_177 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line37, workPart.ModelingViews.WorkView, point1_177, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_177)
    
    point1_178 = NXOpen.Point3d(55.0, -56.0, -5.0)
    point2_178 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder47.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge20, workPart.ModelingViews.WorkView, point1_178, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_178)
    
    dimensionlinearunits1361 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1362 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1363 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1364 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1365 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1366 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1367 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1368 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1369 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1370 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1371 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1372 = sketchRapidDimensionBuilder47.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin34 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin34.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin34.View = NXOpen.View.Null
    assocOrigin34.ViewOfGeometry = workPart.ModelingViews.WorkView
    point114 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin34.PointOnGeometry = point114
    assocOrigin34.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin34.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin34.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin34.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin34.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin34.DimensionLine = 0
    assocOrigin34.AssociatedView = NXOpen.View.Null
    assocOrigin34.AssociatedPoint = NXOpen.Point.Null
    assocOrigin34.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin34.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin34.XOffsetFactor = 0.0
    assocOrigin34.YOffsetFactor = 0.0
    assocOrigin34.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder47.Origin.SetAssociativeOrigin(assocOrigin34)
    
    point115 = NXOpen.Point3d(55.771746151535005, -56.0, -6.4423017920209364)
    sketchRapidDimensionBuilder47.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point115)
    
    sketchRapidDimensionBuilder47.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder47.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder47.Style.DimensionStyle.TextCentered = False
    
    markId280 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject47 = sketchRapidDimensionBuilder47.Commit()
    
    theSession.DeleteUndoMark(markId280, None)
    
    theSession.SetUndoMarkName(markId279, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId279, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder47.Destroy()
    
    markId281 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder48 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines233 = []
    sketchRapidDimensionBuilder48.AppendedText.SetBefore(lines233)
    
    lines234 = []
    sketchRapidDimensionBuilder48.AppendedText.SetAfter(lines234)
    
    lines235 = []
    sketchRapidDimensionBuilder48.AppendedText.SetAbove(lines235)
    
    lines236 = []
    sketchRapidDimensionBuilder48.AppendedText.SetBelow(lines236)
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder48.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder48.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder48.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder48.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId281, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder48.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1373 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1374 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1375 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1376 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1377 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1378 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1379 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1380 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1381 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1382 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder48.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder48.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder48.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder48.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1383 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1384 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1385 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1386 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1387 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1388 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1389 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1390 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1391 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1392 = sketchRapidDimensionBuilder48.Style.UnitsStyle.DimensionLinearUnits
    
    expression135 = workPart.Expressions.FindObject("p54")
    expression135.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId281, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId282 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId282, None)
    
    markId283 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId281, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder48.Destroy()
    
    theSession.UndoToMark(markId283, None)
    
    theSession.DeleteUndoMark(markId283, None)
    
    sketchRapidDimensionBuilder48.Destroy()
    
    sketch21 = theSession.ActiveSketch
    
    markId284 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId285 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section10 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section10
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression136 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies90 = [NXOpen.Body.Null] * 1 
    targetBodies90[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies90)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies91 = [NXOpen.Body.Null] * 1 
    targetBodies91[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies91)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId285, "Extrude Dialog")
    
    section10.DistanceTolerance = 0.01
    
    section10.ChainingTolerance = 0.0094999999999999998
    
    section10.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId286 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId287 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features9 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature8 = feature20
    features9[0] = sketchFeature8
    curveFeatureRule9 = workPart.ScRuleFactory.CreateRuleCurveFeature(features9)
    
    section10.AllowSelfIntersection(True)
    
    rules9 = [None] * 1 
    rules9[0] = curveFeatureRule9
    helpPoint10 = NXOpen.Point3d(57.000000000000348, -56.000000000000227, -4.1815974772298361)
    section10.AddToSection(rules9, line37, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint10, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId287, None)
    
    direction26 = workPart.Directions.CreateDirection(sketch21, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction26
    
    targetBodies92 = [NXOpen.Body.Null] * 1 
    targetBodies92[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies92)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies93 = [NXOpen.Body.Null] * 1 
    targetBodies93[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies93)
    
    expression137 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId286, None)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies94 = [NXOpen.Body.Null] * 1 
    targetBodies94[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies94)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies95 = [NXOpen.Body.Null] * 1 
    targetBodies95[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies95)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies96 = [NXOpen.Body.Null] * 1 
    targetBodies96[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies96)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies97 = [NXOpen.Body.Null] * 1 
    targetBodies97[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies97)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies98 = [NXOpen.Body.Null] * 1 
    targetBodies98[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies98)
    
    targetBodies99 = []
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies99)
    
    direction27 = extrudeBuilder9.Direction
    
    success5 = direction27.ReverseDirection()
    
    extrudeBuilder9.Direction = direction27
    
    targetBodies100 = [NXOpen.Body.Null] * 1 
    targetBodies100[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies100)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies101 = [NXOpen.Body.Null] * 1 
    targetBodies101[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies101)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies102 = [NXOpen.Body.Null] * 1 
    targetBodies102[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies102)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies103 = [NXOpen.Body.Null] * 1 
    targetBodies103[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies103)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies104 = [NXOpen.Body.Null] * 1 
    targetBodies104[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies104)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies105 = [NXOpen.Body.Null] * 1 
    targetBodies105[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies105)
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("30")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies106 = [NXOpen.Body.Null] * 1 
    targetBodies106[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies106)
    
    markId288 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId288, None)
    
    markId289 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder9.ParentFeatureInternal = False
    
    feature21 = extrudeBuilder9.CommitFeature()
    
    theSession.DeleteUndoMark(markId289, None)
    
    theSession.SetUndoMarkName(markId285, "Extrude")
    
    expression138 = extrudeBuilder9.Limits.StartExtend.Value
    expression139 = extrudeBuilder9.Limits.EndExtend.Value
    extrudeBuilder9.Destroy()
    
    workPart.Expressions.Delete(expression136)
    
    workPart.Expressions.Delete(expression137)
    
    rotMatrix29 = NXOpen.Matrix3x3()
    
    rotMatrix29.Xx = -0.1249963077480831
    rotMatrix29.Xy = -0.99160129789692142
    rotMatrix29.Xz = 0.033208267923629534
    rotMatrix29.Yx = -0.15382189547111111
    rotMatrix29.Yy = 0.052434359074807507
    rotMatrix29.Yz = 0.98670637094431168
    rotMatrix29.Zx = -0.98016057231610121
    rotMatrix29.Zy = 0.11822649448222246
    rotMatrix29.Zz = -0.15908409247760538
    translation29 = NXOpen.Point3d(-7.2072982751995562, -18.831920338695774, 50.687703609172615)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix29, translation29, 2.7372126561721077)
    
    scaleAboutPoint128 = NXOpen.Point3d(24.842029176410293, -10.24612876536761, 0.0)
    viewCenter128 = NXOpen.Point3d(-24.842029176410012, 10.24612876536761, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(31.052536470512834, -12.928487946867154, 0.0)
    viewCenter129 = NXOpen.Point3d(-31.052536470512546, 12.928487946867154, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(38.060501899655769, -18.124048523645556, 0.0)
    viewCenter130 = NXOpen.Point3d(-38.060501899655485, 18.124048523645545, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(47.009250858205732, -24.354190203648713, 0.0)
    viewCenter131 = NXOpen.Point3d(-47.009250858205526, 24.354190203648681, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint131, viewCenter131)
    
    rotMatrix30 = NXOpen.Matrix3x3()
    
    rotMatrix30.Xx = 0.34169322641232003
    rotMatrix30.Xy = -0.93497480057177296
    rotMatrix30.Xz = 0.095225318690527153
    rotMatrix30.Yx = -0.54097965679861737
    rotMatrix30.Yy = -0.11282128486118298
    rotMatrix30.Yz = 0.83343408174391875
    rotMatrix30.Zx = -0.76849642156225906
    rotMatrix30.Zy = -0.33629374061680872
    rotMatrix30.Zz = -0.54435261556087389
    translation30 = NXOpen.Point3d(0.032409276372263207, -12.015668518927633, 37.987854563942086)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix30, translation30, 1.1211623039680956)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()