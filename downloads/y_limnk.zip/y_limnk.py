﻿# NX 1872
# Journal created by user on Thu Jun 13 20:41:08 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "Z:\\model1.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch Dialog")
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(True)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId7)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint1 = NXOpen.Point3d(-2.9498776893954486, 19.174204981070364, 0.0)
    viewCenter1 = NXOpen.Point3d(2.9498776893954486, -19.174204981070364, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(0.4719804303032436, 12.743471618188302, 0.0)
    viewCenter2 = NXOpen.Point3d(-0.4719804303032436, -12.743471618188302, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(7.740479056973613, -1.3215452048491465, 0.0)
    viewCenter3 = NXOpen.Point3d(-7.740479056973613, 1.3215452048491465, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(7.0985856717611968, -3.3227422293350157, 0.0)
    viewCenter4 = NXOpen.Point3d(-7.0985856717611711, 3.3227422293350157, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(4.22894465551731, -4.7122526161478522, 0.0)
    viewCenter5 = NXOpen.Point3d(-4.2289446555172692, 4.7122526161478522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(-3.7698020929182743, -5.2197259748099292, 0.0)
    viewCenter6 = NXOpen.Point3d(3.7698020929182907, 5.2197259748099292, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(-3.0158416743346197, -4.175780779847944, 0.0)
    viewCenter7 = NXOpen.Point3d(3.015841674334633, 4.175780779847944, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(-2.4126733394676956, -3.2787612049176431, 0.0)
    viewCenter8 = NXOpen.Point3d(2.4126733394677062, 3.2787612049176431, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(-3.0158416743346197, -4.0984515061470539, 0.0)
    viewCenter9 = NXOpen.Point3d(3.015841674334633, 4.0984515061470539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-3.7698020929182823, -5.1230643826838174, 0.0)
    viewCenter10 = NXOpen.Point3d(3.7698020929182823, 5.1230643826838174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(-4.7122526161478522, -6.4038304783547702, 0.0)
    viewCenter11 = NXOpen.Point3d(4.7122526161478522, 6.4038304783547702, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(-4.3799783932143459, -6.4944507209729929, 0.0)
    viewCenter12 = NXOpen.Point3d(4.3799783932143459, 6.4944507209729929, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-5.4749729915179479, -8.11806340121624, 0.0)
    viewCenter13 = NXOpen.Point3d(5.4749729915179479, 8.11806340121624, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-6.8437162393974358, -10.147579251520302, 0.0)
    viewCenter14 = NXOpen.Point3d(6.8437162393974358, 10.147579251520302, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-8.5546452992467934, -12.684474064400376, 0.0)
    viewCenter15 = NXOpen.Point3d(8.5546452992467934, 12.684474064400376, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint15, viewCenter15)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId9, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(203.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(203.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(203.0, 0.0, 11.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(203.0, 0.0, 11.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 11.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 11.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(101.5, 0.0, -12.542787025775885)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression5 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(215.54278702577588, 0.0, 5.5)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression6 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint16 = NXOpen.Point3d(191.74204981070358, -11.430776046407308, 0.0)
    viewCenter16 = NXOpen.Point3d(-191.74204981070358, 11.430776046407308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(153.3936398485628, -9.1446208371258475, 0.0)
    viewCenter17 = NXOpen.Point3d(-153.39363984856286, 9.1446208371258475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(122.71491187885032, -7.3156966697006789, 0.0)
    viewCenter18 = NXOpen.Point3d(-122.71491187885032, 7.3156966697006789, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(99.115890363686788, -6.041349507881856, 0.0)
    viewCenter19 = NXOpen.Point3d(-99.115890363686788, 6.041349507881856, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(79.292712290949382, -4.8330796063054962, 0.0)
    viewCenter20 = NXOpen.Point3d(-79.29271229094941, 4.8330796063054837, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    point3 = NXOpen.Point3d(203.0, 0.0, 7.517266296031174)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(line2, workPart.ModelingViews.WorkView, point3)
    
    point1_1 = NXOpen.Point3d(203.0, 0.0, 11.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, workPart.ModelingViews.WorkView, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(203.0, 0.0, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    dimensionlinearunits21 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point4 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point4
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point5 = NXOpen.Point3d(208.78764665012773, 0.0, 7.7589202763464549)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point5)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject3 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId11, None)
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId10, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId12, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits27 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    expression7 = workPart.Expressions.FindObject("p0")
    expression7.SetFormula("2.8")
    
    theSession.SetUndoMarkVisibility(markId12, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.25454545454545452)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId13, None)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId12, "Edit Driving Value")
    
    scaleAboutPoint21 = NXOpen.Point3d(-60.655149059133876, -3.2623287342562053, 0.0)
    viewCenter21 = NXOpen.Point3d(60.655149059133898, 3.2623287342561951, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-76.272037537008501, -4.5310121309114084, 0.0)
    viewCenter22 = NXOpen.Point3d(76.272037537008501, 4.531012130911396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-97.039176470352402, -7.740479056973629, 0.0)
    viewCenter23 = NXOpen.Point3d(97.039176470352402, 7.740479056973629, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-137.3463052182517, -21.003129148495532, 0.0)
    viewCenter24 = NXOpen.Point3d(137.3463052182517, 21.003129148495532, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-171.6828815228146, -26.253911435619411, 0.0)
    viewCenter25 = NXOpen.Point3d(171.68288152281465, 26.253911435619436, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(-215.34107132586718, -33.186124005698673, 0.0)
    viewCenter26 = NXOpen.Point3d(215.34107132586718, 33.186124005698737, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-312.96358610929752, -49.779186008548017, 0.0)
    viewCenter27 = NXOpen.Point3d(312.96358610929752, 49.779186008548095, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-250.37086888743801, -39.823348806838418, 0.0)
    viewCenter28 = NXOpen.Point3d(250.37086888743801, 39.823348806838474, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-200.29669510995041, -31.858679045470705, 0.0)
    viewCenter29 = NXOpen.Point3d(200.29669510995041, 31.85867904547078, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-160.23735608796036, -25.486943236376611, 0.0)
    viewCenter30 = NXOpen.Point3d(160.23735608796036, 25.486943236376632, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-128.1898848703683, -20.389554589101273, 0.0)
    viewCenter31 = NXOpen.Point3d(128.1898848703683, 20.389554589101305, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-102.55190789629464, -16.311643671281015, 0.0)
    viewCenter32 = NXOpen.Point3d(102.55190789629461, 16.31164367128104, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    point6 = NXOpen.Point3d(35.385841898925321, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(line1, workPart.ModelingViews.WorkView, point6)
    
    point1_3 = NXOpen.Point3d(51.672727272727265, 0.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, workPart.ModelingViews.WorkView, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point7 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point7
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point8 = NXOpen.Point3d(35.50666888908296, 0.0, -7.3932444703407505)
    sketchRapidDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject4 = sketchRapidDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId15, None)
    
    theSession.SetUndoMarkName(markId14, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId14, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId16, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    expression8 = workPart.Expressions.FindObject("p1")
    expression8.SetFormula("50")
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId16, "Edit Driving Value")
    
    sketchRapidDimensionBuilder3.Destroy()
    
    theSession.UndoToMark(markId18, None)
    
    theSession.DeleteUndoMark(markId18, None)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId20, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(35.530433514904502, -1.7763568394002505e-15, 2.8000000000000016)
    section1.AddToSection(rules1, line3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId22, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId21, None)
    
    extrudeBuilder1.Limits.SymmetricOption = True
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder1.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder1.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("3")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("3")
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId23, None)
    
    theSession.SetUndoMarkName(markId20, "Extrude")
    
    expression11 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    workPart.Expressions.Delete(expression10)
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("3")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("3")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("3")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId24, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scaleAboutPoint33 = NXOpen.Point3d(7.9646697613676878, -4.7198043030326868, 0.0)
    viewCenter33 = NXOpen.Point3d(-7.9646697613676878, 4.7198043030326868, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(9.9558372017096097, -5.8997553787908901, 0.0)
    viewCenter34 = NXOpen.Point3d(-9.9558372017096097, 5.899755378790827, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(12.444796502137009, -7.3746942234886115, 0.0)
    viewCenter35 = NXOpen.Point3d(-12.444796502137009, 7.3746942234885333, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(15.555995627671264, -9.2183677793607153, 0.0)
    viewCenter36 = NXOpen.Point3d(-15.555995627671264, 9.2183677793606673, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(19.444994534589203, -14.403699655251149, 0.0)
    viewCenter37 = NXOpen.Point3d(-19.444994534588954, 14.403699655251149, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(24.306243168236502, -18.004624569063935, 0.0)
    viewCenter38 = NXOpen.Point3d(-24.306243168236193, 18.004624569063935, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(30.382803960295529, -22.505780711329919, 0.0)
    viewCenter39 = NXOpen.Point3d(-30.382803960295337, 22.505780711329919, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(24.306243168236502, -18.004624569063935, 0.0)
    viewCenter40 = NXOpen.Point3d(-24.306243168236193, 18.004624569063935, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(19.444994534589203, -14.403699655251149, 0.0)
    viewCenter41 = NXOpen.Point3d(-19.444994534588954, 14.403699655251149, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(15.555995627671411, -11.52295972420092, 0.0)
    viewCenter42 = NXOpen.Point3d(-15.555995627671164, 11.52295972420092, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(12.444796502137089, -9.2183677793607348, 0.0)
    viewCenter43 = NXOpen.Point3d(-12.444796502136853, 9.2183677793607348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(9.9558372017097039, -7.3746942234885893, 0.0)
    viewCenter44 = NXOpen.Point3d(-9.9558372017095156, 7.3746942234885893, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(6.7847186856096302, -4.7198043030326877, 0.0)
    viewCenter45 = NXOpen.Point3d(-6.7847186856093282, 4.7198043030326877, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(4.9557945181844811, -3.0678727969712449, 0.0)
    viewCenter46 = NXOpen.Point3d(-4.9557945181842191, 3.0678727969712449, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(3.9646356145476003, -2.265506065455698, 0.0)
    viewCenter47 = NXOpen.Point3d(-3.9646356145473107, 2.265506065455698, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(2.2655060654558272, -0.75516868848522845, 0.0)
    viewCenter48 = NXOpen.Point3d(-2.2655060654555697, 0.75516868848522845, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(1.0874429114188795, 0.84578893110346409, 0.0)
    viewCenter49 = NXOpen.Point3d(-1.0874429114185908, -0.84578893110346409, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(0.86995432913512838, 0.67663114488277143, 0.0)
    viewCenter50 = NXOpen.Point3d(-0.86995432913484816, -0.67663114488277143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(0.6959634633081424, 0.61863418960710725, 0.0)
    viewCenter51 = NXOpen.Point3d(-0.69596346330784564, -0.6186341896071007, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(0.55677077064654024, 0.98981470337137689, 0.0)
    viewCenter52 = NXOpen.Point3d(-0.55677077064624481, -0.98981470337136102, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    extrudeBuilder2.Destroy()
    
    section2.Destroy()
    
    workPart.Expressions.Delete(expression12)
    
    theSession.UndoToMark(markId24, None)
    
    theSession.DeleteUndoMark(markId24, None)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId25, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 120 * 140 {(50,3,2.8)(25,3,2.8)(0,3,2.8) EXTRUDE(2)}")
    point9 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 140 * 150 {(0,-3,2.8)(0,0,2.8)(0,3,2.8) EXTRUDE(2)}")
    direction3 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 140 {(25,0,2.8) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point9, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point10 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId26, None)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject5 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject5
    feature3 = sketch3.Feature
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId28)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId27, None)
    
    theSession.SetUndoMarkName(markId25, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point10)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    scaleAboutPoint53 = NXOpen.Point3d(3.8107866079798995, -11.234396883264976, 0.0)
    viewCenter53 = NXOpen.Point3d(-3.8107866079795958, 11.234396883264994, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(3.0486292863839499, -8.9875175066119848, 0.0)
    viewCenter54 = NXOpen.Point3d(-3.0486292863836497, 8.9875175066119919, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(2.4389034291071869, -7.1900140052895898, 0.0)
    viewCenter55 = NXOpen.Point3d(-2.4389034291068898, 7.1900140052895924, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(0.50678512812628473, -4.6877624351667784, 0.0)
    viewCenter56 = NXOpen.Point3d(-0.50678512812598875, 4.687762435166781, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(0.63348141015781811, -5.8597030439584739, 0.0)
    viewCenter57 = NXOpen.Point3d(-0.63348141015752102, 5.8597030439584765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(0.79185176269722846, -7.3246288049480928, 0.0)
    viewCenter58 = NXOpen.Point3d(-0.79185176269693813, 7.3246288049480928, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    origin7 = NXOpen.Point3d(24.077044696567761, 4.3766342894490373, 2.8000000000001806)
    workPart.ModelingViews.WorkView.SetOrigin(origin7)
    
    origin8 = NXOpen.Point3d(24.077044696567761, 4.3766342894490373, 2.8000000000001806)
    workPart.ModelingViews.WorkView.SetOrigin(origin8)
    
    origin9 = NXOpen.Point3d(36.301256283204111, 4.3766342894490373, 2.8000000000001806)
    workPart.ModelingViews.WorkView.SetOrigin(origin9)
    
    origin10 = NXOpen.Point3d(36.301256283204111, 4.3766342894490373, 2.8000000000001806)
    workPart.ModelingViews.WorkView.SetOrigin(origin10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId30, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(43.22995920680367, 0.0, 2.7999999999999985)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 1.8357381616305628, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = arc1
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line3
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = 43.22995920680367
    help1.Point.Y = 0.0
    help1.Point.Z = 2.7999999999999985
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_5, conGeom2_5, help1)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = arc1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(42.668804414341167, 0.0, 2.7999999999999985)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    expression17 = sketchDimensionalConstraint3.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    theSession.SetUndoMarkName(markId31, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point1_5 = NXOpen.Point3d(43.22995920680367, 0.0, 2.7999999999999985)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(43.22995920680367, 0.0, 2.7999999999999985)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    point1_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point11 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point11
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point12 = NXOpen.Point3d(40.260515096689574, 7.3955691347316952, 2.7999999999999985)
    sketchRapidDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point12)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.TextCentered = False
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject6 = sketchRapidDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId32, None)
    
    theSession.SetUndoMarkName(markId31, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId31, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId33, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    expression18 = workPart.Expressions.FindObject("p4")
    expression18.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId33, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId34, None)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId33, "Edit Driving Value")
    
    point1_8 = NXOpen.Point3d(43.22995920680367, 0.0, 2.7999999999999985)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(43.22995920680367, 0.0, 2.7999999999999985)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    edge3 = extrude1.FindObject("EDGE * 140 * 170 {(50,-3,2.8)(50,0,2.8)(50,3,2.8) EXTRUDE(2)}")
    point13 = NXOpen.Point3d(50.0, 0.56584768146928288, 2.799999999999998)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(edge3, workPart.ModelingViews.WorkView, point13)
    
    point1_11 = NXOpen.Point3d(50.0, 0.56584768146928288, 2.799999999999998)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(43.22995920680367, 0.0, 2.7999999999999985)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    point1_13 = NXOpen.Point3d(50.0, 0.56584768146928288, 2.799999999999998)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(43.22995920680367, 0.0, 2.7999999999999985)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point14 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point14
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point15 = NXOpen.Point3d(48.376995664334757, -0.3744762867335103, 2.799999999999998)
    sketchRapidDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point15)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId36, None)
    
    theSession.SetUndoMarkName(markId35, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines25 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines28)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId37, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    expression19 = workPart.Expressions.FindObject("p5")
    expression19.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId37, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId38, None)
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId37, "Edit Driving Value")
    
    scaleAboutPoint59 = NXOpen.Point3d(1.781666466068603, -9.55171188753366, 0.0)
    viewCenter59 = NXOpen.Point3d(-1.7816664660683077, 9.55171188753366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(1.4253331728549095, -7.6413695100269283, 0.0)
    viewCenter60 = NXOpen.Point3d(-1.425333172854619, 7.6413695100269283, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder6.Destroy()
    
    theSession.UndoToMark(markId39, None)
    
    theSession.DeleteUndoMark(markId39, None)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    sketch4 = theSession.ActiveSketch
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("3")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("3")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("3")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId41, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section3.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule2
    helpPoint2 = NXOpen.Point3d(46.204135129973729, 1.2687488983184831, 2.7999999999999985)
    section3.AddToSection(rules2, arc1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId43, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction4
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies6[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId42, None)
    
    direction5 = extrudeBuilder3.Direction
    
    success1 = direction5.ReverseDirection()
    
    extrudeBuilder3.Direction = direction5
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("7")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies13)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId44, None)
    
    theSession.SetUndoMarkName(markId41, "Extrude")
    
    expression22 = extrudeBuilder3.Limits.StartExtend.Value
    expression23 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression20)
    
    workPart.Expressions.Delete(expression21)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("7")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId45, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder4.Destroy()
    
    section4.Destroy()
    
    workPart.Expressions.Delete(expression24)
    
    theSession.UndoToMark(markId45, None)
    
    theSession.DeleteUndoMark(markId45, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin11, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId46, "Create Sketch Dialog")
    
    scalar3 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge4 = extrude1.FindObject("EDGE * 130 * 140 {(50,-3,2.8)(25,-3,2.8)(0,-3,2.8) EXTRUDE(2)}")
    point16 = workPart.Points.CreatePoint(edge4, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction6 = workPart.Directions.CreateDirection(edge4, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude1.FindObject("FACE 130 {(25,-3,1.4) EXTRUDE(2)}")
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction6, point16, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem3
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin12, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom6 = [NXOpen.NXObject.Null] * 1 
    geom6[0] = face2
    plane8.SetGeometry(geom6)
    
    plane8.SetFlip(False)
    
    plane8.SetExpression(None)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin13, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane9.SynchronizeToPlane(plane8)
    
    scalar4 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point17 = workPart.Points.CreatePoint(edge4, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face2
    plane9.SetGeometry(geom7)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId47, None)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject8 = sketchInPlaceBuilder3.Commit()
    
    sketch5 = nXObject8
    feature5 = sketch5.Feature
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId49)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId48, None)
    
    theSession.SetUndoMarkName(markId46, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression26)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point17)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression25)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression28)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression27)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId51, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(0.0, -3.0, -2.248054987193953)
    endPoint5 = NXOpen.Point3d(14.000000000000002, -3.0, -2.248054987193953)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(14.000000000000002, -3.0, -2.248054987193953)
    endPoint6 = NXOpen.Point3d(14.000000000000002, -3.0, 5.251945012806047)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(14.000000000000002, -3.0, 5.251945012806047)
    endPoint7 = NXOpen.Point3d(0.0, -3.0, 5.251945012806047)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(0.0, -3.0, 5.251945012806047)
    endPoint8 = NXOpen.Point3d(0.0, -3.0, -2.248054987193953)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line5
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line6
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line6
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line7
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line7
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line8
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line8
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line5
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom8.Geometry = line5
    geom8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom8)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line5
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line6
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line6
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line7
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line7
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line8
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line8
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line5
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line5
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line5
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(7.0000000000000009, -3.0, -3.9315193645814706)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_3, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression29 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = line6
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line6
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(15.683464377387519, -3.0, 1.501945012806047)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_5, dimObject2_4, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint5
    dimension5 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression30 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines33 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines36)
    
    theSession.SetUndoMarkName(markId52, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    point18 = NXOpen.Point3d(8.3144435083196129, -3.0, 5.251945012806047)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(line7, workPart.ModelingViews.WorkView, point18)
    
    point1_15 = NXOpen.Point3d(14.000000000000002, -3.0, 5.251945012806047)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(0.0, -3.0, 5.251945012806047)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    point1_17 = NXOpen.Point3d(0.0, -3.0, 2.7999999999999998)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    point1_18 = NXOpen.Point3d(8.3144435083196129, -3.0, 5.251945012806047)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    point1_19 = NXOpen.Point3d(0.0, -3.0, 2.7999999999999998)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(8.3144435083196129, -3.0, 5.251945012806047)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    point1_21 = NXOpen.Point3d(0.0, -3.0, 2.7999999999999998)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point19 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point19
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder7.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point20 = NXOpen.Point3d(8.017499097308205, -3.0, 3.5423610275285289)
    sketchRapidDimensionBuilder7.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point20)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.TextCentered = False
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject9 = sketchRapidDimensionBuilder7.Commit()
    
    theSession.DeleteUndoMark(markId53, None)
    
    theSession.SetUndoMarkName(markId52, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines37 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines40)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId54, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits195 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits197 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits203 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits205 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits207 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits213 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    expression31 = workPart.Expressions.FindObject("p8")
    expression31.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId54, "Edit Driving Value")
    
    point21 = NXOpen.Point3d(12.02624864596223, -3.0, -3.1999999999999984)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(line5, workPart.ModelingViews.WorkView, point21)
    
    point1_22 = NXOpen.Point3d(14.000000000000004, -3.0, -3.1999999999999984)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line5, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    point1_23 = NXOpen.Point3d(1.7763568394002505e-15, -3.0, -3.1999999999999984)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    dimensionlinearunits215 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    edge5 = extrude1.FindObject("EDGE * 130 * 160 {(0,-3,0)(25,-3,0)(50,-3,0) EXTRUDE(2)}")
    point1_24 = NXOpen.Point3d(0.0, -3.0, 0.0)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge5, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(12.02624864596223, -3.0, -3.1999999999999984)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    point1_26 = NXOpen.Point3d(0.0, -3.0, 0.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge5, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(12.02624864596223, -3.0, -3.1999999999999984)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(0.0, -3.0, 0.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge5, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    dimensionlinearunits221 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits223 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits225 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits229 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point22 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point22
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point23 = NXOpen.Point3d(8.3144435083196129, -3.0, -1.3077310189911557)
    sketchRapidDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point23)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.TextCentered = True
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject10 = sketchRapidDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId57, None)
    
    theSession.SetUndoMarkName(markId56, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId58, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits233 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits251 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    expression32 = workPart.Expressions.FindObject("p9")
    expression32.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId59, None)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId58, "Edit Driving Value")
    
    point24 = NXOpen.Point3d(3.8107866079799013, -3.0, 4.3000000000000007)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(line7, workPart.ModelingViews.WorkView, point24)
    
    point1_29 = NXOpen.Point3d(1.7763568394002505e-15, -3.0, 4.2999999999999998)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(14.000000000000002, -3.0, 4.3000000000000016)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    dimensionlinearunits253 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits257 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point25 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point25
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point26 = NXOpen.Point3d(4.3056939596655877, -3.0, 7.155184694834011)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point26)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject11 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId61, None)
    
    theSession.SetUndoMarkName(markId60, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId60, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId62, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits259 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits261 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression33 = workPart.Expressions.FindObject("p10")
    expression33.SetFormula("8")
    
    theSession.SetUndoMarkVisibility(markId62, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId63, None)
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId62, "Edit Driving Value")
    
    point1_31 = NXOpen.Point3d(6.0000000000000018, -3.0, 1.3999999999999999)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line8, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    edge6 = extrude1.FindObject("EDGE * 130 * 150 {(0,-3,2.8)(0,-3,1.4)(0,-3,0) EXTRUDE(2)}")
    point1_32 = NXOpen.Point3d(0.0, -3.0, 1.3999999999999999)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge6, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    point1_33 = NXOpen.Point3d(6.0000000000000018, -3.0, 1.3999999999999999)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line8, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(0.0, -3.0, 1.3999999999999999)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge6, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point27 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point27
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder10.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point28 = NXOpen.Point3d(2.2270830825857222, -3.0, -2.4460179278682235)
    sketchRapidDimensionBuilder10.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point28)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.TextCentered = False
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject12 = sketchRapidDimensionBuilder10.Commit()
    
    theSession.DeleteUndoMark(markId65, None)
    
    theSession.SetUndoMarkName(markId64, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId66, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    expression34 = workPart.Expressions.FindObject("p11")
    expression34.SetFormula("0")
    
    theSession.SetUndoMarkVisibility(markId66, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId67, None)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId66, "Edit Driving Value")
    
    scaleAboutPoint61 = NXOpen.Point3d(8.8093508600052921, 2.6724996991026924, 0.0)
    viewCenter61 = NXOpen.Point3d(-8.8093508600049883, -2.6724996991026755, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(6.8495177473299931, 2.2171849355518707, 0.0)
    viewCenter62 = NXOpen.Point3d(-6.8495177473296893, -2.2171849355518467, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(5.3845919863403671, 1.7737479484414962, 0.0)
    viewCenter63 = NXOpen.Point3d(-5.3845919863400704, -1.7737479484414747, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder11.Destroy()
    
    theSession.UndoToMark(markId68, None)
    
    theSession.DeleteUndoMark(markId68, None)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    sketch6 = theSession.ActiveSketch
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("7")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId70, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature5
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section5.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule3
    helpPoint3 = NXOpen.Point3d(1.0405828242666391, -3.0, 4.2999999999999989)
    section5.AddToSection(rules3, line7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId72, None)
    
    direction7 = workPart.Directions.CreateDirection(sketch6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction7
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies19)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId71, None)
    
    direction8 = extrudeBuilder5.Direction
    
    success2 = direction8.ReverseDirection()
    
    extrudeBuilder5.Direction = direction8
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("11.5")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies26)
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies28)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature6 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId73, None)
    
    theSession.SetUndoMarkName(markId70, "Extrude")
    
    expression37 = extrudeBuilder5.Limits.StartExtend.Value
    expression38 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression35)
    
    workPart.Expressions.Delete(expression36)
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId74, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder6.Destroy()
    
    section6.Destroy()
    
    workPart.Expressions.Delete(expression39)
    
    theSession.UndoToMark(markId74, None)
    
    theSession.DeleteUndoMark(markId74, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin14, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane10
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId75, "Create Sketch Dialog")
    
    scalar5 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature6
    edge7 = extrude2.FindObject("EDGE * 150 EXTRUDE(2) 130 {(8,-3,0)(8,-3,-0.75)(8,-3,-1.5) EXTRUDE(2)}")
    point29 = workPart.Points.CreatePoint(edge7, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge8 = extrude2.FindObject("EDGE * 160 EXTRUDE(2) 130 {(8,-3,-1.5)(4,-3,-1.5)(0,-3,-1.5) EXTRUDE(2)}")
    direction9 = workPart.Directions.CreateDirection(edge8, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction9, point29, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem4
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin15, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = face2
    plane11.SetGeometry(geom9)
    
    plane11.SetFlip(False)
    
    plane11.SetExpression(None)
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin16, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane12.SynchronizeToPlane(plane11)
    
    scalar6 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point30 = workPart.Points.CreatePoint(edge7, scalar6, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = face2
    plane12.SetGeometry(geom10)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId76, None)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject13 = sketchInPlaceBuilder4.Commit()
    
    sketch7 = nXObject13
    feature7 = sketch7.Feature
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId78)
    
    sketch7.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.SetUndoMarkName(markId75, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression41)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point30)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression40)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression43)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression42)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane12.DestroyPlane()
    
    scaleAboutPoint64 = NXOpen.Point3d(-3.8107866079796042, 0.49490735168569205, 0.0)
    viewCenter64 = NXOpen.Point3d(3.810786607979908, -0.49490735168567518, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(-4.763483259974552, 0.61863418960711503, 0.0)
    viewCenter65 = NXOpen.Point3d(4.7634832599748371, -0.61863418960709926, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(-5.954354074968224, 0.77329273700888734, 0.0)
    viewCenter66 = NXOpen.Point3d(5.9543540749685144, -0.77329273700887413, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(-4.763483259974552, 0.61863418960711503, 0.0)
    viewCenter67 = NXOpen.Point3d(4.7634832599748371, -0.61863418960709393, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(-3.8107866079796127, 0.49490735168569627, 0.0)
    viewCenter68 = NXOpen.Point3d(3.8107866079798995, -0.49490735168567518, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(-3.0486292863836595, 0.39592588134855705, 0.0)
    viewCenter69 = NXOpen.Point3d(3.0486292863839468, -0.39592588134853679, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-7.3167102873209853, 3.040710768756842, 0.0)
    viewCenter70 = NXOpen.Point3d(7.3167102873212659, -3.0407107687568207, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId80, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(-1.5000000000000009, -3.0, 3.2000000000000002)
    endPoint9 = NXOpen.Point3d(6.3999999999999986, -3.0, 3.2000000000000002)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(6.3999999999999986, -3.0, 3.2000000000000002)
    endPoint10 = NXOpen.Point3d(6.3999999999999986, -3.0, -0.20000000000000018)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(6.3999999999999986, -3.0, -0.20000000000000018)
    endPoint11 = NXOpen.Point3d(-1.5000000000000009, -3.0, -0.20000000000000018)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(-1.5000000000000009, -3.0, -0.20000000000000018)
    endPoint12 = NXOpen.Point3d(-1.5000000000000009, -3.0, 3.2000000000000002)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line9
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line10
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line10
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line11
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line11
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line12
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line12
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line9
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom11.Geometry = line9
    geom11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateHorizontalConstraint(geom11)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line9
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line10
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line10
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line11
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line11
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line12
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line12
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line9
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line9
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line9
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(2.4499999999999988, -3.0, 2.338066238777591)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_5, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression44 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line10
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line10
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(5.5380662387775894, -3.0, 1.5)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_6, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression45 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines57 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines60)
    
    theSession.SetUndoMarkName(markId81, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    point31 = NXOpen.Point3d(3.7204371485037226, -3.0, 4.2999999999999998)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(line7, workPart.ModelingViews.WorkView, point31)
    
    point1_35 = NXOpen.Point3d(2.4499999999999988, -3.0, 3.2000000000000002)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line9, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point32 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point32
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder12.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point33 = NXOpen.Point3d(-1.6514852096333472, -3.0, 4.7392327997421049)
    sketchRapidDimensionBuilder12.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point33)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.TextCentered = False
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject14 = sketchRapidDimensionBuilder12.Commit()
    
    theSession.DeleteUndoMark(markId82, None)
    
    theSession.SetUndoMarkName(markId81, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId81, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines61 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines64)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId83, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    expression46 = workPart.Expressions.FindObject("p14")
    expression46.SetFormula("1")
    
    theSession.SetUndoMarkVisibility(markId83, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId84, None)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId83, "Edit Driving Value")
    
    point1_36 = NXOpen.Point3d(2.4499999999999997, -3.0, -0.099999999999999062)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line11, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point34 = NXOpen.Point3d(2.6055098666262166, -3.0, -1.5000000000000004)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(line5, workPart.ModelingViews.WorkView, point34)
    
    point1_37 = NXOpen.Point3d(2.6055098666262166, -3.0, -1.5000000000000004)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(2.4499999999999997, -3.0, -0.099999999999999062)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line11, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point35 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point35
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder13.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point36 = NXOpen.Point3d(-1.3474141327576641, -3.0, -1.6209205582409347)
    sketchRapidDimensionBuilder13.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point36)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.TextCentered = False
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject15 = sketchRapidDimensionBuilder13.Commit()
    
    theSession.DeleteUndoMark(markId86, None)
    
    theSession.SetUndoMarkName(markId85, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId87, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    expression47 = workPart.Expressions.FindObject("p15")
    expression47.SetFormula("1")
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId88, None)
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId87, "Edit Driving Value")
    
    point37 = NXOpen.Point3d(-1.5000000000000009, -3.0, 2.4586997231744818)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(line12, workPart.ModelingViews.WorkView, point37)
    
    point1_39 = NXOpen.Point3d(-1.5000000000000009, -3.0, 3.3000000000000012)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line12, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(-1.5000000000000009, -3.0, -0.50000000000000089)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    point1_41 = NXOpen.Point3d(-8.8817841970012523e-16, -3.0, 4.2999999999999989)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    point1_42 = NXOpen.Point3d(-1.5000000000000009, -3.0, 2.4586997231744818)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line12, workPart.ModelingViews.WorkView, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(-8.8817841970012523e-16, -3.0, 4.2999999999999989)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(-1.5000000000000009, -3.0, 2.4586997231744818)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line12, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    point1_45 = NXOpen.Point3d(-8.8817841970012523e-16, -3.0, 4.2999999999999989)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point38 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point38
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder14.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point39 = NXOpen.Point3d(-0.91664677385044513, -3.0, 1.5464864925474315)
    sketchRapidDimensionBuilder14.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point39)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.TextCentered = False
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject16 = sketchRapidDimensionBuilder14.Commit()
    
    theSession.DeleteUndoMark(markId90, None)
    
    theSession.SetUndoMarkName(markId89, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId89, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines69 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines72)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId91, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    expression48 = workPart.Expressions.FindObject("p16")
    expression48.SetFormula("1")
    
    theSession.SetUndoMarkVisibility(markId91, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId92, None)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId91, "Edit Driving Value")
    
    point40 = NXOpen.Point3d(5.2407925328821401, -3.0, 3.3000000000000012)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(line9, workPart.ModelingViews.WorkView, point40)
    
    point1_46 = NXOpen.Point3d(6.8999999999999986, -3.0, 3.3000000000000012)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(-1.0000000000000009, -3.0, 3.3000000000000003)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point41 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point41
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder15.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point42 = NXOpen.Point3d(4.5059540970992362, -3.0, 6.1328919020889874)
    sketchRapidDimensionBuilder15.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point42)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.TextCentered = False
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject17 = sketchRapidDimensionBuilder15.Commit()
    
    theSession.DeleteUndoMark(markId94, None)
    
    theSession.SetUndoMarkName(markId93, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId93, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines73 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines76)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId95, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    expression49 = workPart.Expressions.FindObject("p17")
    expression49.SetFormula("8")
    
    theSession.SetUndoMarkVisibility(markId95, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId96, None)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId95, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder16.Destroy()
    
    theSession.UndoToMark(markId97, None)
    
    theSession.DeleteUndoMark(markId97, None)
    
    sketchRapidDimensionBuilder16.Destroy()
    
    sketch8 = theSession.ActiveSketch
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies32)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId99, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature7
    features4[0] = sketchFeature4
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section7.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule4
    helpPoint4 = NXOpen.Point3d(-1.0000000000000016, -2.9999999999999991, 2.7279909900842134)
    section7.AddToSection(rules4, line12, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId101, None)
    
    direction10 = workPart.Directions.CreateDirection(sketch8, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction10
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId100, None)
    
    direction11 = extrudeBuilder7.Direction
    
    success3 = direction11.ReverseDirection()
    
    extrudeBuilder7.Direction = direction11
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("13")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies33)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies34)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    feature8 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId102, None)
    
    theSession.SetUndoMarkName(markId99, "Extrude")
    
    expression52 = extrudeBuilder7.Limits.StartExtend.Value
    expression53 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression50)
    
    workPart.Expressions.Delete(expression51)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies35)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("13")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies36 = [NXOpen.Body.Null] * 1 
    targetBodies36[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies36)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId103, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    extrudeBuilder8.Destroy()
    
    section8.Destroy()
    
    workPart.Expressions.Delete(expression54)
    
    theSession.UndoToMark(markId103, None)
    
    theSession.DeleteUndoMark(markId103, None)
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin17, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane13
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId104, "Create Sketch Dialog")
    
    scalar7 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge9 = extrude2.FindObject("EDGE * 140 * 150 {(8,3,4.3)(8,0,4.3)(8,-3,4.3) EXTRUDE(2)}")
    point43 = workPart.Points.CreatePoint(edge9, scalar7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction12 = workPart.Directions.CreateDirection(edge9, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude2.FindObject("FACE 140 {(4,0,4.3) EXTRUDE(2)}")
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction12, point43, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem5
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin18, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = face3
    plane14.SetGeometry(geom12)
    
    plane14.SetFlip(False)
    
    plane14.SetExpression(None)
    
    plane14.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane14.Evaluate()
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin19, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane15.SynchronizeToPlane(plane14)
    
    scalar8 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point44 = workPart.Points.CreatePoint(edge9, scalar8, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = face3
    plane15.SetGeometry(geom13)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId105, None)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject18 = sketchInPlaceBuilder5.Commit()
    
    sketch9 = nXObject18
    feature9 = sketch9.Feature
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId107)
    
    sketch9.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.SetUndoMarkName(markId104, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression56)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point44)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression55)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression58)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression57)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId109, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(3.9999999999999982, 0.0, 4.3000000000000007)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.9896412672389601, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = arc2
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(3.4388452075374922, 0.0, 4.3000000000000007)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension8 = sketchDimensionalConstraint8.AssociatedDimension
    
    expression59 = sketchDimensionalConstraint8.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines77 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines80)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines81 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines84)
    
    theSession.SetUndoMarkName(markId110, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits441 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits443 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits447 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits451 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits453 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits459 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    point1_48 = NXOpen.Point3d(3.9999999999999982, 0.0, 4.3000000000000007)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    point1_49 = NXOpen.Point3d(3.9999999999999982, 0.0, 4.3000000000000007)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    dimensionlinearunits461 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits463 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point45 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point45
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder17.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point46 = NXOpen.Point3d(1.7146766335918191, 6.0189348452828106, 4.3000000000000007)
    sketchRapidDimensionBuilder17.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point46)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.TextCentered = False
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject19 = sketchRapidDimensionBuilder17.Commit()
    
    theSession.DeleteUndoMark(markId111, None)
    
    theSession.SetUndoMarkName(markId110, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId110, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder17.Destroy()
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId112, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits467 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits469 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits471 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits473 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits477 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits479 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits481 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits485 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    expression60 = workPart.Expressions.FindObject("p20")
    expression60.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId112, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.75390474891022796)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId113, None)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId112, "Edit Driving Value")
    
    point1_51 = NXOpen.Point3d(4.9843810043590864, 0.73828575326931611, 4.3000000000000007)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(4.9843810043590864, 0.73828575326931611, 4.3000000000000007)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    point1_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    dimensionlinearunits487 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    datumPlane2 = workPart.Datums.FindObject("DATUM_CSYS(0) YZ plane")
    point47 = NXOpen.Point3d(7.2116301717823669e-17, 0.8718983877517168, 2.0786108770798655)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(datumPlane2, workPart.ModelingViews.WorkView, point47)
    
    point1_54 = NXOpen.Point3d(7.2116301717823669e-17, 0.8718983877517168, 2.0786108770798655)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, datumPlane2, workPart.ModelingViews.WorkView, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    point1_55 = NXOpen.Point3d(4.9843810043590864, 0.73828575326931611, 4.3000000000000007)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    point1_56 = NXOpen.Point3d(7.2116301717823669e-17, 0.8718983877517168, 2.0786108770798655)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, datumPlane2, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(4.9843810043590864, 0.73828575326931611, 4.3000000000000007)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point48 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point48
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point49 = NXOpen.Point3d(-2.393054385399342, 5.9694441101142459, 4.3000000000000007)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point49)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = False
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject20 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId115, None)
    
    theSession.SetUndoMarkName(markId114, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId114, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines89 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines92)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId116, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression61 = workPart.Expressions.FindObject("p21")
    expression61.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId116, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId117, None)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId116, "Edit Driving Value")
    
    point1_58 = NXOpen.Point3d(4.0, 0.73828575326931611, 4.3000000000000007)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(4.0, 0.73828575326931611, 4.3000000000000007)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    point1_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    point1_61 = NXOpen.Point3d(3.9999999999999991, -3.0, 4.2999999999999998)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line7, workPart.ModelingViews.WorkView, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(4.0, 0.73828575326931611, 4.3000000000000007)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    point1_63 = NXOpen.Point3d(3.9999999999999991, -3.0, 4.2999999999999998)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line7, workPart.ModelingViews.WorkView, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    point1_64 = NXOpen.Point3d(4.0, 0.73828575326931611, 4.3000000000000007)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    point1_65 = NXOpen.Point3d(3.9999999999999991, -3.0, 4.2999999999999998)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line7, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point50 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point50
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder19.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point51 = NXOpen.Point3d(3.1004172183117298, -6.0568045358478333, 4.3000000000000007)
    sketchRapidDimensionBuilder19.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point51)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.TextCentered = False
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject21 = sketchRapidDimensionBuilder19.Commit()
    
    theSession.DeleteUndoMark(markId119, None)
    
    theSession.SetUndoMarkName(markId118, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId118, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines93 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines96)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId120, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    expression62 = workPart.Expressions.FindObject("p22")
    expression62.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId120, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId121, None)
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId120, "Edit Driving Value")
    
    sketchRapidDimensionBuilder20.Destroy()
    
    theSession.UndoToMark(markId122, None)
    
    theSession.DeleteUndoMark(markId122, None)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch10 = theSession.ActiveSketch
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section9
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies37)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("13")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies38)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId124, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features5 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature5 = feature9
    features5[0] = sketchFeature5
    curveFeatureRule5 = workPart.ScRuleFactory.CreateRuleCurveFeature(features5)
    
    section9.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule5
    helpPoint5 = NXOpen.Point3d(3.163999980236909, 1.2425661813766193, 4.3000000000000007)
    section9.AddToSection(rules5, arc2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId126, None)
    
    direction13 = workPart.Directions.CreateDirection(sketch10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction13
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies39)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies40)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId125, None)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies41)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies42)
    
    direction14 = extrudeBuilder9.Direction
    
    success4 = direction14.ReverseDirection()
    
    extrudeBuilder9.Direction = direction14
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies43)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies44)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies45)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies46 = [NXOpen.Body.Null] * 1 
    targetBodies46[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies46)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies47)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies48 = [NXOpen.Body.Null] * 1 
    targetBodies48[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("18")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies50)
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder9.ParentFeatureInternal = False
    
    feature10 = extrudeBuilder9.CommitFeature()
    
    theSession.DeleteUndoMark(markId127, None)
    
    theSession.SetUndoMarkName(markId124, "Extrude")
    
    expression65 = extrudeBuilder9.Limits.StartExtend.Value
    expression66 = extrudeBuilder9.Limits.EndExtend.Value
    extrudeBuilder9.Destroy()
    
    workPart.Expressions.Delete(expression63)
    
    workPart.Expressions.Delete(expression64)
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder10 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section10 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder10.Section = section10
    
    extrudeBuilder10.AllowSelfIntersectingSection(True)
    
    expression67 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder10.DistanceTolerance = 0.01
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies51)
    
    extrudeBuilder10.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("18")
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies52)
    
    extrudeBuilder10.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder10.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder10 = extrudeBuilder10.SmartVolumeProfile
    
    smartVolumeProfileBuilder10.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder10.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId128, "Extrude Dialog")
    
    section10.DistanceTolerance = 0.01
    
    section10.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section10.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder10.Destroy()
    
    section10.Destroy()
    
    workPart.Expressions.Delete(expression67)
    
    theSession.UndoToMark(markId128, None)
    
    theSession.DeleteUndoMark(markId128, None)
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects1 = [NXOpen.DisplayableObject.Null] * 5 
    objects1[0] = line5
    objects1[1] = line6
    objects1[2] = line7
    objects1[3] = line8
    objects1[4] = sketch6
    theSession.DisplayManager.BlankObjects(objects1)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects2 = [NXOpen.DisplayableObject.Null] * 5 
    objects2[0] = sketch2
    objects2[1] = line1
    objects2[2] = line2
    objects2[3] = line3
    objects2[4] = line4
    theSession.DisplayManager.BlankObjects(objects2)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects3 = [NXOpen.DisplayableObject.Null] * 2 
    objects3[0] = arc1
    objects3[1] = sketch4
    theSession.DisplayManager.BlankObjects(objects3)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects4 = [NXOpen.DisplayableObject.Null] * 5 
    objects4[0] = line9
    objects4[1] = line10
    objects4[2] = sketch8
    objects4[3] = line11
    objects4[4] = line12
    theSession.DisplayManager.BlankObjects(objects4)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects5 = [NXOpen.DisplayableObject.Null] * 2 
    objects5[0] = arc2
    objects5[1] = sketch10
    theSession.DisplayManager.BlankObjects(objects5)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects6 = [NXOpen.DisplayableObject.Null] * 8 
    objects6[0] = point1
    cartesianCoordinateSystem6 = datumCsys1.FindObject("CSYSTEM 1")
    objects6[1] = cartesianCoordinateSystem6
    objects6[2] = datumAxis1
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    objects6[3] = datumAxis2
    datumAxis3 = workPart.Datums.FindObject("DATUM_CSYS(0) Z axis")
    objects6[4] = datumAxis3
    datumPlane3 = workPart.Datums.FindObject("DATUM_CSYS(0) XY plane")
    objects6[5] = datumPlane3
    objects6[6] = datumPlane2
    objects6[7] = datumPlane1
    theSession.DisplayManager.BlankObjects(objects6)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()